

import type * as LucideIcons from 'lucide-react';
import * as geminiService from './services/geminiService'; // For OrchestratorComponentDefinition execute type

export type IconName = Extract<keyof typeof LucideIcons, string>;

export interface Badge {
  id: string;
  name: string;
  icon: IconName;
  description: string;
}

// --- New Multi-modal Message Parts ---
export interface TextPart {
  text: string;
}

export interface ImagePart {
  inlineData: {
    mimeType: string; // e.g., 'image/png', 'image/jpeg'
    data: string; // base64 encoded string
  };
}

export type ChatMessagePart = TextPart | ImagePart;

// For Actions requested from Guidance Console to Orchestrator
export type OrchestratorActionType =
  | 'ADD_AND_CONNECT_DISPLAY'
  | 'SCAFFOLD_WORKFLOW_BLUEPRINT'; // Added new type

export interface AddAndConnectDisplayActionPayload {
  type: 'ADD_AND_CONNECT_DISPLAY';
  sourceInstanceId: string;
  sourceNodeId: string; // The output node ID of the sourceInstance
  outputDataType: 'text' | 'image_ref'; // Data type of the source output, to determine which display component to add
}

export interface BlueprintComponentToScaffold {
  componentDefId: string;
  customName?: string;
}

export interface BlueprintConnectionToMake {
  fromInstanceIndex: number; // Index in the componentsToScaffold array
  fromNodeId: string;
  toInstanceIndex: number;   // Index in the componentsToScaffold array
  toNodeId: string;
}

export interface ScaffoldWorkflowBlueprintPayload {
  type: 'SCAFFOLD_WORKFLOW_BLUEPRINT';
  workflowTypeName: string;
  componentsToScaffold: BlueprintComponentToScaffold[];
  connectionsToMake?: BlueprintConnectionToMake[];
}

export type OrchestratorActionPayload = 
  | AddAndConnectDisplayActionPayload
  | ScaffoldWorkflowBlueprintPayload; // Added new payload type


export interface ChatMessage {
  id: string;
  role: 'user' | 'model' | 'system' | 'noema';
  parts: ChatMessagePart[];
  timestamp: number;
  isSocratic?: boolean;
  isLoading?: boolean;
  isError?: boolean;
  imageUrl?: string;
  // For Tool Master mode display
  isToolCallRequest?: boolean; // Model wants to call a tool
  toolName?: string;
  toolArgs?: Record<string, any>;
  isToolResponse?: boolean; // This message is the result of a tool
  toolResult?: any;
  
  // For query-based actionable hints in Guidance Console (Console C style)
  isHint?: boolean;
  actionableText?: string; // e.g., "Tell me more..."
  actionQuery?: string; // The query string to send if button clicked
  hintContextComponentDefId?: string; // Optional component ID relevant to the hint query
  questToStartId?: string; // New field: If set, handleSendMessage should start this quest

  // For direct orchestrator actions (Console A style & new review actions)
  directOrchestratorAction?: {
    buttonLabel: string;
    actionType: OrchestratorActionType;
    actionPayload: OrchestratorActionPayload;
  };

  // For making issue text clickable to focus canvas elements
  focusTarget?: {
    instanceId: string;
    nodeId?: string; // Optional: to highlight a specific input/output node
    // The main text of the message part itself will be the clickable label
  };
}

// --- End New Multi-modal Message Parts ---

export interface ModelConfigOverrides {
  temperature?: number;
  topK?: number;
  topP?: number;
  systemInstruction?: string;
  // other potential generative config params
}

// --- Agent Orchestrator Types ---
export interface OrchestratorNodeDefinition {
  id: string; // e.g., 'input_text', 'output_image'
  label: string;
  dataType: 'text' | 'image_ref' | 'number' | 'boolean' | 'generic_object' | 'any' | 'json_object'; // Added 'any', 'json_object' for flexibility
  isOptional?: boolean;
  nodeDescription?: string; // Added for more detail in UI
}

export interface OrchestratorComponentConfigField {
  id: string; // e.g., 'prompt_style', 'max_tokens'
  label: string;
  type: 'text' | 'textarea' | 'number' | 'select' | 'boolean'; // Added 'boolean'
  options?: Array<{value: string | number, label: string}>; // For select type
  defaultValue?: any;
  placeholder?: string;
  min?: number;
  max?: number;
  step?: number;
  helpText?: string; // New field for contextual help
}

// Orchestrator specific types for the new AgentOrchestratorView
export interface MappingRule {
  id: string;
  outputFieldName: string;
  sourceType: 'input_path' | 'static_value';
  inputFieldPath?: string; // Used if sourceType is 'input_path'
  staticValue?: any;       // Used if sourceType is 'static_value'
  outputDataType?: 'auto' | 'string' | 'number' | 'boolean'; // Used for static_value type coercion
}


export interface OrchestratorComponentDefinition {
  id: string; // Unique ID for the component definition, e.g., "user_text_input_v1"
  name: string;
  description: string;
  icon: IconName;
  category: 'INPUT' | 'PROCESS' | 'OUTPUT' | 'LOGIC' | 'TOOL' | 'DATA'; // Added TOOL, DATA
  inputs: OrchestratorNodeDefinition[];
  outputs: OrchestratorNodeDefinition[];
  configFields?: OrchestratorComponentConfigField[];
  usageAnalogy?: string; // New field for Orchestrator Companion Panel
  execute?: (
    inputs: Record<string, any>,
    config: Record<string, any>,
    services: { gemini: typeof geminiService } // Pass geminiService module
  ) => Promise<Record<string, any>>; // Output data keyed by output node ID
}

export interface OrchestratorInstance {
  id: string; // Instance-specific unique ID, e.g., generated by crypto.randomUUID()
  componentDefId: string; // Links to OrchestratorComponentDefinition.id
  position: { x: number; y: number };
  configValues: Record<string, any>; // Keyed by configField.id
  customName?: string; // User-defined name for the instance
  isCollapsed?: boolean;
  outputData?: Record<string, any>; // Stores last execution output, keyed by output node ID
  error?: string; // Stores last execution error message
  isRunning?: boolean; // Visual feedback during execution
  isCompleted?: boolean; // Visual feedback after successful execution
}

export interface OrchestratorConnection {
  id: string; // Unique ID for the connection
  fromInstanceId: string;
  fromNodeId: string; // OrchestratorNodeDefinition.id of an output node
  toInstanceId: string;
  toNodeId: string; // OrchestratorNodeDefinition.id of an input node
}

export interface OrchestratorWorkflow {
  instances: OrchestratorInstance[];
  connections: OrchestratorConnection[];
}

export interface OrchestratorConfig {
  taskDescription: string;
  availableComponentDefs: string[]; // IDs of OrchestratorComponentDefinitions allowed for this step
  initialWorkflow?: OrchestratorWorkflow; // Optional pre-defined starting workflow
  successCriteria?: {
    requiredConnections?: Array<{ from: string; to: string }>; // componentDefId.outputNodeId -> componentDefId.inputNodeId
    // expectedOutput?: (data: any) => boolean; // Function to check final output (complex)
    // For simplicity, can rely on Socratic prompts or simple connection checks first.
    requiredComponents?: string[]; // List of componentDefIds that must be present
    successMessage?: string; // For AgentOrchestratorView (new): message in log that indicates success for quest
  };
}
// --- End Agent Orchestrator Types ---


export interface SocraticContext {
  userInput?: string;
  aiResponse?: string;
  uploadedImage?: File; // Or string for base64
  currentQuestId?: string;
  currentStepId?: string;
  userProgress?: UserProgressData;
  chatHistory?: ChatMessage[];
  generatedImageUrl?: string;
  // For Agent Simulation Context
  customEventIdentifier?: string; // Renamed from simulationEvent for broader use, e.g., "agent_cleaned_dirt", "user_added_inputs_orchestrator"
  agentGridPosition?: { x: number, y: number };
  agentBatteryLevel?: number;
  agentInternalModelSize?: number; // e.g., number of known obstacles
  agentInventorySize?: number; // New for Goal-Based Agent
  agentGoalStatus?: string; // New for Goal-Based Agent
  // For Parameter Tweaking Context
  tweakedParameters?: Record<string, number>;
  simulationOutcome?: string; // e.g., "battery_depleted_quickly", "goal_achieved_efficiently"
  agentAssemblyStatus?: 'incomplete_sensors' | 'incomplete_logic' | 'incomplete_actuators' | 'success' | 'incomplete' | string; // For Agent Assembly
  // For Agent Orchestrator Context
  orchestratorWorkflowStatus?: 'executed_success' | 'executed_error' | 'incomplete' | 'cycle_detected' | 'user_added_inputs'; // Added 'user_added_inputs'
  orchestratorOutputData?: Record<string, any>; // Outputs from 'OUTPUT' category components
}

export type SocraticBranchCondition = (context: SocraticContext) => boolean;

export interface SocraticBranch {
  id: string;
  responseTextMatch?: string | RegExp;
  condition?: SocraticBranchCondition;
  nextSocraticPromptId?: string;
  noemaResponse?: string;
  advanceToStepId?: string;
  awardXp?: number;
  expectedUserAction?: string;
}

export type SocraticPromptTrigger =
  | 'STEP_START'
  | 'AI_RESPONSE_RECEIVED'
  | 'IMAGE_GENERATED'
  | 'IMAGE_UPLOADED'
  | 'USER_REFLECTION_SUBMITTED'
  | 'AGENT_SIMULATION_EVENT' // This relates to the agent sim specific view
  | 'CUSTOM_EVENT' // Generic custom event for various UI interactions
  | 'SIMULATION_PARAMETERS_SET' // For agent sim parameter view
  | 'ORCHESTRATOR_WORKFLOW_EVENT' // Specific to Orchestrator view events
  | 'GLOSSARY_EXPLORATION'; // Added for Nexus interaction

export interface SocraticPromptDefinition {
  id: string;
  questStepId: string;
  trigger: SocraticPromptTrigger;
  condition?: SocraticBranchCondition;
  noemaQuestion: string;
  branches: SocraticBranch[];
  expectedUserActionHint?: string;
}

// --- Agent Assembly Types ---
export type AgentComponentType = 'SENSOR' | 'DECISION_MODULE' | 'ACTUATOR';

export interface AgentComponentDefinition {
  id: string;
  name: string;
  description: string;
  type: AgentComponentType;
  icon?: IconName;
  cost?: number;
  properties?: Record<string, any>;
}

export interface AgentSlotDefinition {
  id: string;
  label: string;
  acceptedType: AgentComponentType;
  icon?: IconName;
  required?: boolean;
}

export interface AssembledAgentComponent {
  slotId: string;
  componentId: string;
}

export interface AgentAssemblySuccessCriteria {
    requiredComponentIds?: string[];
}

export interface AgentAssemblyConfig {
  taskDescription: string;
  environmentDescription: string;
  agentSlots: AgentSlotDefinition[];
  availableComponents: AgentComponentDefinition[];
  successCriteria: AgentAssemblySuccessCriteria;
}
// --- End Agent Assembly Types ---

export type InteractionType =
  | 'AI_CHAT'
  | 'AI_IMAGE_GEN'
  | 'AI_IMAGE_UPLOAD_ANALYSIS'
  | 'USER_REFLECTION'
  | 'GLOSSARY_EXPLORATION'
  | 'CAPSTONE_PROJECT'
  | 'AGENT_SIMULATION_2D'
  | 'AGENT_ASSEMBLY'
  | 'AGENT_ORCHESTRATOR';

export interface GridCellState {
  type: 'empty' | 'obstacle' | 'dirt' | 'charging_station' | 'item' | 'exit';
  id: string;
  itemId?: string;
}

export interface AgentInternalModel {
  knownObstacles: {x: number, y: number}[];
  knownChargingStation: {x: number, y: number} | null;
}

export interface AgentGoalDefinition {
    itemsToCollectCount: number;
    exitLocation: {x: number, y:number};
}

export interface Agent2DState {
  x: number;
  y: number;
  direction: 'N' | 'E' | 'S' | 'W';
  actionMessage?: string;
  currentRule?: string;
  batteryLevel: number;
  lowBatteryThreshold: number;
  internalModel: AgentInternalModel;
  currentPercepts?: string[];
  inventory: string[];
  goalDefinition?: AgentGoalDefinition;
  currentGoalDescription?: string;
}

export interface AgentRule {
    id: string;
    conditionFn: (agent: Agent2DState, grid: GridCellState[][], allItems?: Array<{x:number, y:number, id:string}>) => boolean;
    action: string;
    description: string;
    priority?: number;
}

export interface TweakableParameterConfig {
    id: string;
    label: string;
    defaultValue: number;
    min: number;
    max: number;
    step: number;
    description?: string;
}

export interface AgentSimulation2DConfig {
  gridSize: { rows: number; cols: number };
  initialGridState: GridCellState[][];
  initialAgentState: Omit<Agent2DState, 'internalModel' | 'lowBatteryThreshold' | 'inventory' | 'goalDefinition' | 'currentGoalDescription' | 'currentPercepts'> &
                     Partial<Pick<Agent2DState, 'lowBatteryThreshold' | 'goalDefinition'>>;
  agentRules: AgentRule[];
  initialBatteryLevel?: number;
  lowBatteryThreshold?: number;
  batteryConsumption?: { move: number; turn: number; clean: number; idle: number; collect?: number };
  batteryRechargeRate?: number;
  itemLocations?: Array<{x: number, y: number, id: string}>;
  exitLocation?: {x: number, y: number};
  tweakableParameters?: TweakableParameterConfig[];
}

export interface QuestStep {
  id: string;
  questId: string;
  title: string;
  learningObjective: string;
  noemaIntro: string;
  interactionType: InteractionType;
  initialAiPromptSuggestions?: { type: 'text' | 'image'; prompt: string }[];
  socraticPromptIds?: string[];
  keyTakeaway: string;
  xpAward: number;
  icon: IconName;
  simulationConfig?: AgentSimulation2DConfig;
  agentAssemblyConfig?: AgentAssemblyConfig;
  orchestratorConfig?: OrchestratorConfig;
  modelConfigOverrides?: ModelConfigOverrides;
}

export interface Quest {
  id: string;
  phase: string;
  title: string;
  description: string;
  badge: Badge;
  totalXp: number;
  steps: QuestStep[];
  academy?: 'agentAcademy' | string;
}

export interface SavedAiResponse {
  id: string;
  userPrompt: string;
  aiResponse: string;
  interactionType: InteractionType;
  timestamp: number;
  relatedUserImage?: string;
  relatedAiImage?: string;
}

export type NotebookEntryType =
  | 'user_note'
  | 'aha_moment'
  | 'question_for_later'
  | 'story_fragment'
  | 'lore_entry'
  | 'story_snapshot'
  | 'scenario_lab_result';

export interface NotebookEntry {
  id: string;
  type: NotebookEntryType;
  title?: string;
  content: any;
  questId?: string;
  stepId?: string;
  storyId?: string;
  tags?: string[];
  createdAt: number;
  updatedAt: number;
}

export type StoryForgeLoreCategory = "Characters" | "Locations" | "PlotPoints" | "Items" | "Factions" | "Concepts" | string;

// --- Scenario Lab Types ---
export interface StoryboardPrompt {
  description: string;
  imageGenPrompt: string;
}

export interface ScenarioOutput {
  titleSuggestion: string;
  keyElementsAndCharacters: string[];
  potentialPlotPoints: string[];
  atmosphericDescriptors: string[];
  storyboardPrompts: StoryboardPrompt[];
  dialogueSnippet: string;
}
// --- End Scenario Lab Types ---

export interface StoryForgeSession {
  id: string;
  title: string;
  fullStory: ChatMessage[];
  loreNotes: { [K in StoryForgeLoreCategory]?: string[] };
  generatedVisuals?: {
    [key: string]: {
      description: string;
      imagePrompt: string;
      imageBase64: string;
    }
  };
  scenarioVisualPrompts?: StoryboardPrompt[];
  currentSystemInstructionForNoema?: string; // New for guiding narrative tone
  lastUpdated: string;
  vaultStoryId?: string;
}

export interface VaultStory {
  id: string;
  title: string;
  description?: string;
  baseSessionId: string;
  versionSessionIds: string[];
  createdAt: number;
  lastModified: number;
}

export interface UserProgressData {
  userId: string;
  displayName: string;
  xp: number;
  unlockedBadgeIds: string[];
  currentQuestId: string | null;
  currentStepId: string | null;
  completedQuestSteps: { [stepId: string]: { completedAt: number; socraticPath?: string[] } };
  savedAiResponses: SavedAiResponse[];
  noemasNotebookEntries: NotebookEntry[];
  storyForgeSessions: StoryForgeSession[];
  storyVault: VaultStory[];
  ttsEnabled: boolean;
}

export interface PromptItem {
  id: string;
  text: string;
  type: 'text' | 'image' | 'multi-modal';
  title: string;
  category: string;
  notes?: string;
  createdAt: number;
  updatedAt: number;
}

export interface GlossaryItem {
  id: string;
  term: string;
  explanation: string;
  example?: string;
  category: string;
  icon?: IconName;
  interactiveComponentKey?: string;
  imagePromptForNexus?: string;
  generatedImageBase64?: string;
}

export type AppView = 
  | 'welcome' 
  | 'interaction' 
  | 'nexus' 
  | 'library' 
  | 'workshop' 
  | 'notebook' 
  | 'story_vault' 
  | 'agent_academy_log' 
  | 'quest_log'
  | 'story_forge'             // New AppView
  | 'agent_orchestrator_sandbox'; // New AppView

export type WorkshopMode =
  | 'chat'
  | 'image'
  | 'story_forge' // Will remain for internal logic if Workshop is selected
  | 'debate_arena'
  | 'feedback_coach'
  | 'tool_master'
  // | 'scenario_lab' // Removed as it's integrated into Story Forge
  | 'agent_orchestrator_sandbox'; // Will remain for internal logic if Workshop is selected

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface ToastMessage {
  id: string;
  message: string;
  type: ToastType;
  icon?: IconName;
  duration?: number;
}

export interface ModalConfig {
  title: string;
  content: React.ReactNode;
  onConfirm?: () => void;
  confirmText?: string;
  onCancel?: () => void;
  cancelText?: string;
  isVisible: boolean;
}

// --- Tool Master Mode Types (New) ---
export interface ToolDefinition {
  name: string;
  description: string;
  parameters: {
    type: "object";
    properties: Record<string, { type: string; description: string; enum?: string[] }>;
    required?: string[];
  };
}

export interface AvailableTools {
  [key: string]: {
    definition: ToolDefinition;
    execute: Function;
  };
}
// --- End Tool Master Mode Types ---


// Contextual Insights for Guidance Console
export interface NoemaInsight {
  id: string; // e.g., "nexus-G1", "quest-Q1S2"
  type: 'nexus' | 'quest_step';
  title: string; // Term name or Quest Step Title
  targetId: string; // GlossaryItem.id or QuestStep.id
  questId?: string; // Only if type is 'quest_step'
  relevanceContext?: string; // Short explanation of why it's relevant
}

// New context fields for Orchestrator Companion Panel
export interface AppContextType {
  userProgress: UserProgressData | null;
  setUserProgress: React.Dispatch<React.SetStateAction<UserProgressData | null>>;
  updateUserProgress: (updates: Partial<UserProgressData>) => void;
  promptLibrary: PromptItem[];
  setPromptLibrary: React.Dispatch<React.SetStateAction<PromptItem[]>>;
  addPromptToLibrary: (prompt: Omit<PromptItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  deletePromptFromLibrary: (promptId: string) => void;
  quests: Quest[];
  socraticPrompts: SocraticPromptDefinition[];
  activeQuest: Quest | null;
  activeStep: QuestStep | null;
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  startQuest: (questId: string) => void;
  completeStep: (stepId: string, questId: string, socraticContext?: SocraticContext) => void;
  resetUserProgressAndLibrary: () => void;
  
  modalConfig: ModalConfig | null;
  showModal: (config: Omit<ModalConfig, 'isVisible'>) => void;
  hideModal: () => void;

  addToast: (message: string, type?: ToastMessage['type'], duration?: number) => void;

  speak: (text: string, force?: boolean) => void;
  toggleTTS: () => void;
  isTTSEnabled: boolean;

  userId: string | null;
  isAppReady: boolean;
  initializeUser: (name: string) => void;

  addNotebookEntry: (entryData: Omit<NotebookEntry, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateNotebookEntry: (updatedEntry: NotebookEntry) => void;
  deleteNotebookEntry: (entryId: string) => void;

  addSavedAiResponse: (aiMessage: ChatMessage, userPrompt?: ChatMessage) => void;
  
  storyForgeSessions: StoryForgeSession[]; // Added storyForgeSessions
  createStoryForgeSession: () => StoryForgeSession; 
  updateStoryForgeSessions: (sessions: StoryForgeSession[], updatedSession?: StoryForgeSession) => void;
  createVaultStory: (baseSession: StoryForgeSession, title?: string) => string | undefined;
  addVersionToVaultStory: (vaultId: string, versionSession: StoryForgeSession) => void;
  updateVaultStoryMeta: (vaultId: string, updates: Partial<Pick<VaultStory, 'title' | 'description'>>) => void;
  deleteVaultStoryEntry: (vaultId: string) => void;
  removeSessionFromVault: (vaultId: string, sessionId: string) => void;
  loadSessionToWorkshop: (sessionId: string) => void;

  triggerSocraticPromptsForSimulation: (triggerType: SocraticPromptDefinition['trigger'], context: SocraticContext) => void;

  targetNexusTermId: string | null;
  setTargetNexusTermId: (termId: string | null) => void;

  // For Agent Orchestrator global state if needed by other views (e.g. Guidance Console)
  selectedOrchestratorInstanceId: string | null;
  setSelectedOrchestratorInstanceId: React.Dispatch<React.SetStateAction<string | null>>;

  // New for Orchestrator Companion Panel & Workshop Mode Management
  activeWorkshopMode: WorkshopMode | null;
  setActiveWorkshopMode: React.Dispatch<React.SetStateAction<WorkshopMode | null>>;
  orchestratorWorkflowForContext: OrchestratorWorkflow | null;
  setOrchestratorWorkflowForContext: React.Dispatch<React.SetStateAction<OrchestratorWorkflow | null>>;

  // For PromptLibraryView to set input for Workshop
  inputValue: string;
  setInputValue: React.Dispatch<React.SetStateAction<string>>;
}