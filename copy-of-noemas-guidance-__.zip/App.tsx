
import React from 'react'; // FC, ReactNode, useEffect, useCallback, useState, createContext are moved
import { useAppContext } from './contexts/AppContext.tsx'; // Updated import path for useAppContext
import { Icon } from './components/Icon.tsx'; // Icon specific to AppDisplayContent if needed, or AppProvider if only used there.
import WelcomeScreen from './components/WelcomeScreen.tsx';
import Header from './components/Header.tsx';
import Sidebar from './components/Sidebar.tsx';
import MainInteractionView from './components/MainInteractionView.tsx';
import NoemasNexusView from './components/NoemasNexusView.tsx';
import PromptLibraryView from './components/PromptLibraryView.tsx';
import { NoemasWorkshopView } from './components/NoemasWorkshopView.tsx'; // Changed to named import
import NoemasNotebookView from './components/NoemasNotebookView.tsx';
import StoryVaultView from './components/StoryVaultView.tsx';
import AgentAcademyLogView from './components/AgentAcademyLogView.tsx';
import QuestLogView from './components/QuestLogView.tsx';
// Types like AppContextType are now defined/used within contexts/AppContext.tsx primarily
// Constants like ALL_QUESTS are used by AppProvider in contexts/AppContext.tsx

export const AppDisplayContent: React.FC = () => {
  const { 
    userProgress, 
    currentView, 
    isAppReady, 
    activeWorkshopMode, 
    updateUserProgress: contextUpdateUserProgress, 
    addNotebookEntry: contextAddNotebook, 
    speak, 
    addToast, 
    storyForgeSessions, 
    updateStoryForgeSessions, 
    addPromptToLibrary, 
    addSavedAiResponse 
  } = useAppContext();

  if (!isAppReady) {
    return (
      <div className="flex items-center justify-center h-full bg-gradient-to-br from-slate-900 via-purple-900 to-sky-900 p-8">
        <Icon name="Loader2" className="animate-spin h-16 w-16 text-sky-400" />
        <p className="text-slate-300 ml-4">Initializing Noema's Guidance...</p>
      </div>
    );
  }
  
  if (!userProgress) {
    return <WelcomeScreen />;
  }

  console.log("[AppDisplayContent] RENDERING. currentView:", currentView, "activeWorkshopMode:", activeWorkshopMode);

  const renderMainContent = () => {
    console.log("[AppDisplayContent] Rendering main layout. currentView:", currentView);
    switch (currentView) {
      case 'interaction': return <MainInteractionView />;
      case 'nexus': return <NoemasNexusView />;
      case 'library': return <PromptLibraryView />;
      case 'notebook': return <NoemasNotebookView />;
      case 'story_vault': return <StoryVaultView />;
      case 'agent_academy_log': return <AgentAcademyLogView />;
      case 'quest_log': return <QuestLogView />;
      
      case 'story_forge':
      case 'agent_orchestrator_sandbox':
      case 'workshop': 
        // Pass necessary props to NoemasWorkshopView.
        // Many of these will now be implicitly available via context if NoemasWorkshopView uses useAppContext.
        // Explicitly pass props that StoryForgeView (a child of NoemasWorkshopView) might need if it doesn't use context directly for them.
        return <NoemasWorkshopView 
                  speakMessage={speak} 
                  addToast={addToast}
                  userProgress={userProgress!} 
                  updateUserProgress={contextUpdateUserProgress}
                  onSavePrompt={addPromptToLibrary} 
                  onSaveAiResponse={addSavedAiResponse}
                  storyForgeSessions={storyForgeSessions}
                  onUpdateStoryForgeSessions={updateStoryForgeSessions}
                  onSaveToNotebook={contextAddNotebook}
               />;
      default: return <div className="p-6 text-center text-slate-400">Noema is pondering... Unknown view: {currentView}</div>;
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100 dot-grid-background">
      <Header />
      <div className="flex flex-row flex-grow overflow-hidden pt-16"> {/* pt-16 for header height */}
        <Sidebar />
        <main className="flex-grow overflow-auto custom-scrollbar p-3 md:p-4 bg-slate-900/70 backdrop-blur-sm">
          {renderMainContent()}
        </main>
      </div>
    </div>
  );
};
