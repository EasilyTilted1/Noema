import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAppContext } from '../../contexts/AppContext.tsx'; 
import { Icon } from '../Icon.tsx'; 
import { ChatMessage, TextPart, ModelConfigOverrides, SocraticPromptDefinition, SocraticContext } from '../../types.ts'; 
import * as geminiService from '../../services/geminiService.ts'; 

const ChatInteraction: React.FC = () => {
  const { 
    activeStep, 
    addToast, 
    speak, 
    isTTSEnabled, 
    addSavedAiResponse, 
    userId, 
    socraticPrompts, 
    completeStep,
    activeQuest 
  } = useAppContext();
  
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentSocraticContextId, setCurrentSocraticContextId] = useState<string | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeStep) {
      const initialMessages: ChatMessage[] = [];
      let introText = activeStep.noemaIntro || "Hello! How can I assist you with this step?";
      
      initialMessages.push({
        id: crypto.randomUUID(),
        role: 'noema',
        parts: [{ text: introText }],
        timestamp: Date.now(),
      });
      
      // Check for STEP_START Socratic prompts
      const stepStartPrompts = socraticPrompts.filter(
        sp => sp.questStepId === activeStep.id && sp.trigger === 'STEP_START'
      );

      if (stepStartPrompts.length > 0) {
        const firstSocraticPrompt = stepStartPrompts[0];
        // Check condition if present
        const context: SocraticContext = { userInput: '', aiResponse: '', currentQuestId: activeQuest?.id, currentStepId: activeStep.id }; // Minimal context for initial check
        if (!firstSocraticPrompt.condition || firstSocraticPrompt.condition(context)) {
          setCurrentSocraticContextId(firstSocraticPrompt.id);
          initialMessages.push({
            id: crypto.randomUUID(),
            role: 'noema',
            parts: [{ text: firstSocraticPrompt.noemaQuestion }],
            timestamp: Date.now(),
            isSocratic: true,
          });
          introText = firstSocraticPrompt.noemaQuestion; // For TTS
        }
      } else {
        setCurrentSocraticContextId(null); // No STEP_START Socratic prompt for this step
      }
      
      setChatHistory(initialMessages);

      if (isTTSEnabled && introText) {
        speak(introText, true);
      }
    }
    setUserInput('');
  }, [activeStep, socraticPrompts, speak, isTTSEnabled, activeQuest?.id]); // REMOVED chatHistory from dependency array

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSendMessage = useCallback(async () => {
    if (!userInput.trim() || isLoading || !activeStep || !activeQuest) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      parts: [{ text: userInput.trim() }],
      timestamp: Date.now(),
    };

    setChatHistory(prev => [...prev, userMessage]);
    const currentInput = userInput.trim();
    setUserInput('');
    setIsLoading(true);

    try {
      if (currentSocraticContextId) {
        const activeSocraticPrompt = socraticPrompts.find(sp => sp.id === currentSocraticContextId);
        if (activeSocraticPrompt) {
          let matchedBranch = null;
          const socraticEvaluationContext: SocraticContext = { 
            userInput: currentInput, 
            currentQuestId: activeQuest.id, 
            currentStepId: activeStep.id,
            chatHistory: [...chatHistory, userMessage] 
          };

          for (const branch of activeSocraticPrompt.branches) {
            if (branch.responseTextMatch) {
              const regex = typeof branch.responseTextMatch === 'string' 
                            ? new RegExp(branch.responseTextMatch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') 
                            : branch.responseTextMatch;
              if (regex.test(currentInput)) {
                matchedBranch = branch;
                break;
              }
            } else if (branch.condition && branch.condition(socraticEvaluationContext)) {
              matchedBranch = branch;
              break;
            }
          }
          
          // Fallback to the last branch if it has no condition or responseTextMatch (i.e. a default/catch-all branch)
          if (!matchedBranch && activeSocraticPrompt.branches.length > 0) {
              const lastBranch = activeSocraticPrompt.branches[activeSocraticPrompt.branches.length - 1];
              if (!lastBranch.responseTextMatch && !lastBranch.condition) {
                  matchedBranch = lastBranch;
              }
          }


          if (matchedBranch) {
            const noemaSocraticResponse: ChatMessage = {
              id: crypto.randomUUID(),
              role: 'noema',
              parts: [{ text: matchedBranch.noemaResponse || "Interesting..." }],
              timestamp: Date.now(),
              isSocratic: true,
            };
            setChatHistory(prev => [...prev, noemaSocraticResponse]);
            if (isTTSEnabled && matchedBranch.noemaResponse) speak(matchedBranch.noemaResponse);

            if (matchedBranch.nextSocraticPromptId) {
              const nextPrompt = socraticPrompts.find(sp => sp.id === matchedBranch!.nextSocraticPromptId);
              if (nextPrompt) {
                setCurrentSocraticContextId(nextPrompt.id);
                const nextNoemaQuestion: ChatMessage = {
                  id: crypto.randomUUID(),
                  role: 'noema',
                  parts: [{ text: nextPrompt.noemaQuestion }],
                  timestamp: Date.now(),
                  isSocratic: true,
                };
                setChatHistory(prev => [...prev, nextNoemaQuestion]);
                if (isTTSEnabled) speak(nextPrompt.noemaQuestion);
              } else {
                setCurrentSocraticContextId(null); // Next prompt not found, clear Socratic context
                addToast("Error: Next Socratic prompt not found.", "error");
              }
            } else if (matchedBranch.advanceToStepId) {
              completeStep(activeStep.id, activeQuest.id, socraticEvaluationContext);
              setCurrentSocraticContextId(null); // Reset Socratic context
            } else {
              setCurrentSocraticContextId(null); // End of Socratic chain for this interaction
            }
          } else {
            // No branch matched, let AI respond generally or provide a default Socratic fallback
            setCurrentSocraticContextId(null); // Clear Socratic context for now
            addToast("No specific Socratic branch matched. Falling back to general AI.", "info");
            
             const { text: aiResponseText } = await geminiService.generateChatResponseMultiModal(
                [...chatHistory, userMessage], undefined, activeStep.modelConfigOverrides
             );
             const aiMessage: ChatMessage = { id: crypto.randomUUID(), role: 'model', parts: [{ text: aiResponseText }], timestamp: Date.now() };
             setChatHistory(prev => [...prev, aiMessage]);
             if (isTTSEnabled) speak(aiResponseText);
             addSavedAiResponse(aiMessage, userMessage);
          }
        } else {
          setCurrentSocraticContextId(null); // Active Socratic prompt def not found
        }
      } else { // No active Socratic context, proceed with normal Gemini call
        const apiChatHistory = chatHistory.filter(msg => msg.role === 'user' || msg.role === 'model');
        const currentTurnHistory = [...apiChatHistory, userMessage];

        const { text: aiResponseText } = await geminiService.generateChatResponseMultiModal(
          currentTurnHistory,
          undefined,
          activeStep.modelConfigOverrides
        );

        if (!aiResponseText.toLowerCase().startsWith('error:')) {
          const aiMessage: ChatMessage = {
            id: crypto.randomUUID(),
            role: 'model',
            parts: [{ text: aiResponseText }],
            timestamp: Date.now(),
          };
          setChatHistory(prev => [...prev, aiMessage]);
          if (isTTSEnabled) {
            speak(aiResponseText);
          }
          addSavedAiResponse(aiMessage, userMessage);

          // After AI response, check for AI_RESPONSE_RECEIVED Socratic prompts
          const aiResponsePrompts = socraticPrompts.filter(
            sp => sp.questStepId === activeStep.id && sp.trigger === 'AI_RESPONSE_RECEIVED'
          );
          if (aiResponsePrompts.length > 0) {
            const socraticEvaluationContext: SocraticContext = { userInput: currentInput, aiResponse: aiResponseText, chatHistory: [...chatHistory, userMessage, aiMessage], currentQuestId: activeQuest.id, currentStepId: activeStep.id };
            let triggeredSocraticPrompt = null;
            for(const promptDef of aiResponsePrompts) {
                if (!promptDef.condition || promptDef.condition(socraticEvaluationContext)) {
                    triggeredSocraticPrompt = promptDef;
                    break;
                }
            }
            if (triggeredSocraticPrompt) {
              setCurrentSocraticContextId(triggeredSocraticPrompt.id);
              const noemaQuestion: ChatMessage = {
                id: crypto.randomUUID(),
                role: 'noema',
                parts: [{ text: triggeredSocraticPrompt.noemaQuestion }],
                timestamp: Date.now(),
                isSocratic: true,
              };
              setChatHistory(prev => [...prev, noemaQuestion]);
              if (isTTSEnabled) speak(triggeredSocraticPrompt.noemaQuestion);
            }
          }

        } else {
          throw new Error(aiResponseText.substring(7));
        }
      }
    } catch (error: any) {
      console.error("Error in handleSendMessage:", error);
      const errorMessage = error.message || "Failed to process message.";
      addToast(errorMessage, 'error');
      setChatHistory(prev => [...prev, {
        id: crypto.randomUUID(),
        role: 'system',
        parts: [{ text: `Error: ${errorMessage}` }],
        timestamp: Date.now(),
        isError: true,
      }]);
    } finally {
      setIsLoading(false);
    }
  }, [userInput, isLoading, activeStep, activeQuest, chatHistory, socraticPrompts, currentSocraticContextId, addToast, speak, isTTSEnabled, addSavedAiResponse, completeStep]);

  const getRoleIcon = (role: ChatMessage['role']) => {
    switch (role) {
      case 'user': return <Icon name="UserCircle" size={18} className="text-sky-300 flex-shrink-0" aria-label="User icon" />;
      case 'model': return <Icon name="Bot" size={18} className="text-purple-300 flex-shrink-0" aria-label="AI Guide icon" />;
      case 'noema': return <Icon name="Bot" size={18} className="text-yellow-300 flex-shrink-0" aria-label="Noema icon" />;
      case 'system': return <Icon name="AlertTriangle" size={18} className="text-red-400 flex-shrink-0" aria-label="System alert icon"/>;
      default: return <Icon name="MessageSquare" size={18} className="text-slate-400 flex-shrink-0" aria-label="Message icon" />;
    }
  };

   const getRoleLabel = (role: ChatMessage['role']) => {
    switch (role) {
      case 'user': return userId || 'User';
      case 'model': return 'AI Guide';
      case 'noema': return 'Noema';
      case 'system': return 'System Alert';
      default: return 'Message';
    }
  };

  return (
    <div className="flex flex-col h-full p-2 bg-slate-800/50 rounded-lg" aria-live="polite">
      <div ref={chatContainerRef} className="flex-grow overflow-y-auto mb-3 space-y-3 custom-scrollbar pr-2">
        {chatHistory.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-3 rounded-xl shadow-md ${
              msg.role === 'user' ? 'bg-sky-600 text-white rounded-br-none' :
              msg.role === 'model' ? 'bg-purple-600 text-white rounded-bl-none' :
              msg.role === 'noema' ? 'bg-yellow-600 text-slate-900 rounded-bl-none' :
              msg.isError ? 'bg-red-700 text-red-100' :
              'bg-slate-600 text-slate-200'
            }`}>
              <div className="flex items-center mb-1">
                {getRoleIcon(msg.role)}
                <span className="text-xs font-semibold ml-2 opacity-80">{getRoleLabel(msg.role)}</span>
              </div>
              <p className="text-sm whitespace-pre-wrap break-words">
                {msg.parts.map(part => 'text' in part ? part.text : '[Non-text content]').join('\n')}
              </p>
              <p className="text-xs opacity-60 mt-1 text-right">{new Date(msg.timestamp).toLocaleTimeString()}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="max-w-[85%] p-3 rounded-xl shadow-md bg-purple-600 text-white rounded-bl-none flex items-center">
              <Icon name="Loader2" size={16} className="animate-spin mr-2" /> 
              <span className="text-sm italic">AI is thinking...</span>
            </div>
          </div>
        )}
      </div>
      <div className="flex items-center space-x-2 pt-2 border-t border-slate-700">
        <textarea
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !isLoading) {
              e.preventDefault();
              handleSendMessage();
            }
          }}
          placeholder="Type your message or prompt here..."
          rows={2}
          className="flex-grow p-2.5 bg-slate-700 border border-slate-600 rounded-lg text-sm text-slate-100 placeholder-slate-400 focus:ring-1 focus:ring-purple-500 outline-none resize-none custom-scrollbar"
          disabled={isLoading}
          aria-label="Chat input"
        />
        <button
          onClick={handleSendMessage}
          disabled={isLoading || !userInput.trim()}
          className="p-3 bg-purple-600 hover:bg-purple-500 text-white rounded-lg disabled:opacity-60 transition-colors flex items-center justify-center aspect-square"
          aria-label="Send message"
        >
          {isLoading ? <Icon name="Loader2" size={18} className="animate-spin" /> : <Icon name="Send" size={18} />}
        </button>
      </div>
    </div>
  );
};

export default ChatInteraction;