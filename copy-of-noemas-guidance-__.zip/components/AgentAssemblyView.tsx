
import React, { useState, useCallback, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { AgentComponentDefinition, AgentSlotDefinition, AssembledAgentComponent, AgentComponentType, QuestStep, SocraticContext } from '../types.ts'; 
import { Loader2 } from 'lucide-react';

const ComponentCard: React.FC<{ component: AgentComponentDefinition; isDraggable: boolean; onDragStart?: (e: React.DragEvent<HTMLDivElement>, componentId: string) => void }> = ({ component, isDraggable, onDragStart }) => {
  return (
    <div
      id={`component-${component.id}`}
      draggable={isDraggable}
      onDragStart={isDraggable && onDragStart ? (e) => onDragStart(e, component.id) : undefined}
      className={`p-3 mb-2 border rounded-lg shadow-sm cursor-grab active:cursor-grabbing flex items-center space-x-2
                  ${component.type === 'SENSOR' ? 'bg-sky-700 border-sky-600 hover:bg-sky-600' :
                    component.type === 'DECISION_MODULE' ? 'bg-purple-700 border-purple-600 hover:bg-purple-600' :
                    'bg-green-700 border-green-600 hover:bg-green-600'}`}
    >
      <Icon name={component.icon || 'Puzzle'} size={20} className="text-slate-100" />
      <div>
        <h4 className="font-semibold text-sm text-slate-100">{component.name}</h4>
        <p className="text-xs text-slate-300">{component.description}</p>
      </div>
    </div>
  );
};

const AgentSlot: React.FC<{
  slot: AgentSlotDefinition;
  assembledComponentDef: AgentComponentDefinition | null;
  onDrop: (e: React.DragEvent<HTMLDivElement>, slotId: string) => void;
  onDragOver: (e: React.DragEvent<HTMLDivElement>) => void;
  onRemoveComponent?: (slotId: string) => void;
}> = ({ slot, assembledComponentDef, onDrop, onDragOver, onRemoveComponent }) => {
  return (
    <div
      id={`slot-${slot.id}`}
      onDrop={(e) => onDrop(e, slot.id)}
      onDragOver={onDragOver}
      className="p-4 border-2 border-dashed border-slate-600 rounded-lg min-h-[80px] flex flex-col items-center justify-center text-center bg-slate-800/50 relative group"
      data-slot-id={slot.id}
      data-accepted-type={slot.acceptedType}
    >
      {assembledComponentDef ? (
        <>
          <div className="flex items-center space-x-2">
            <Icon name={assembledComponentDef.icon || 'Puzzle'} size={20} className="text-slate-100" />
            <div>
                <h4 className="font-semibold text-sm text-slate-100">{assembledComponentDef.name}</h4>
                <p className="text-xs text-slate-400">{slot.label}</p>
            </div>
          </div>
          {onRemoveComponent && (
            <button 
              onClick={() => onRemoveComponent(slot.id)} 
              className="absolute top-1 right-1 p-0.5 bg-red-600 hover:bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              title={`Remove ${assembledComponentDef.name}`}
            >
              <Icon name="X" size={12} />
            </button>
          )}
        </>
      ) : (
        <>
          <Icon name={slot.icon || 'PlusSquare'} size={24} className="text-slate-500 mb-1" />
          <p className="text-xs text-slate-500">{slot.label} ({slot.acceptedType})</p>
        </>
      )}
    </div>
  );
};


const AgentAssemblyView: React.FC = () => {
  const { activeStep, triggerSocraticPromptsForSimulation, speak, addToast, completeStep, activeQuest } = useAppContext();
  const config = activeStep?.agentAssemblyConfig;

  const [assembledComponents, setAssembledComponents] = useState<AssembledAgentComponent[]>([]);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const [isLoadingTest, setIsLoadingTest] = useState(false);
  const [isTaskSuccessfullyCompleted, setIsTaskSuccessfullyCompleted] = useState(false);

  const allComponentDefs = useMemo(() => config?.availableComponents || [], [config]);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, componentId: string) => {
    e.dataTransfer.setData("application/noema-component-id", componentId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault(); 
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, slotId: string) => {
    e.preventDefault();
    const componentId = e.dataTransfer.getData("application/noema-component-id");
    const slotElement = e.currentTarget as HTMLDivElement;
    const acceptedType = slotElement.dataset.acceptedType as AgentComponentType;
    
    const componentDef = allComponentDefs.find(c => c.id === componentId);
    if (!componentDef) {
      addToast("Invalid component dragged.", "error");
      return;
    }

    if (componentDef.type !== acceptedType) {
      addToast(`Cannot place ${componentDef.name} (${componentDef.type}) in a ${acceptedType} slot.`, "warning");
      return;
    }
    setIsTaskSuccessfullyCompleted(false); 
    setAssembledComponents(prev => {
      const otherComponents = prev.filter(ac => ac.slotId !== slotId);
      return [...otherComponents, { slotId, componentId }];
    });
    setFeedbackMessage(`${componentDef.name} placed in ${slotId}.`);
    speak(`${componentDef.name} placed.`);
  };
  
  const handleRemoveComponentFromSlot = (slotIdToRemove: string) => {
    const removed = assembledComponents.find(ac => ac.slotId === slotIdToRemove);
    const componentDef = allComponentDefs.find(c => c.id === removed?.componentId);
    setIsTaskSuccessfullyCompleted(false); 
    setAssembledComponents(prev => prev.filter(ac => ac.slotId !== slotIdToRemove));
    if(componentDef) addToast(`${componentDef.name} removed.`, "info");
  };

  const handleTestConfiguration = () => {
    if (!config || !activeStep) return; 
    setIsLoadingTest(true);
    setFeedbackMessage("Testing configuration...");
    // Placeholder for testing logic
    setTimeout(() => {
      setIsLoadingTest(false);
      addToast("Configuration tested (placeholder result).", "info");
    }, 1000);
  };

  // Render logic remains the same, using Icon component correctly.
  if (!config) return <div className="p-4 text-slate-400">Agent Assembly: No configuration loaded.</div>;

  return (
    <div className="flex flex-col md:flex-row h-full p-2 md:p-4 gap-4 bg-slate-800/70 rounded-lg shadow-inner">
      {/* Component Palette */}
      <div className="w-full md:w-1/3 lg:w-1/4 p-3 bg-slate-800 rounded-lg shadow-md overflow-y-auto custom-scrollbar">
        <h3 className="text-md font-semibold text-sky-300 mb-3 border-b border-slate-700 pb-2">Available Components</h3>
        {(Object.keys(allComponentDefs.reduce((acc, curr) => { (acc[curr.type] = acc[curr.type] || []).push(curr); return acc; }, {} as Record<AgentComponentType, AgentComponentDefinition[]>)) as AgentComponentType[]).map(type => (
          <div key={type} className="mb-3">
            <h4 className="text-sm font-medium text-purple-300 mb-1.5">{type}S</h4>
            {allComponentDefs.filter(c => c.type === type).map(comp => (
              <ComponentCard key={comp.id} component={comp} isDraggable={true} onDragStart={handleDragStart} />
            ))}
          </div>
        ))}
      </div>

      {/* Agent Blueprint & Controls */}
      <div className="flex-grow flex flex-col p-3 bg-slate-800 rounded-lg shadow-md">
        <div className="mb-3 border-b border-slate-700 pb-2">
          <h3 className="text-md font-semibold text-sky-300">Agent Blueprint: {config.taskDescription}</h3>
          <p className="text-xs text-slate-400 italic mt-1">{config.environmentDescription}</p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-3 overflow-y-auto custom-scrollbar flex-grow p-1">
          {config.agentSlots.map(slot => {
            const assembled = assembledComponents.find(ac => ac.slotId === slot.id);
            const componentDef = assembled ? allComponentDefs.find(c => c.id === assembled.componentId) : null;
            return (
              <AgentSlot
                key={slot.id}
                slot={slot}
                assembledComponentDef={componentDef || null}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onRemoveComponent={handleRemoveComponentFromSlot}
              />
            );
          })}
        </div>

        {feedbackMessage && <p className="text-xs text-yellow-300 mb-2 p-2 bg-yellow-800/30 rounded">{feedbackMessage}</p>}
        
        <button
          onClick={handleTestConfiguration}
          disabled={isLoadingTest || isTaskSuccessfullyCompleted}
          className="w-full mt-auto p-2.5 bg-green-600 hover:bg-green-500 text-white font-medium rounded-lg shadow-md disabled:opacity-60 transition-colors flex items-center justify-center"
        >
          {isLoadingTest ? <Loader2 size={20} className="animate-spin mr-2" /> : <Icon name="Zap" size={18} className="mr-2" />}
          {isTaskSuccessfullyCompleted ? "Task Completed!" : "Test Configuration"}
        </button>
      </div>
    </div>
  );
};

export default AgentAssemblyView;
