
import React from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { AppView, IconName } from '../types.ts';

const Header: React.FC = () => {
  const { currentView, setCurrentView, userProgress, toggleTTS, isTTSEnabled } = useAppContext();

  const navItems: { id: AppView; label: string; icon: IconName }[] = [
    { id: 'quest_log', label: 'Quests', icon: 'ListChecks' },
    { id: 'agent_academy_log', label: 'Agent Academy', icon: 'Network' },
    { id: 'nexus', label: 'Nexus', icon: 'BookOpen' },
    { id: 'library', label: 'Library', icon: 'Library' },
    { id: 'story_forge', label: 'Story Forge', icon: 'Feather' },
    { id: 'agent_orchestrator_sandbox', label: 'Orchestrator', icon: 'Workflow' },
    { id: 'workshop', label: 'Workshop', icon: 'Sparkles' }, 
    { id: 'notebook', label: 'Notebook', icon: 'NotebookText' },
    { id: 'story_vault', label: 'Vault', icon: 'Archive' },
  ];

  if (!userProgress) return null;

  return (
    <header className="fixed top-0 left-0 right-0 bg-slate-800/80 backdrop-blur-md shadow-lg p-3 flex justify-between items-center z-50 h-16 border-b border-slate-700">
      <div className="flex items-center">
        <Icon name="Bot" size={28} className="text-sky-400 mr-2 flex-shrink-0" />
        <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-500 hidden sm:block">
          Noema's Guidance
        </h1>
      </div>
      <nav className="flex items-center space-x-1 md:space-x-0"> {/* Reduced space for more items */}
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={`px-1.5 py-2 md:px-2.5 rounded-md text-xs md:text-sm font-medium transition-colors duration-150 flex items-center space-x-1 md:space-x-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500
              ${currentView === item.id ? 'bg-sky-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}
            title={item.label}
          >
            <Icon name={item.icon as IconName} size={16} className="flex-shrink-0 md:size-18" /> {/* Adjusted icon size for md */}
            <span className="hidden md:inline">{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="flex items-center space-x-2 md:space-x-3">
        <div className="text-xs md:text-sm text-slate-400 flex items-center">
          <Icon name="UserCircle" size={18} className="mr-1 text-sky-400 flex-shrink-0" />
          <span className="truncate max-w-[50px] md:max-w-[100px]">{userProgress.displayName}</span>
          <span className="mx-1 text-slate-600">|</span>
          <Icon name="Zap" size={16} className="mr-1 text-yellow-400 flex-shrink-0" />
          <span>{userProgress.xp} XP</span>
        </div>
        <button
            onClick={toggleTTS}
            title={isTTSEnabled ? "Disable Text-to-Speech" : "Enable Text-to-Speech"}
            className="p-2 rounded-full hover:bg-slate-700 transition-colors text-slate-300 hover:text-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
        >
            <Icon name={isTTSEnabled ? "Volume2" : "VolumeX"} size={20} />
        </button>
      </div>
    </header>
  );
};

export default Header;
