
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { UserProgressData, ChatMessage, TextPart, ImagePart, PromptItem, SavedAiResponse, StoryForgeSession, NotebookEntry, ToastMessage, StoryForgeLoreCategory, WorkshopMode, ChatMessagePart, VaultStory, IconName, AvailableTools, ToolDefinition, ScenarioOutput, StoryboardPrompt, OrchestratorWorkflow, OrchestratorComponentDefinition, OrchestratorActionPayload } from '../types.ts';
import * as geminiService from '../services/geminiService.ts';
import {
  ImageIcon as LucideImageIcon, Sparkles as LucideSparkles, Save as LucideSave, TextQuote as LucideTextQuote, AlertTriangle as LucideAlertTriangle, Info as LucideInfo, Star as LucideStar, BookOpen as LucideBookOpen,
  BrainCircuit as LucideBrainCircuit, X as LucideX, MessageSquare as LucideMessageSquare, Feather as LucideFeather, Users as LucideUsers, MapPin as LucideMapPin, MessageCircleQuestion as LucideMessageCircleQuestion, PlusCircle as LucidePlusCircle,
  Wand2 as LucideWand2, Edit as LucideEdit, Trash2 as LucideTrash2, Scale as LucideScale, ThumbsUp as LucideThumbsUp, ThumbsDown as LucideThumbsDown, Lightbulb as LucideLightbulb, FlaskConical as LucideFlaskConical, Combine as LucideCombine, Zap as LucideZap, Shuffle as LucideShuffle,
  Flame as LucideFlame, Droplets as LucideDroplets, BookOpenText as LucideBookOpenText, Globe as LucideGlobe, FilePlus2 as LucideFilePlus2, GitFork as LucideGitFork, Archive as LucideArchive, BotMessageSquare as LucideBotMessageSquare, Square as LucideSquare, PenLine as LucidePenLine, HelpCircle as LucideHelpCircle,
  PlayCircle as LucidePlayCircle, StopCircle as LucideStopCircle, FastForward as LucideFastForward, SearchCheck as LucideSearchCheck, Palette as LucidePalette, Bot as LucideBot, ClipboardCopy as LucideClipboardCopy, PlusSquare as LucidePlusSquare, Wrench as LucideWrench, TerminalSquare as LucideTerminalSquare,
  Microscope as LucideMicroscope, TestTube2 as LucideTestTube2, ImagePlay as LucideImagePlay, Workflow as LucideWorkflow, MessageCircleMore as LucideMessageCircleMore, Loader2, Send
} from 'lucide-react';
import { MAX_CHAT_HISTORY_FOR_CONTEXT, PREDEFINED_TOOLS, ORCHESTRATOR_COMPONENT_DEFS } from '../constants.ts';
import { useAppContext } from '../contexts/AppContext.tsx';
import { Icon } from './Icon.tsx';
import { AgentOrchestratorView } from './AgentOrchestratorView.tsx';
import { NoemasGuidanceConsole } from './NoemasGuidanceConsole.tsx';
import StoryForgeView from './StoryForgeView.tsx';

interface StoryExplorationTool {
    id: string;
    name: string;
    icon: IconName;
    description: string;
    action: () => void;
    isImplemented: boolean;
    inputPrompt?: string;
}


interface NoemasWorkshopViewProps {
  speakMessage: (text: string, force?: boolean) => void;
  addToast: (message: string, type?: ToastMessage['type'], duration?: number) => void;
  userProgress: UserProgressData;
  updateUserProgress: (updates: Partial<UserProgressData>) => void;
  onSavePrompt: (promptData: Omit<PromptItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onSaveAiResponse: (aiMessage: ChatMessage, userPrompt?: ChatMessage) => void;
  storyForgeSessions: StoryForgeSession[];
  onUpdateStoryForgeSessions: (sessions: StoryForgeSession[], updatedSession?: StoryForgeSession) => void;
  onSaveToNotebook: (entry: Omit<NotebookEntry, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

const ALL_WORKSHOP_MODES: { id: WorkshopMode; label: string; icon: IconName; description: string }[] = [
  { id: 'story_forge', label: 'Story Forge', icon: 'Feather', description: 'Collaboratively write stories with AI assistance.' },
  { id: 'agent_orchestrator_sandbox', label: 'Orchestrator', icon: 'Workflow', description: 'Design and test AI agent workflows.' },
  { id: 'chat', label: 'Chat', icon: 'MessageSquare', description: 'Engage in general conversation with an AI.' },
  { id: 'image', label: 'Image Gen', icon: 'ImageIcon', description: 'Create images from text prompts.' },
  { id: 'tool_master', label: 'Tool Master', icon: 'Wrench', description: 'Experiment with AI using external tools.' },
  { id: 'debate_arena', label: 'Debate Arena', icon: 'Users', description: 'Explore different perspectives on various topics.' },
  { id: 'feedback_coach', label: 'Feedback Coach', icon: 'ThumbsUp', description: 'Learn to provide effective feedback to AI.' },
];


export const NoemasWorkshopView: React.FC<NoemasWorkshopViewProps> = ({
  speakMessage,
  addToast,
  userProgress,
  updateUserProgress, // Prop is now destructured, though potentially unused directly in this component
  onSavePrompt,       // Prop is now destructured, though potentially unused directly in this component
  onSaveAiResponse,   // Prop is now destructured, though potentially unused directly in this component
  storyForgeSessions,
  onUpdateStoryForgeSessions,
  onSaveToNotebook
}) => {
  const {
    // speak, // Using prop speakMessage instead
    // addToast: contextAddToast, // Using prop addToast instead
    showModal,
    hideModal,
    activeQuest,
    activeStep,
    selectedOrchestratorInstanceId: globalSelectedInstanceId,
    activeWorkshopMode,
    setActiveWorkshopMode: setContextActiveWorkshopMode,
    setOrchestratorWorkflowForContext,
    currentView,
    inputValue,
    setInputValue,
  } = useAppContext();

  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const [isGuidanceConsoleOpen, setIsGuidanceConsoleOpen] = useState(true);
  const [activeSelectedComponentDefIdForConsole, setActiveSelectedComponentDefIdForConsole] = useState<string | undefined>(undefined);
  const [activeSelectedInstanceErrorForConsole, setActiveSelectedInstanceErrorForConsole] = useState<string | undefined>(undefined);
  const [currentOrchestratorWorkflowForConsole, setCurrentOrchestratorWorkflowForConsole] = useState<OrchestratorWorkflow | null>(null);

  const orchestratorActionHandlerRef = useRef<((action: OrchestratorActionPayload) => void) | null>(null);


  const [activeStorySession, setActiveStorySession] = useState<StoryForgeSession | null>(null);

  useEffect(() => {
    if (currentView === 'workshop' && !activeWorkshopMode) {
        setContextActiveWorkshopMode('chat');
    }
  }, [currentView, activeWorkshopMode, setContextActiveWorkshopMode]);

  useEffect(() => {
    if (inputValue && (activeWorkshopMode === 'chat' || activeWorkshopMode === 'image' || activeWorkshopMode === 'tool_master')) {
        setUserInput(inputValue);
        setInputValue('');
        addToast("Prompt loaded into input field.", "info");
    }
  }, [inputValue, activeWorkshopMode, setInputValue, addToast]);


  useEffect(() => {
    const sessionIdToLoad = localStorage.getItem('storyforge_load_session_id');
    const targetMode = localStorage.getItem('storyforge_target_mode');

    if (sessionIdToLoad && targetMode === 'story_forge' && activeWorkshopMode === 'story_forge') {
      const session = storyForgeSessions.find(s => s.id === sessionIdToLoad);
      if (session) {
        setActiveStorySession(session);
      } else {
        addToast(`Could not find story session ID: ${sessionIdToLoad} to load.`, 'error');
      }
      localStorage.removeItem('storyforge_load_session_id');
      localStorage.removeItem('storyforge_target_mode');
    } else if (activeWorkshopMode !== 'story_forge') {
        setActiveStorySession(null);
    }
  }, [storyForgeSessions, addToast, activeWorkshopMode]);

  useEffect(() => {
    if (activeWorkshopMode === 'agent_orchestrator_sandbox' && isGuidanceConsoleOpen) {
      console.log("NoemasWorkshopView: Passing to Console -> activeSelectedInstanceId (from context):", globalSelectedInstanceId, "currentWorkflow instance count:", currentOrchestratorWorkflowForConsole?.instances.length);
    }
  }, [globalSelectedInstanceId, currentOrchestratorWorkflowForConsole, activeWorkshopMode, isGuidanceConsoleOpen]);

  const handleInternalModeChange = (newMode: WorkshopMode) => {
    if (currentView === 'workshop') {
        setContextActiveWorkshopMode(newMode);
        setUserInput('');
        speakMessage(`Switched to ${ALL_WORKSHOP_MODES.find(m => m.id === newMode)?.label || newMode} mode.`);
        if (newMode !== 'agent_orchestrator_sandbox') {
            setActiveSelectedComponentDefIdForConsole(undefined);
            setActiveSelectedInstanceErrorForConsole(undefined);
            setCurrentOrchestratorWorkflowForConsole(null);
            setOrchestratorWorkflowForContext(null);
        }
    } else {
        const { setCurrentView: globalSetCurrentView } = useAppContext();
        if (newMode === 'story_forge') globalSetCurrentView('story_forge');
        else if (newMode === 'agent_orchestrator_sandbox') globalSetCurrentView('agent_orchestrator_sandbox');
        else {
            globalSetCurrentView('workshop');
            setContextActiveWorkshopMode(newMode); 
        }
    }
  };

  const handleComponentSelectionChangeOrchestrator = useCallback((selectedDefId: string | null, selectedInstanceId: string | null) => {
    setActiveSelectedComponentDefIdForConsole(selectedDefId || undefined);
  }, []);

  const handleWorkflowChangeOrchestrator = useCallback((workflow: OrchestratorWorkflow) => {
    setCurrentOrchestratorWorkflowForConsole(workflow);
    setOrchestratorWorkflowForContext(workflow);
  }, [setOrchestratorWorkflowForContext]);

  const handleSelectedInstanceErrorChangeOrchestrator = useCallback((errorMessage: string | null) => {
      setActiveSelectedInstanceErrorForConsole(errorMessage || undefined);
  }, []);

  const handlePerformOrchestratorAction = useCallback((action: OrchestratorActionPayload) => {
    if (orchestratorActionHandlerRef.current) {
        orchestratorActionHandlerRef.current(action);
    } else {
        addToast("Orchestrator action request could not be processed at this moment.", "warning");
    }
  }, [addToast]);


  const handleSaveStorySession = (session: StoryForgeSession) => {
    const existingSessionIndex = storyForgeSessions.findIndex(s => s.id === session.id);
    let newSessions;
    if (existingSessionIndex > -1) {
      newSessions = storyForgeSessions.map((s, index) => index === existingSessionIndex ? session : s);
    } else {
      newSessions = [session, ...storyForgeSessions];
    }
    onUpdateStoryForgeSessions(newSessions, session);
    setActiveStorySession(session);
  };

  const handleCreateNewStory = () => {
    const newSession: StoryForgeSession = {
      id: `story_${Date.now()}_${Math.random().toString(16).slice(2)}`,
      title: "Untitled Story",
      fullStory: [],
      loreNotes: {},
      lastUpdated: new Date().toISOString(),
    };
    onUpdateStoryForgeSessions([newSession, ...storyForgeSessions], newSession);
    setActiveStorySession(newSession);
  };

  const renderModeContent = () => {
    switch (activeWorkshopMode) {
      case 'agent_orchestrator_sandbox':
        return (
          <AgentOrchestratorView
            isExplicitSandbox={true}
            onComponentSelectionChange={handleComponentSelectionChangeOrchestrator}
            onWorkflowChange={handleWorkflowChangeOrchestrator}
            onSelectedInstanceErrorChange={handleSelectedInstanceErrorChangeOrchestrator}
            requestOrchestratorActionFromConsoleRef={orchestratorActionHandlerRef}
          />
        );
      case 'story_forge':
        return (
          <StoryForgeView
            activeSession={activeStorySession}
            onSaveSession={handleSaveStorySession}
            onCreateNewStory={handleCreateNewStory}
            speakMessage={speakMessage} // Pass prop
            addToast={addToast}         // Pass prop
            onSaveToNotebook={onSaveToNotebook}
            allSessions={storyForgeSessions}
            onLoadSession={(sessionId) => {
                const sessionToLoad = storyForgeSessions.find(s => s.id === sessionId);
                if (sessionToLoad) setActiveStorySession(sessionToLoad);
            }}
          />
        );
      case 'chat':
        return "Chat Mode Placeholder Active";
      case 'image':
        return "Image Gen Mode Placeholder Active";
      case 'tool_master':
        return "Tool Master Mode Placeholder Active";
      case 'debate_arena':
        return "Debate Arena Mode Placeholder Active";
      case 'feedback_coach':
        return "Feedback Coach Mode Placeholder Active";
      default:
        if (activeWorkshopMode) {
          return `${ALL_WORKSHOP_MODES.find(m=>m.id === activeWorkshopMode)?.label || activeWorkshopMode} Mode Placeholder.`;
        }
        return "Select a workshop mode to begin.";
    }
  };

  // Ensure global input is hidden for all general workshop modes
  const showGlobalInputForMode: WorkshopMode[] = [];

  // This is the main return for the NoemasWorkshopView component.
  // If TypeScript infers this component's return type as 'void', it implies this 'return' statement
  // is somehow not being recognized or there's a syntax error preventing proper parsing.
  // The code structure appears correct.
  return (
    <div className="p-3 md:p-4 h-full flex flex-col bg-slate-800 text-slate-100">
      <div className="mb-4 pb-3 border-b border-slate-700">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-sky-300 flex items-center">
            <Icon name="Sparkles" size={24} className="mr-2 text-yellow-400"/>
            Noema's Workshop
          </h1>
          {(activeWorkshopMode === 'agent_orchestrator_sandbox' || activeWorkshopMode === 'story_forge') && (
             <button
                onClick={() => setIsGuidanceConsoleOpen(prev => !prev)}
                className="p-2 bg-slate-700 hover:bg-slate-600 rounded-md text-xs text-slate-200 flex items-center"
                title={isGuidanceConsoleOpen ? "Hide Guidance Console" : "Show Guidance Console"}
                aria-expanded={isGuidanceConsoleOpen}
            >
                <Icon name="MessageCircleMore" size={16} className="mr-1.5"/>
                {isGuidanceConsoleOpen ? "Hide Guide" : "Show Guide"}
            </button>
          )}
        </div>
        <p className="text-sm text-slate-400 mt-1">Select a mode to begin your creative exploration or agent design.</p>
      </div>

      <div className="mb-3 flex flex-wrap gap-2 p-2 bg-slate-800/50 rounded-md border border-slate-700 items-center">
        <span className="text-xs text-slate-400 mr-2 hidden sm:inline">Modes:</span>
        {ALL_WORKSHOP_MODES.map(m => (
          <button
            key={m.id}
            onClick={() => handleInternalModeChange(m.id)}
            className={`px-2.5 py-1.5 text-xs rounded-md flex items-center transition-colors
                        ${activeWorkshopMode === m.id ? 'bg-sky-600 text-white shadow-md' : 'bg-slate-700 hover:bg-slate-600 text-slate-300'}`}
            title={m.description}
          >
            <Icon name={m.icon} size={14} className="mr-1.5" />
            {m.label}
          </button>
        ))}
      </div>

      <div className="flex-grow overflow-hidden flex relative">
        <div className={`flex-grow overflow-auto custom-scrollbar ${isGuidanceConsoleOpen && (activeWorkshopMode === 'agent_orchestrator_sandbox' || activeWorkshopMode === 'story_forge') ? 'md:w-2/3' : 'w-full'}`}>
            <div className="p-4 text-center text-slate-300">
                {renderModeContent()}
            </div>
        </div>
        {(activeWorkshopMode === 'agent_orchestrator_sandbox' || activeWorkshopMode === 'story_forge') && (
          <NoemasGuidanceConsole
            isOpen={isGuidanceConsoleOpen}
            onToggleOpen={() => setIsGuidanceConsoleOpen(prev => !prev)}
            activeSelectedComponentDefId={activeSelectedComponentDefIdForConsole}
            activeSelectedInstanceId={globalSelectedInstanceId}
            activeSelectedInstanceError={activeSelectedInstanceErrorForConsole}
            currentWorkflow={currentOrchestratorWorkflowForConsole}
            activeQuest={activeQuest}
            activeStepId={activeStep?.id}
            onPerformOrchestratorAction={handlePerformOrchestratorAction}
          />
        )}
      </div>

      {activeWorkshopMode && showGlobalInputForMode.includes(activeWorkshopMode) && (
        <div className="mt-3 pt-3 border-t border-slate-700">
          <textarea
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            placeholder={`Enter input for ${ALL_WORKSHOP_MODES.find(m=>m.id === activeWorkshopMode)?.label || activeWorkshopMode}...`}
            className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 custom-scrollbar text-sm"
            rows={2}
            disabled={isLoading}
          />
          <button
            onClick={async () => {
                if (activeWorkshopMode === 'chat' || activeWorkshopMode === 'image') {
                     addToast(`Input submitted for ${activeWorkshopMode}: "${userInput.substring(0,30)}..." This mode's full interaction is pending.`, "info");
                } else {
                    addToast(`Input submitted for ${activeWorkshopMode}: "${userInput.substring(0,30)}..."`, "info");
                }
            }}
            disabled={isLoading || !userInput.trim()}
            className="mt-2 w-full p-2 bg-green-600 hover:bg-green-500 text-white rounded-md disabled:opacity-50 flex items-center justify-center text-sm"
          >
            {isLoading ? "Loading..." : "Submit"}
          </button>
        </div>
      )}
    </div>
  );
};
