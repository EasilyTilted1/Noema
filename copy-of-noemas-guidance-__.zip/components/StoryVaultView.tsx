
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { VaultStory, StoryForgeSession, IconName } from '../types.ts'; 

const StoryVaultView: React.FC = () => {
  const { userProgress, loadSessionToWorkshop, showModal, hideModal, deleteVaultStoryEntry, removeSessionFromVault, updateVaultStoryMeta } = useAppContext();
  const [expandedVaults, setExpandedVaults] = useState<Record<string, boolean>>({});
  const [editingVault, setEditingVault] = useState<VaultStory | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");

  const storyVaultEntries = useMemo(() => {
    return (userProgress?.storyVault || []).sort((a, b) => b.lastModified - a.lastModified);
  }, [userProgress?.storyVault]);

  const getSessionsForVault = (vaultEntry: VaultStory): StoryForgeSession[] => {
    if (!userProgress) return [];
    return vaultEntry.versionSessionIds
      .map(id => userProgress.storyForgeSessions.find(s => s.id === id))
      .filter(Boolean) as StoryForgeSession[];
  };

  const toggleExpand = (vaultId: string) => {
    setExpandedVaults(prev => ({ ...prev, [vaultId]: !prev[vaultId] }));
  };
  
  const handleEditVault = (vault: VaultStory) => {
    setEditingVault(vault);
    setEditTitle(vault.title);
    setEditDescription(vault.description || "");
  };

  const handleSaveEditVault = () => {
    if (editingVault) {
      updateVaultStoryMeta(editingVault.id, { title: editTitle, description: editDescription });
      setEditingVault(null);
    }
  };

  const handleDeleteVault = (vaultId: string, title: string) => {
    showModal({
      title: "Delete Story Group?",
      content: <p>Are you sure you want to delete the story group "<strong>{title}</strong>"? This will remove the group, but individual story versions will remain in your main story list unless also deleted from there. This action cannot be undone.</p>,
      confirmText: "Delete Group",
      onConfirm: () => {
        deleteVaultStoryEntry(vaultId);
        hideModal();
      },
      cancelText: "Cancel",
      onCancel: hideModal
    });
  };

  const handleDeleteVersion = (vaultId: string, sessionId: string, sessionTitle: string, vaultTitle: string) => {
     showModal({
      title: "Delete Story Version?",
      content: <p>Are you sure you want to remove the version "<strong>{sessionTitle}</strong>" from the story group "<strong>{vaultTitle}</strong>"? The version will no longer be part of this group. This action cannot be undone.</p>,
      confirmText: "Remove Version",
      onConfirm: () => {
        removeSessionFromVault(vaultId, sessionId);
        hideModal();
      },
      cancelText: "Cancel",
      onCancel: hideModal
    });
  };


  if (!userProgress) return <div className="p-6 text-center text-slate-400">Loading user data...</div>;

  return (
    <div className="p-4 md:p-6 h-full flex flex-col">
      <div className="mb-6 text-center">
        <Icon name="Archive" size={48} className="text-sky-400 mx-auto mb-3" />
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-500">
          Story Vault
        </h1>
        <p className="text-slate-400 mt-1">Manage your story collections and their versions.</p>
      </div>

      {editingVault && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-[150]">
          <div className="bg-slate-800 p-6 rounded-lg shadow-xl w-full max-w-md border border-sky-600">
            <h3 className="text-xl font-semibold text-sky-300 mb-4">Edit Story Group</h3>
            <div className="space-y-3">
              <div>
                <label htmlFor="editVaultTitle" className="block text-sm text-slate-300 mb-1">Group Title</label>
                <input type="text" id="editVaultTitle" value={editTitle} onChange={e => setEditTitle(e.target.value)} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md"/>
              </div>
              <div>
                <label htmlFor="editVaultDesc" className="block text-sm text-slate-300 mb-1">Description (Optional)</label>
                <textarea id="editVaultDesc" value={editDescription} onChange={e => setEditDescription(e.target.value)} rows={3} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md custom-scrollbar"/>
              </div>
            </div>
            <div className="mt-5 flex justify-end space-x-3">
              <button onClick={() => setEditingVault(null)} className="px-4 py-2 bg-slate-600 hover:bg-slate-500 rounded-md">Cancel</button>
              <button onClick={handleSaveEditVault} className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-md">Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {storyVaultEntries.length === 0 && (
        <div className="text-center text-slate-500 py-10 flex-grow flex flex-col items-center justify-center">
          <Icon name="ArchiveX" size={40} className="mx-auto mb-3"/>
          <p>Your Story Vault is empty. Save stories from the Workshop to group them here!</p>
        </div>
      )}

      <div className="flex-grow overflow-y-auto custom-scrollbar pr-1 space-y-4">
        {storyVaultEntries.map(vaultEntry => {
          const versions = getSessionsForVault(vaultEntry);
          const latestVersion = versions.sort((a,b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime())[0];
          
          return (
            <div key={vaultEntry.id} className="bg-slate-800 rounded-lg shadow-lg border border-slate-700">
              <div className="p-4 flex justify-between items-center cursor-pointer hover:bg-slate-700/50" onClick={() => toggleExpand(vaultEntry.id)}>
                <div>
                  <h2 className="text-xl font-semibold text-sky-300">{vaultEntry.title}</h2>
                  <p className="text-xs text-slate-400">
                    {versions.length} version(s) | Last modified: {new Date(vaultEntry.lastModified).toLocaleDateString()}
                  </p>
                  {vaultEntry.description && <p className="text-sm text-slate-300 mt-1 italic line-clamp-1">{vaultEntry.description}</p>}
                </div>
                <div className="flex items-center space-x-2">
                   <button onClick={(e) => { e.stopPropagation(); handleEditVault(vaultEntry); }} className="p-1.5 text-slate-400 hover:text-sky-300" title="Edit Group"><Icon name="Edit3" size={16}/></button>
                   <button onClick={(e) => { e.stopPropagation(); handleDeleteVault(vaultEntry.id, vaultEntry.title); }} className="p-1.5 text-slate-400 hover:text-red-400" title="Delete Group"><Icon name="Trash2" size={16}/></button>
                  <Icon name={expandedVaults[vaultEntry.id] ? "ChevronUp" : "ChevronDown"} size={20} />
                </div>
              </div>
              {expandedVaults[vaultEntry.id] && (
                <div className="border-t border-slate-700 p-3 space-y-2 bg-slate-800/50">
                  {versions.length > 0 ? versions.map(session => (
                    <div key={session.id} className="p-2.5 bg-slate-700 rounded-md flex justify-between items-center hover:bg-slate-600/70">
                      <div>
                        <p className="text-sm text-slate-100 font-medium">
                          {session.title} 
                          {session.id === vaultEntry.baseSessionId && <span className="ml-2 text-xs bg-sky-700 px-1.5 py-0.5 rounded-full">Base</span>}
                        </p>
                        <p className="text-xs text-slate-400">Updated: {new Date(session.lastUpdated).toLocaleString()}</p>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => loadSessionToWorkshop(session.id)} className="p-2 text-xs bg-sky-600 hover:bg-sky-500 text-white rounded-md" title="Load this version to Story Forge">
                          <Icon name="Play" size={14}/>
                        </button>
                         <button onClick={() => handleDeleteVersion(vaultEntry.id, session.id, session.title, vaultEntry.title)} className="p-2 text-xs bg-red-700 hover:bg-red-600 text-white rounded-md" title="Remove this version from group">
                            <Icon name="XCircle" size={14}/>
                        </button>
                      </div>
                    </div>
                  )) : <p className="text-xs text-slate-500 text-center">No versions in this group.</p>}
                  {latestVersion && (
                     <button 
                        onClick={() => {
                            loadSessionToWorkshop(latestVersion.id);
                        }} 
                        className="w-full mt-2 p-2 text-xs bg-purple-600 hover:bg-purple-500 text-white rounded-md"
                     >
                       <Icon name="GitFork" size={14} className="inline mr-1"/> Branch from Latest Version
                     </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StoryVaultView;
