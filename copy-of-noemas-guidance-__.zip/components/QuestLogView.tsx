import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; 
import { Icon } from './Icon.tsx'; 
import { Quest, QuestStep } from '../types.ts'; // Removed IconName as we'll use strings
import { IS_CONTENT_UNLOCKED_FOR_TESTING } from '../constants.ts';
// Removed direct lucide-react imports for: CheckCircle2, Circle, ListChecks, ChevronDown, ChevronRight, Construction, ChevronUp

interface QuestGroup {
  [phase: string]: Quest[];
}

const QuestLogView: React.FC = () => {
  const {
    userProgress,
    quests,
    activeQuest,
    activeStep,
    startQuest,
    speak,
    setUserProgress: setAppContextUserProgress,
    setCurrentView,
  } = useAppContext();

  const mainQuests = useMemo(() => quests.filter(q => q.academy !== 'agentAcademy'), [quests]);
  
  const [expandedQuests, setExpandedQuests] = useState<Record<string, boolean>>(() => {
    if (activeQuest && mainQuests.some(q => q.id === activeQuest.id)) return { [activeQuest.id]: true };
    return {};
  });

  useEffect(() => {
    if (activeQuest && mainQuests.some(q => q.id === activeQuest.id) && !expandedQuests[activeQuest.id]) {
      setExpandedQuests(prev => ({ ...prev, [activeQuest.id!]: true }));
    }
  }, [activeQuest, mainQuests, expandedQuests]);

  const toggleQuestExpansion = (questId: string) => {
    setExpandedQuests(prev => ({ ...prev, [questId]: !prev[questId] }));
  };

  const questsByPhase = useMemo(() => {
    return mainQuests.reduce((acc, quest) => {
      const phase = quest.phase || "Uncategorized Quests";
      if (!acc[phase]) acc[phase] = [];
      acc[phase].push(quest);
      return acc;
    }, {} as QuestGroup);
  }, [mainQuests]);

  const handleStepClick = useCallback((questId: string, stepId: string) => {
    const targetQuest = mainQuests.find(q => q.id === questId);
    const targetStep = targetQuest?.steps.find(s => s.id === stepId);

    if (!targetQuest || !targetStep) return;

    const isStepCompleted = userProgress?.completedQuestSteps[stepId];
    const isCurrentStep = stepId === userProgress?.currentStepId && questId === userProgress?.currentQuestId;
    const isFirstStepOfQuest = targetQuest.steps[0].id === stepId;
    
    let canAccessStep = IS_CONTENT_UNLOCKED_FOR_TESTING || isStepCompleted || isCurrentStep;
    if (!canAccessStep && !isStepCompleted && isFirstStepOfQuest) {
        canAccessStep = true;
    } else if (!canAccessStep && !isStepCompleted && !isFirstStepOfQuest) {
        const stepIndex = targetQuest.steps.findIndex(s => s.id === stepId);
        if (stepIndex > 0) {
            const prevStepId = targetQuest.steps[stepIndex - 1].id;
            if (userProgress?.completedQuestSteps[prevStepId]) {
                canAccessStep = true;
            }
        }
    }

    if (canAccessStep) {
        speak(`Navigating to ${targetStep.title}.`);
        setAppContextUserProgress(prev => {
            if (!prev) return null;
            return { ...prev, currentQuestId: questId, currentStepId: stepId };
        });
        setCurrentView('interaction');
    } else {
        speak(`Please complete previous steps to unlock "${targetStep.title}".`);
    }
  }, [mainQuests, speak, userProgress, setAppContextUserProgress, setCurrentView]);

  if (!userProgress) {
    return <div className="p-6 text-center text-slate-400">Loading user data...</div>;
  }

  return (
    <div className="p-4 md:p-6 h-full flex flex-col bg-slate-900 text-slate-100">
      <div className="mb-6 text-center">
        <Icon name="ListChecks" size={48} className="text-sky-400 mx-auto mb-3" />
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-500">
          Noema's Quests
        </h1>
        <p className="text-slate-400 mt-1">Embark on your learning journey. Select a quest to begin or continue.</p>
      </div>
      
      {mainQuests.length === 0 ? (
         <div className="text-center text-slate-500 py-10 flex-grow flex flex-col items-center justify-center">
            <Icon name="ArchiveX" size={40} className="mx-auto mb-3"/>
            <p>No main quests found.</p>
         </div>
      ) : (
        <div className="flex-grow overflow-y-auto custom-scrollbar pr-1 space-y-4">
          {Object.entries(questsByPhase).map(([phase, phaseQuests]) => (
            <div key={phase} className="bg-slate-800/50 p-3 rounded-lg border border-slate-700">
              <h2 className="text-xl font-semibold text-purple-300 mb-2">{phase}</h2>
              {phaseQuests.map(quest => (
                <div key={quest.id} className="mb-2 last:mb-0">
                  <button
                    onClick={() => toggleQuestExpansion(quest.id)}
                    className={`flex items-center justify-between w-full text-left p-2.5 rounded-md hover:bg-slate-700/70 transition-colors duration-150 focus:outline-none focus:ring-1 focus:ring-sky-500
                      ${quest.id === activeQuest?.id ? 'bg-slate-700' : ''}`}
                    aria-expanded={!!expandedQuests[quest.id]}
                  >
                    <div className="flex items-center">
                      <Icon name={quest.badge.icon} size={20} className="mr-2.5 text-sky-400 flex-shrink-0" />
                      <span className={`font-medium ${quest.id === activeQuest?.id ? 'text-sky-200' : 'text-slate-100'}`}>
                        {quest.title}
                      </span>
                    </div>
                    {expandedQuests[quest.id] ? <Icon name="ChevronUp" size={18} className="text-slate-400"/> : <Icon name="ChevronRight" size={18} className="text-slate-400"/>}
                  </button>
                  {expandedQuests[quest.id] && (
                    <ul className="ml-5 mt-1.5 space-y-1 border-l-2 border-slate-600 pl-4 py-1">
                      {quest.steps.map(step => {
                        const isCompleted = userProgress.completedQuestSteps[step.id];
                        const isCurrent = step.id === activeStep?.id && quest.id === activeQuest?.id;
                        const isClickableForStyle = IS_CONTENT_UNLOCKED_FOR_TESTING || isCompleted || isCurrent || quest.steps.findIndex(s => s.id === step.id) === 0 || (quest.steps.findIndex(s => s.id === step.id) > 0 && userProgress.completedQuestSteps[quest.steps[quest.steps.findIndex(s => s.id === step.id) - 1].id]);

                        let stepIconName: string = 'Circle';
                        let iconColor = 'text-slate-500';
                        if (isCompleted) { stepIconName = 'CheckCircle2'; iconColor = 'text-green-400'; }
                        else if (isCurrent) { stepIconName = 'ListChecks'; iconColor = 'text-sky-300'; }
                        else if (!isClickableForStyle) { stepIconName = 'Construction'; iconColor = 'text-yellow-500';}


                        return (
                          <li key={step.id}>
                            <button
                              onClick={() => handleStepClick(quest.id, step.id)}
                              className={`flex items-center w-full text-left text-sm px-2 py-1.5 rounded transition-colors duration-150 group
                                ${isCurrent ? 'bg-sky-700/70 text-white font-semibold shadow-sm' : 'text-slate-300 hover:bg-slate-600/70'}
                                ${!isClickableForStyle ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}`}
                              disabled={!isClickableForStyle && !IS_CONTENT_UNLOCKED_FOR_TESTING}
                            >
                              <Icon name={stepIconName} size={16} className={`mr-2 flex-shrink-0 ${iconColor}`} />
                              <span className="truncate flex-grow">{step.title}</span>
                              {step.xpAward > 0 && <span className="ml-auto text-xs text-yellow-400 opacity-70 group-hover:opacity-100">+{step.xpAward} XP</span>}
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default QuestLogView;