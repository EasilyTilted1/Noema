import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Icon } from './Icon.tsx';
import { StoryForgeSession, ChatMessage, TextPart, ImagePart, ScenarioOutput, NotebookEntry, ChatMessagePart, ModelConfigOverrides } from '../types.ts';
import * as geminiService from '../services/geminiService.ts';
import { Send, Feather, PlusCircle, TestTube2, BookOpen, Save, MessageSquareDashed } from 'lucide-react'; // Removed Loader2 from here

interface StoryForgeViewProps {
  activeSession: StoryForgeSession | null;
  onSaveSession: (session: StoryForgeSession) => void;
  onCreateNewStory: () => void; // Callback to signal workshop view to create a new blank session object
  speakMessage: (text: string, force?: boolean) => void;
  addToast: (message: string, type?: 'success' | 'error' | 'info' | 'warning', duration?: number) => void;
  onSaveToNotebook: (entryData: Omit<NotebookEntry, 'id' | 'createdAt' | 'updatedAt'>) => void;
  allSessions: StoryForgeSession[];
  onLoadSession: (sessionId: string) => void;
}

// Helper function defined locally
const extractTextFromParts = (parts: ChatMessagePart[]): string => {
  return parts.filter(p => 'text' in p).map(p => (p as TextPart).text).join('\n');
};

const StoryForgeView: React.FC<StoryForgeViewProps> = ({
  activeSession,
  onSaveSession,
  onCreateNewStory,
  speakMessage,
  addToast,
  onSaveToNotebook,
  allSessions,
  onLoadSession
}) => {
  const [currentStory, setCurrentStory] = useState<ChatMessage[]>([]);
  const [storyTitle, setStoryTitle] = useState("Untitled Story");
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingScenario, setIsLoadingScenario] = useState(false);
  const [scenarioConcept, setScenarioConcept] = useState("");
  const [generatedScenario, setGeneratedScenario] = useState<ScenarioOutput | null>(null);
  const [showScenarioInput, setShowScenarioInput] = useState(false);

  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeSession) {
      setCurrentStory(activeSession.fullStory);
      setStoryTitle(activeSession.title);
      setGeneratedScenario(null); // Clear any previous scenario if loading a session
      setShowScenarioInput(false); // Hide scenario input if loading a session
    } else {
      // If no active session, check if there's a temp scenario from Scenario Lab mode
      const tempScenarioJSON = localStorage.getItem('storyforge_temp_scenario');
      const tempConcept = localStorage.getItem('storyforge_temp_concept');
      if (tempScenarioJSON && tempConcept) {
          try {
            const scenario = JSON.parse(tempScenarioJSON) as ScenarioOutput;
            setGeneratedScenario(scenario);
            setScenarioConcept(tempConcept);
            setShowScenarioInput(false); // Scenario is already generated
            localStorage.removeItem('storyforge_temp_scenario');
            localStorage.removeItem('storyforge_temp_concept');
            addToast("Scenario ready to use!", "info");
          } catch(e) { console.error("Error parsing temp scenario", e); }
      } else {
        setCurrentStory([]);
        setStoryTitle("Untitled Story");
        setShowScenarioInput(false); 
      }
    }
  }, [activeSession, addToast]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [currentStory]);

  const handleGenerateScenario = async () => {
    if (!scenarioConcept.trim()) {
      addToast("Please enter a concept for your scenario.", "warning");
      return;
    }
    setIsLoadingScenario(true);
    setGeneratedScenario(null);
    try {
      const scenario = await geminiService.generateScenarioFromConcept(scenarioConcept.trim());
      if (scenario) {
        setGeneratedScenario(scenario);
        addToast("Scenario generated!", "success");
        speakMessage("I've generated a scenario for you. Review it and decide if you want to use it to start your story.");
      } else {
        addToast("Failed to generate scenario. Please try again.", "error");
      }
    } catch (error: any) {
      addToast(`Error generating scenario: ${error.message}`, "error");
    } finally {
      setIsLoadingScenario(false);
    }
  };

  const handleUseScenario = () => {
    if (!generatedScenario) return;
    onCreateNewStory(); // This will create a new session object in the parent
    setStoryTitle(generatedScenario.titleSuggestion || "Story from Scenario");
    
    const initialMessages: ChatMessage[] = [];
    initialMessages.push({
        id: crypto.randomUUID(), role: 'noema', parts: [{ text: `Starting story based on scenario: "${generatedScenario.titleSuggestion}"` }], timestamp: Date.now()
    });
    initialMessages.push({
        id: crypto.randomUUID(), role: 'noema', parts: [{ text: `Key Elements: ${generatedScenario.keyElementsAndCharacters.join(', ')}` }], timestamp: Date.now()
    });
    initialMessages.push({
        id: crypto.randomUUID(), role: 'noema', parts: [{ text: `Plot Points: ${generatedScenario.potentialPlotPoints.join('; ')}` }], timestamp: Date.now()
    });
    if (generatedScenario.dialogueSnippet) {
         initialMessages.push({
            id: crypto.randomUUID(), role: 'noema', parts: [{ text: `Opening Dialogue Snippet:\n${generatedScenario.dialogueSnippet}` }], timestamp: Date.now()
        });
    }
    setCurrentStory(initialMessages);

    // Save this initial state as part of the new session
    // The actual saving to userProgress will happen on first interaction or explicit save button click
    // The parent's `activeSession` will be updated by `onCreateNewStory` and then by `onSaveSession`
    
    addToast(`Started story with scenario: "${generatedScenario.titleSuggestion}"`, "success");
    setGeneratedScenario(null);
    setScenarioConcept("");
    setShowScenarioInput(false);
  };

  const handleStartBlankStory = () => {
      onCreateNewStory(); // This sets up a new blank session in the parent
      setCurrentStory([]); // Clear local story
      setStoryTitle("Untitled Story"); // Reset local title
      setGeneratedScenario(null);
      setScenarioConcept("");
      setShowScenarioInput(false);
      addToast("Blank story started. Write your first lines!", "info");
  };

  const handleContinueStory = async (instruction?: "continue_normal" | "incorporate_twist", twistIdea?: string) => {
    if (!activeSession) {
        addToast("Please start or load a story first.", "warning");
        return;
    }
    setIsLoading(true);
    
    const userPromptMessage: ChatMessage | undefined = userInput.trim() ? {
        id: crypto.randomUUID(), role: 'user', parts: [{text: userInput.trim()}], timestamp: Date.now()
    } : undefined;

    let storyToContinueFrom = [...currentStory];
    if (userPromptMessage) {
        storyToContinueFrom.push(userPromptMessage);
        setCurrentStory(prev => [...prev, userPromptMessage]);
    }
    setUserInput("");

    try {
      const loreSummary = "Relevant lore items: " + Object.entries(activeSession.loreNotes || {})
        .map(([category, items]) => `${category}: ${items?.join(', ')}`)
        .join('; ')
        .substring(0, 500); // Truncate if too long

      const aiResponseText = await geminiService.generateAiChapter(
        storyToContinueFrom, 
        loreSummary,
        storyTitle,
        instruction || "continue_normal",
        twistIdea
      );
      
      const aiMessage: ChatMessage = { id: crypto.randomUUID(), role: 'model', parts: [{ text: aiResponseText }], timestamp: Date.now() };
      setCurrentStory(prev => [...prev, aiMessage]);
      speakMessage(aiResponseText.length < 150 ? aiResponseText : "Noema has continued the story.");

      // Auto-save after AI response
      const updatedSession = { ...activeSession, title: storyTitle, fullStory: [...storyToContinueFrom, aiMessage], lastUpdated: new Date().toISOString() };
      onSaveSession(updatedSession);

    } catch (error: any) {
      addToast(`Error generating story: ${error.message}`, "error");
      setCurrentStory(prev => [...prev, { id: crypto.randomUUID(), role: 'system', parts: [{ text: `Error: ${error.message}` }], timestamp: Date.now(), isError: true }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveCurrentStory = () => {
    if (!activeSession) {
        addToast("No active story to save.", "warning");
        return;
    }
    const updatedSession: StoryForgeSession = {
      ...activeSession,
      title: storyTitle,
      fullStory: currentStory,
      lastUpdated: new Date().toISOString(),
      // Lore notes and visuals would be managed by more specific UI elements not yet built
    };
    onSaveSession(updatedSession);
  };

  if (!activeSession && !generatedScenario && !showScenarioInput) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 bg-slate-800/50 rounded-lg">
        <Icon name="Feather" size={64} className="text-purple-400 mb-6 opacity-70" />
        <h2 className="text-2xl font-semibold text-slate-100 mb-4">Story Forge</h2>
        <p className="text-slate-300 mb-6 text-center">Craft your narrative with AI assistance.</p>
        <div className="space-y-3 w-full max-w-sm">
          <button onClick={handleStartBlankStory} className="w-full p-3 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-medium flex items-center justify-center text-sm">
            <Icon name="PlusCircle" size={18} className="mr-2" /> Start Blank Story
          </button>
          <button onClick={() => setShowScenarioInput(true)} className="w-full p-3 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-medium flex items-center justify-center text-sm">
            <Icon name="TestTube2" size={18} className="mr-2" /> Generate Scenario to Start
          </button>
        </div>
         {allSessions.length > 0 && (
            <div className="mt-8 w-full max-w-sm">
                <h3 className="text-slate-300 mb-2 text-center">Or load an existing story:</h3>
                <select 
                    onChange={(e) => e.target.value && onLoadSession(e.target.value)} 
                    className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 custom-scrollbar"
                    defaultValue=""
                >
                    <option value="" disabled>Select a story...</option>
                    {allSessions.map(s => <option key={s.id} value={s.id}>{s.title} (Updated: {new Date(s.lastUpdated).toLocaleDateString()})</option>)}
                </select>
            </div>
        )}
      </div>
    );
  }
  
  if (showScenarioInput && !generatedScenario) {
      return (
          <div className="p-4 text-center flex-grow flex flex-col items-center justify-center">
              <Icon name="TestTube2" size={48} className="mx-auto mb-4 text-teal-400 opacity-80" />
              <h3 className="text-xl font-semibold text-slate-100 mb-3">Generate Scenario</h3>
              <p className="text-slate-300 mb-4 text-sm max-w-md">Enter a core concept, theme, or basic idea, and Noema will help you generate a scenario outline to kickstart your story.</p>
              <textarea
                  value={scenarioConcept}
                  onChange={(e) => setScenarioConcept(e.target.value)}
                  placeholder="e.g., A detective investigating a series of impossible thefts in a city powered by sentient crystals."
                  className="w-full max-w-lg p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 custom-scrollbar text-sm mb-3"
                  rows={3}
                  disabled={isLoadingScenario}
              />
              <div className="flex space-x-3">
                <button onClick={() => {setShowScenarioInput(false); setScenarioConcept('');}} disabled={isLoadingScenario} className="p-2 px-4 bg-slate-600 hover:bg-slate-500 text-white rounded-md text-sm">Cancel</button>
                <button onClick={handleGenerateScenario} disabled={isLoadingScenario || !scenarioConcept.trim()} className="p-2 px-4 bg-teal-600 hover:bg-teal-500 text-white rounded-md disabled:opacity-50 flex items-center text-sm">
                    {isLoadingScenario ? <Icon name="Loader2" size={18} className="animate-spin mr-2" /> : <Icon name="Sparkles" size={16} className="mr-2" />}
                    Generate
                </button>
              </div>
          </div>
      );
  }

  if (generatedScenario) {
    return (
      <div className="p-4 flex-grow flex flex-col items-center justify-center bg-slate-800/70 rounded-lg">
        <Icon name="ScrollText" size={48} className="mx-auto mb-4 text-teal-400 opacity-90" />
        <h3 className="text-xl font-semibold text-slate-100 mb-3">Scenario Ready: "{generatedScenario.titleSuggestion}"</h3>
        <div className="text-sm text-slate-300 bg-slate-700/50 p-3 rounded-md max-w-lg w-full max-h-60 overflow-y-auto custom-scrollbar mb-4 space-y-1">
          <p><strong>Key Elements:</strong> {generatedScenario.keyElementsAndCharacters.join(', ')}</p>
          <p><strong>Plot Points:</strong> {generatedScenario.potentialPlotPoints.join('; ')}</p>
          <p><strong>Atmosphere:</strong> {generatedScenario.atmosphericDescriptors.join(', ')}</p>
          <p className="whitespace-pre-wrap"><strong>Dialogue Snippet:</strong>\n{generatedScenario.dialogueSnippet}</p>
        </div>
        <div className="flex space-x-3">
            <button onClick={() => { setGeneratedScenario(null); setScenarioConcept(''); setShowScenarioInput(true);}} className="p-2 px-4 bg-slate-600 hover:bg-slate-500 text-white rounded-md text-sm">Back to Concept</button>
            <button onClick={handleUseScenario} className="p-2 px-4 bg-green-600 hover:bg-green-500 text-white rounded-md flex items-center text-sm">
                <Icon name="PlayCircle" size={16} className="mr-2" /> Use this Scenario
            </button>
        </div>
      </div>
    );
  }

  // Main Story Writing UI
  return (
    <div className="flex flex-col h-full p-1">
      <div className="mb-2 flex items-center justify-between">
        <input 
            type="text"
            value={storyTitle}
            onChange={(e) => setStoryTitle(e.target.value)}
            className="text-xl font-semibold bg-transparent text-sky-300 border-b-2 border-slate-700 focus:border-sky-500 outline-none w-1/2"
            placeholder="Story Title"
        />
        <button onClick={handleSaveCurrentStory} disabled={isLoading} className="p-2 bg-green-600 hover:bg-green-700 text-white rounded-md text-xs flex items-center">
            <Icon name="Save" size={14} className="mr-1.5"/> Save Story
        </button>
      </div>
      <div ref={chatContainerRef} className="flex-grow overflow-y-auto mb-2 space-y-3 custom-scrollbar pr-2 bg-slate-800/30 p-2 rounded-md border border-slate-700">
        {currentStory.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[90%] p-2.5 rounded-lg shadow-sm text-sm ${
              msg.role === 'user' ? 'bg-sky-700 text-slate-50' :
              msg.role === 'model' || msg.role === 'noema' ? 'bg-purple-700 text-slate-50' :
              'bg-red-700 text-red-100' // System error
            }`}>
              <p className="whitespace-pre-wrap break-words">{extractTextFromParts(msg.parts)}</p>
            </div>
          </div>
        ))}
        {isLoading && <div className="text-center text-slate-400 italic py-2"><Icon name="Loader2" size={18} className="inline animate-spin mr-2" />Noema is writing...</div>}
      </div>
      <div className="flex items-center space-x-2">
        <textarea
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Write your part or give Noema instructions..."
          rows={2}
          className="flex-grow p-2 bg-slate-700 border border-slate-600 rounded-lg text-sm text-slate-100 placeholder-slate-400 focus:ring-1 focus:ring-purple-500 outline-none resize-none custom-scrollbar"
          disabled={isLoading}
        />
        <button onClick={() => handleContinueStory("continue_normal")} disabled={isLoading} className="p-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg disabled:opacity-60 transition-colors flex items-center justify-center text-sm" title="Continue Story">
          <Icon name="Feather" size={18} className="mr-1 sm:mr-2" /> <span className="hidden sm:inline">Continue</span>
        </button>
      </div>
    </div>
  );
};

export default StoryForgeView;
