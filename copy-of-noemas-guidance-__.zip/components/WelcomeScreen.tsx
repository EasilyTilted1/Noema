
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 

const WelcomeScreen: React.FC = () => {
  const { initializeUser, speak, isAppReady, userProgress } = useAppContext();
  const [name, setName] = useState('');

  useEffect(() => {
    if (isAppReady && !userProgress) {
      speak("Welcome, AI Adventurer! Please enter your name to begin your quest.", true);
    }
  }, [speak, isAppReady, userProgress]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    initializeUser(name.trim() || "Adventurer");
  };

  if (!isAppReady) {
    return (
      <div className="flex items-center justify-center h-full bg-gradient-to-br from-slate-900 via-purple-900 to-sky-900 p-8">
        <Icon name="Loader2" className="animate-spin h-16 w-16 text-sky-400" />
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-slate-900 via-purple-800 to-sky-800 p-6 md:p-8 rounded-lg shadow-2xl">
      <Icon name="Bot" size={80} className="text-sky-400 mb-6 animate-bounce" />
      <h1 className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-500 mb-4 text-center">
        Noema's Guidance
      </h1>
      <p className="text-lg md:text-xl text-slate-300 mb-8 text-center max-w-xl">
        Embark on an interactive journey to explore the fascinating world of Artificial Intelligence with Noema, your personal AI guide.
      </p>
      <form onSubmit={handleSubmit} className="w-full max-w-md">
        <label htmlFor="displayNameInput" className="block text-md md:text-lg text-sky-300 mb-2">
          Enter your name, AI Adventurer:
        </label>
        <input
          type="text"
          id="displayNameInput"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full p-3 mb-6 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none transition-colors duration-150"
          placeholder="e.g., Alex the Explorer"
          maxLength={50}
        />
        <button
          type="submit"
          className="w-full bg-gradient-to-r from-sky-500 to-purple-600 hover:from-sky-600 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out text-lg"
        >
          Begin Your Quest
        </button>
      </form>
      <p className="mt-8 text-xs text-slate-500 text-center">
        Your progress will be saved locally in your browser.
      </p>
    </div>
  );
};

export default WelcomeScreen;
