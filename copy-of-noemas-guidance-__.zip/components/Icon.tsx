
import React from 'react';
import { IconName } from '../types.ts'; // Assuming types.ts is in the parent directory

export interface IconProps extends React.SVGProps<SVGSVGElement> {
  name: IconName | string; // Allow string for flexibility if IconName isn't exhaustive
  size?: number | string;
  className?: string;
}

export const Icon: React.FC<IconProps> = ({ name, size = 20, className = '', ...props }) => {
  const iconPaths: Record<string, React.ReactNode> = {
    Bot: <><circle cx="12" cy="12" r="10" /><path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0-8 0" /><path d="M12 16c-2.67 0-5 1.33-5 2.5V20h10v-1.5c0-1.17-2.33-2.5-5-2.5zM8.5 9a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1h-2a.5.5 0 0 1-.5-.5zm5 0a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1h-2a.5.5 0 0 1-.5-.5z" /></>,
    UserCircle: <><circle cx="12" cy="12" r="10" /><circle cx="12" cy="10" r="3" /><path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662" /></>,
    AlertTriangle: <><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" /></>,
    MessageSquare: <><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></>,
    Loader2: <><path d="M21 12a9 9 0 1 1-6.219-8.56" /></>,
    Send: <><line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" /></>,
    Volume2: <><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" /><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" /></>,
    VolumeX: <><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" /><line x1="23" y1="9" x2="17" y2="15" /><line x1="17" y1="9" x2="23" y2="15" /></>,
    ListChecks: <><path d="M10.5 6h9.5" /><path d="M10.5 12h9.5" /><path d="M10.5 18h9.5" /><path d="M3.6 7.2L3 7.8l-.6-.6L1.8 6l.6-.6L3 6l.6.6z" /><path d="M3.6 13.2L3 13.8l-.6-.6-1.2-1.2.6-.6L3 12l.6.6z" /><path d="M3.6 19.2L3 19.8l-.6-.6-1.2-1.2.6-.6L3 18l.6.6z" /></>,
    Network: <><rect x="16" y="16" width="6" height="6" rx="1" /><rect x="2" y="16" width="6" height="6" rx="1" /><rect x="9" y="2" width="6" height="6" rx="1" /><path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" /><path d="M12 12V8" /></>,
    BookOpen: <><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" /></>,
    Library: <><path d="M16 6H4a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" /><path d="M19 20H7a2 2 0 0 1-2-2V6" /><path d="M20 4v12" /></>,
    Sparkles: <><path d="M9.95 5.05L12 2l2.05 3.05" /><path d="M2.05 14.05L5 12l-2.95-2.05" /><path d="M19.05 11.95L22 14l-2.95 2.05" /><path d="M12 22l-2.05-3.05L12 16l2.05 3.05z" /><path d="m5 7 1-1" /><path d="m18 7 1-1" /><path d="m5 17-1 1" /><path d="m18 17-1 1" /></>,
    NotebookText: <><path d="M2 6h4" /><path d="M2 10h4" /><path d="M2 14h4" /><path d="M2 18h4" /><rect width="16" height="20" x="4" y="2" rx="2" /><path d="M15 2v20" /><path d="M8 12h6" /><path d="M8 16h6" /></>,
    Archive: <><rect width="20" height="5" x="2" y="3" rx="1" /><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8" /><path d="M10 12h4" /></>,
    Zap: <><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></>,
    ScrollText: <><path d="M8 21h10a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H8" /><path d="M18 9H6a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h12" /><path d="M18 15H6a2 2 0 0 1-2 2v2a2 2 0 0 1 2 2h12" /><path d="M3 7.5h2" /><path d="M3 12.5h2" /><path d="M3 17.5h2" /></>,
    ChevronUp: <><polyline points="18 15 12 9 6 15" /></>,
    ChevronRight: <><polyline points="9 18 15 12 9 6" /></>,
    ChevronDown: <><polyline points="6 9 12 15 18 9" /></>,
    CheckCircle2: <><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" /><path d="m9 12 2 2 4-4" /></>,
    Circle: <><circle cx="12" cy="12" r="10" /></>,
    Construction: <><rect x="2" y="6" width="20" height="12" rx="2" /><path d="M10 12h4v4h-4z"/><path d="m18 18-2-2"/><path d="m6 6 2 2"/></>,
    Lightbulb: <><path d="M15 14c.2-1 .7-1.7 1.5-2.5C17.7 10.2 18 9 18 8A6 6 0 0 0 6 8c0 1 .3 2.2 1.5 3.5.7.7 1.2 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></>,
    BookOpenCheck: <><path d="M8 3H2v15h7c1.7 0 3 1.3 3 3V7c0-2.2-1.8-4-4-4Z"/><path d="M16 12l2 2 4-4"/><path d="M22 6V3h-6c-2.2 0-4 1.8-4 4v14c0-1.7 1.3-3 3-3h7Z"/></>,
    Search: <><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></>,
    ArchiveX: <><rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="m9.5 12.5 5 5"/><path d="m14.5 12.5-5 5"/></>,
    RotateCcw: <><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /></>,
    StickyNote: <><path d="M15.5 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2V8.5L15.5 3Z"/><path d="M15 3v6h6"/></>,
    Gem: <><path d="M6 3h12l4 6-10 13L2 9Z"/><path d="m12 22 4-13-3-6-1 6-4-6-3 6 4 13Z"/><path d="M2 9h20"/></>,
    BookCopy: <><path d="M2 16V4a2 2 0 0 1 2-2h11"/><path d="M5 14H4a2 2 0 1 0 0 4h1"/><path d="M22 18H11a2 2 0 1 0 0 4h11"/><path d="M15 22V10a2 2 0 0 0-2-2H7"/></>,
    Edit3: <><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/></>,
    Trash2: <><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></>,
    XSquare: <><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></>,
    PlusCircle: <><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></>,
    HelpCircle: <><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></>,
    Scroll: <><path d="M8 21h10a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H8"/><path d="M18 9H6a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h12"/><path d="M18 15H6a2 2 0 0 1-2 2v2a2 2 0 0 1 2 2h12"/></>,
    FlaskConical: <><path d="M10 2v7.31"/><path d="M14 9.31V2"/><path d="M3 13a8 8 0 0 0 .88 3.88L5 19l1-1.54c.41-.63.76-1.3.95-2.01A8.003 8.003 0 0 0 3 13Z"/><path d="M21 13a8 8 0 0 1-3.88 6.88l-1.12-2.33A8.003 8.003 0 0 1 21 13Z"/><path d="M5 19s4.03-5.99 4.49-6.5A1.5 1.5 0 0 1 10.5 12h3a1.5 1.5 0 0 1 1.01.5A13.713 13.713 0 0 1 19 19"/></>,
    TestTube2: <><path d="M14.5 2v17.5c0 1.4-1.1 2.5-2.5 2.5h0c-1.4 0-2.5-1.1-2.5-2.5V2"/><path d="M8.5 2h7"/><path d="M14.5 16H10"/><path d="m10 10 4.5 4.5"/><path d="M10 2v2.34"/><path d="M14.5 2v2.34"/></>,
    Compass: <><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 -7.07 7.07 7.07 16.93 12 12 7.76 16.24 16.93 7.07 7.07 7.07 12 12"/></>,
    ClipboardList: <><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/></>,
    Play: <><polygon points="5 3 19 12 5 21 5 3"/></>,
    XCircle: <><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></>,
    GitFork: <><path d="M12 18c-3.3 0-6-2.7-6-6v-1"/><path d="M12 6c-3.3 0-6 2.7-6 6v1"/><path d="M12 12h1c2.8 0 5-2.2 5-5V6"/><path d="M12 12h-1c-2.8 0-5 2.2-5 5V6"/><circle cx="12" cy="18" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="6" cy="12" r="2"/><circle cx="18" cy="12" r="2"/></>,
    MessageCircleQuestion: <><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8c-.5 1.4-1.2 2.6-2.2 3.7-1.1 1.1-2.5 1.9-4 2.3A8.38 8.38 0 0 1 12 22a8.38 8.38 0 0 1-3.8-.9c-1.4-.5-2.6-1.2-3.7-2.2-1.1-1.1-1.9-2.5-2.3-4A8.38 8.38 0 0 1 2 12.5a8.38 8.38 0 0 1 .9-3.8c.5-1.4 1.2-2.6 2.2-3.7 1.1-1.1 2.5-1.9 4-2.3A8.38 8.38 0 0 1 12 2a8.38 8.38 0 0 1 3.8.9c1.4.5 2.6 1.2 3.7 2.2 1.1 1.1 1.9 2.5 2.3 4A8.38 8.38 0 0 1 21 11.5Z"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></>,
    Feather: <><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><line x1="16" x2="2" y1="8" y2="22"/><line x1="17.5" x2="9" y1="15" y2="15"/></>,
    Workflow: <><path d="M6 3v2a3 3 0 0 0 3 3h3"/><path d="M12 8V6a3 3 0 0 0-3-3H6"/><path d="M12 16v-2a3 3 0 0 0-3-3H6"/><path d="M6 13H3a3 3 0 0 0-3 3v2"/><path d="M18 3v2a3 3 0 0 1-3 3h-3"/><path d="M12 8V6a3 3 0 0 1 3-3h3"/><path d="M12 16v-2a3 3 0 0 1 3-3h3"/><path d="M18 13h3a3 3 0 0 1 3 3v2"/></>,
    MousePointer: <><path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/><path d="M13 13l6 6"/></>,
    MessageCircleMore: <><path d="M21 6h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v4l-4-4H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M12 12h.01"/><path d="M16 12h.01"/><path d="M8 12h.01"/></>,
    Settings2: <><path d="M20 7h-9"/><path d="M14 17H5"/><circle cx="17" cy="17" r="3"/><circle cx="7" cy="7" r="3"/></>,
    FileJson: <><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="M12 18h-1v-5h2v1a1 1 0 0 1-1 1v2a1 1 0 0 1 1 1Z"/><path d="M9 18h1v-4h-2v1a1 1 0 0 0 1 1Z"/></>,
    AlignLeft: <><line x1="21" x2="3" y1="6" y2="6"/><line x1="15" x2="3" y1="12" y2="12"/><line x1="17" x2="3" y1="18" y2="18"/></>,
    ImageUp: <><path d="M10.083 5H21a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h3.083"/><path d="M7 9L5 7l2-2"/><path d="m14 16.5-3-3-3 3h-1a2 2 0 0 0-2 2v1h12v-1a2 2 0 0 0-2-2Z"/><circle cx="14" cy="9.5" r=".5"/></>,
    ScanSearch: <><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/><path d="m16 16-1.9-1.9"/></>,
    CaseSensitive: <><path d="m3 15 4-8 4 8"/><path d="M4 13h6"/><path d="M15 4h6"/><path d="M15 10h6"/><path d="M15 16h6"/></>,
    FileOutput: <><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><polyline points="10 12 8 14 10 16"/><polyline points="16 12 14 14 16 16"/></>,
    Merge: <><path d="m10 16.5-4-4 4-4"/><path d="m14 7.5 4 4-4 4"/><path d="M6 12.5h12"/></>,
    Tags: <><path d="M9 5H2v7l6.29 6.29c.94.94 2.48.94 3.42 0l3.58-3.58c.94-.94.94-2.48 0-3.42L9 5Z"/><path d="M6 9.01V9h.01"/><path d="m15 5 6.3 6.3a2.4 2.4 0 0 1 0 3.4L17 19"/></>,
    ListTree: <><path d="M21 12h-8"/><path d="M21 6H8"/><path d="M21 18H8"/><path d="M3 6v4c0 1.1.9 2 2 2h3"/><path d="M3 10v4c0 1.1.9 2 2 2h3"/></>,
    Calculator: <><rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><line x1="16" x2="12" y1="14" y2="14"/><line x1="12" x2="12" y1="14" y2="18"/><line x1="12" x2="8" y1="14" y2="14"/><line x1="8" x2="8" y1="14" y2="18"/><line x1="8" x2="4" y1="14" y2="14"/></>,
    ImagePlay: <><path d="M21 12c0 4.418-4.03 8-9 8s-9-3.582-9-8 4.03-8 9-8"/><path d="m14 9-4 3 4 3V9Z"/><path d="M10.083 5H21a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h3.083"/><path d="M7 9L5 7l2-2"/></>,
    Key: <><circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/></>,
    TableProperties: <><path d="M15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9l-4.5-4.5M15 3v4.5h4.5"/><path d="M8 18h1"/><path d="M8 14h3"/><path d="M13 18h1"/><path d="M13 14h1"/></>,
    ArchiveRestore: <><rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/><path d="m9 16 3-3 3 3"/></>,
    Wand: <><path d="M15 4V2"/><path d="M15 8V6"/><path d="M15 12V10"/><path d="M15 16V14"/><path d="M15 20V18"/><path d="M15 22V20"/><path d="M17.8 2.2 17 3"/><path d="M17.8 6.2 17 7"/><path d="M17.8 10.2 17 11"/><path d="M17.8 14.2 17 15"/><path d="M17.8 18.2 17 19"/><path d="M12.2 2.2 13 3"/><path d="M12.2 6.2 13 7"/><path d="M12.2 10.2 13 11"/><path d="M12.2 14.2 13 15"/><path d="M12.2 18.2 13 19"/><path d="M6.2 2.2 7 3"/><path d="M6.2 6.2 7 7"/><path d="M6.2 10.2 7 11"/><path d="M6.2 14.2 7 15"/><path d="M6.2 18.2 7 19"/><path d="M22 18h-2"/><path d="M18 18h-2"/><path d="M14 18h-2"/><path d="M10 18H8"/><path d="M6 18H4"/><path d="M2 18H4"/><path d="m19 11-8-8-4 4 8 8 4-4z"/></>,
    Component: <><path d="M5.5 8.5 9 12l-3.5 3.5L2 12l3.5-3.5Z"/><path d="m12 2 3.5 3.5L12 9 8.5 5.5 12 2Z"/><path d="m12 15 3.5 3.5L12 22l-3.5-3.5L12 15Z"/><path d="M15.5 8.5 19 12l-3.5 3.5L12 12l3.5-3.5Z"/></>,
    TestTubeDiagonal: <><path d="M14.5 2v17.5c0 1.4-1.1 2.5-2.5 2.5h0c-1.4 0-2.5-1.1-2.5-2.5V2"/><path d="M8.5 2h7"/><path d="M14.5 16H10"/><path d="m10 10 4.5 4.5"/><path d="M10 2v2.34"/><path d="M14.5 2v2.34"/></>,
    TrendingUp: <><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></>,
    ShieldCheck: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></>,
    Lock: <><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></>,
    Users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    Cpu: <><rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2M15 20v2M2 15h2M20 15h2M9 2v2M9 20v2M2 9h2M20 9h2"/></>,
    Infinity: <><path d="M3.5 9C6.24 6.05 9.51 4 12.59 4c4.04 0 6.45 1.99 8.23 4.48.4.57.25 1.06-.31 1.06H3.81c-.56 0-.71-.49-.31-1.06ZM20.5 15c-2.74 2.95-6.01 5-9.09 5-4.04 0-6.45-1.99-8.23-4.48-.4-.57-.25-1.06.31-1.06h16.12c.56 0 .71.49.31 1.06Z"/></>, 
    LocateFixed: <><line x1="2" x2="5" y1="12" y2="12"/><line x1="19" x2="22" y1="12" y2="12"/><line x1="12" x2="12" y1="2" y2="5"/><line x1="12" x2="12" y1="19" y2="22"/><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="3"/></>,
    Unlock: <><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></>,
    Radar: <><path d="M19.07 4.93A10 10 0 0 0 6.99 3.34"/><path d="M4 6h.01"/><path d="M2.29 9.62A10 10 0 0 0 2 12.5"/><path d="M6 20h.01"/><path d="M20.71 14.38A10 10 0 0 0 22 12.5"/><path d="M17.01 18h.01"/><path d="M12 2a10 10 0 0 0-9.07 5.5"/><path d="M12 22A10 10 0 0 0 21.07 16.5"/></>,
    Route: <><circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/></>,
    Move: <><polyline points="5 9 2 12 5 15"/><polyline points="9 5 12 2 15 5"/><polyline points="15 19 12 22 9 19"/><polyline points="19 9 22 12 19 15"/><line x1="2" x2="22" y1="12" y2="12"/><line x1="12" x2="12" y1="2" y2="22"/></>,
    BrainCircuit: <><path d="M12 2a4.5 4.5 0 0 0-4.5 4.5v.142A4.5 4.5 0 0 0 3 11.142V16.5a4.5 4.5 0 1 0 9 0v-5.358A4.5 4.5 0 0 0 16.5 6.642V6.5A4.5 4.5 0 0 0 12 2Z"/><path d="M3 14.5a2.5 2.5 0 0 1 2.5-2.5"/><path d="M3.5 21a2.5 2.5 0 0 0 2.5-2.5"/><path d="M7.5 14a2.5 2.5 0 0 1 2.5-2.5"/><path d="M7.5 21a2.5 2.5 0 0 0 2.5-2.5"/><path d="M12 14.5a2.5 2.5 0 0 1 2.5-2.5"/><path d="M12 21a2.5 2.5 0 0 0 2.5-2.5"/><path d="M16.5 14a2.5 2.5 0 0 1 2.5-2.5"/><path d="M16.5 21a2.5 2.5 0 0 0 2.5-2.5"/><circle cx="12" cy="8.5" r=".5" fill="currentColor"/><path d="M12 12v-2"/><circle cx="9.5" cy="11" r=".5" fill="currentColor"/><path d="M9.5 14.5v-2.5"/><circle cx="14.5" cy="11" r=".5" fill="currentColor"/><path d="M14.5 14.5v-2.5"/></>,
    Target: <><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></>,
    Puzzle: <><path d="M19.435 7.765C20.138 7.38 21 7.644 21 8.429v7.142c0 .785-.862 1.049-1.565.664l-2.869-1.565C15.862 14.283 15 13.76 15 13V9c0-.76.862-1.283 1.566-.664l2.869 1.43Z"/><path d="M14.235 15.235C14.62 14.532 14.356 13.5 13.571 13.5H7.857C7.072 13.5 6.5 14.362 6.5 15.065l1.43 2.869C8.317 18.862 9.24 19.5 10 19.5h4c.76 0 1.283-.862.664-1.565l-1.43-2.869Z"/><path d="M7.765 4.565C7.38 3.862 7.644 3 8.429 3h7.142c.785 0 1.049.862.664 1.565l-1.565 2.869C14.283 8.138 13.76 9 13 9H9c-.76 0-1.283-.862-.664-1.565l-1.565-2.87Z"/><path d="M4.565 16.235C3.862 15.85 3 16.114 3 16.899V9.757C3 8.972 3.862 8.708 4.565 9.092l2.869 1.565C8.138 11.04 9 11.563 9 12.327V15c0 .76-.862 1.283-1.565.664l-2.87-1.43Z"/></>,
    Grid: <><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/></>,
    Map: <><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" x2="9" y1="3" y2="18"/><line x1="15" x2="15" y1="6" y2="21"/></>,
    SlidersHorizontal: <><line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/></>,
    DraftingCompass: <><circle cx="12" cy="12" r="10"/><path d="M12 12 7.5 21.5"/><path d="M12 12 16.5 21.5"/><path d="m7 10 5-7 5 7"/><path d="m7 10-1.76 1.76"/><path d="m17 10 1.76 1.76"/></>,
    Link: <><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.72"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.72-1.72"/></>,
    Palette: <><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="10.5" cy="12.5" r=".5" fill="currentColor"/><path d="M21.174 6.812a1 1 0 0 0-3.988-3.988L2.5 10.5V19h8.5Z"/></>,
    Newspaper: <><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2Zm0 0a2 2 0 0 1-2-2V9h4v13Z"/><path d="M18 22V9"/><path d="M10 14.5a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 1 1 0v2a.5.5 0 0 1-.5.5Z"/><path d="M12 14h2"/><path d="M12 12h2"/><path d="M12 10h4"/><path d="M12 8h4"/></>,
    Quote: <><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2H16c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.5 2.25 4 4.25 4V20c0 1 0 1 1 1z"/></>,
    ListFilter: <><path d="M3 6h18"/><path d="M7 12h10"/><path d="M10 18h4"/></>,
    GitCompareArrows: <><path d="M5 12H3"/><path d="M10 12H8"/><path d="M17 12h2"/><path d="M14 7l-3-3-3 3"/><path d="M14 17l-3 3-3-3"/><path d="M21 12h-2"/></>,
    Megaphone: <><path d="m3 11 18-5v10L3 11"/><path d="M11.5 14H8a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3.5"/><path d="M16 10a1 1 0 1 1 0 2H4.1L3 11Z"/></>,
    BotMessageSquare: <><path d="M12 6V2m0 4a6 6 0 0 1 6 6v0a6 6 0 0 1-6 6v0a6 6 0 0 1-6-6v0a6 6 0 0 1 6-6Z"/><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></>,
    Bird: <><path d="M16 7h.01"/><path d="M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.28-2.3L2 22"/><path d="m20 7 2 .5-2 .5"/><path d="M10 18c1.8 0 3.5-.8 4.8-2.3"/><path d="M8 18c-1.8 0-3.5-.8-4.8-2.3L2 22"/></>,
    FileSearch2: <><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><circle cx="11.5" cy="14.5" r="2.5"/><line x1="13.5" x2="15.5" y1="16.5" y2="18.5"/></>,
    Brain: <><path d="M12 2a4.5 4.5 0 0 0-4.5 4.5v.142A4.5 4.5 0 0 0 3 11.142V16.5a4.5 4.5 0 1 0 9 0v-5.358A4.5 4.5 0 0 0 16.5 6.642V6.5A4.5 4.5 0 0 0 12 2Z"/></>, 
    Cookie: <><path d="M12 2a8 8 0 0 0-8 8 8 8 0 0 0 8 8 8 8 0 0 0 8-8 8 8 0 0 0-8-8Z"/><path d="M5.1 14.1A3 3 0 0 1 4 12a3 3 0 0 1 2.9-3 .3.3 0 0 0 .1-.1 3 3 0 0 1 5.9-1 .3.3 0 0 0 .1-.1 3 3 0 0 1 5.9 1 .3.3 0 0 0 .1.1A3 3 0 0 1 20 12a3 3 0 0 1-1.1 2.1 .3.3 0 0 0-.1.1 3 3 0 0 1-1 5.9 .3.3 0 0 0-.1.1 3 3 0 0 1-5.9 1 .3.3 0 0 0-.1.1A3 3 0 0 1 4 18a3 3 0 0 1 1.1-2.1.3.3 0 0 0 .1-.1Z"/></>,
    SprayCan: <><path d="m16.7 11.7-.3.3a1 1 0 0 0 0 1.4l.3.3"/><path d="M18.4 10-.3.3a1 1 0 0 0-1.4 0l-.3.3"/><path d="m13.3 15 .3-.3a1 1 0 0 0 0-1.4l-.3-.3"/><path d="m15 16.7-.3-.3a1 1 0 0 0-1.4 0l-.3.3"/><path d="M21.5 6.5c.6-.6.6-1.5 0-2.1l-3-3c-.6-.6-1.5-.6-2.1 0L16 1.8"/><path d="M20 3.3 18.7 2"/><path d="M7.1 10.2C4.5 11.9 2.4 13.1 2 13.3a1.5 1.5 0 0 0-1 1.4c0 1.2 1.4 1.8 2.6 2.1.4.1.9.2 1.4.2 1.4 0 2.5-.5 3.6-1.3a10.7 10.7 0 0 0 2.4-2.3L7.1 10.2Z"/><path d="M21.1 10.2c-.3-.2-1.5-1.2-3.6-2.8s-3.7-2.9-4.1-3.1c-.4-.3-.9-.4-1.4-.4-1.4 0-2.5.5-3.6 1.3a10.7 10.7 0 0 0-2.4 2.3L13.9 14Z"/></>,
    Wrench: <><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></>,
    Binary: <><path d="M6 20h4"/><path d="M14 20h4"/><rect width="4" height="6" x="6" y="14" rx="2"/><rect width="4" height="6" x="14" y="14" rx="2"/><path d="M6 10h2v4H6z"/><path d="M14 4h2v6h-2z"/><path d="M6 4h4v6H6zm8 0h4v2h-4z"/></>,
    default: <><circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="3" fill="currentColor"/></>
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
      aria-label={`Icon: ${String(name)}`}
      role="img"
    >
      <title>{String(name)}</title>
      {iconPaths[name as string] || iconPaths.default}
    </svg>
  );
};
