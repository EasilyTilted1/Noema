
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { Agent2DState, GridCellState, AgentSimulation2DConfig, SocraticContext, AgentInternalModel, AgentRule, TweakableParameterConfig } from '../types.ts';
import { Bot, Square, Play, Pause, RotateCcw, Rabbit, FastForward, SlidersHorizontal, Info, HelpCircle, ChevronDown, ChevronUp, Zap, Target, BrainCircuit, AlertTriangle, Settings } from 'lucide-react';

interface AgentSimulation2DViewProps {
}

const AgentSimulation2DView: React.FC<AgentSimulation2DViewProps> = (props) => {
  const { speak, triggerSocraticPromptsForSimulation, activeStep, activeQuest } = useAppContext();
  const [agentState, setAgentState] = useState<Agent2DState | null>(null);
  const [gridState, setGridState] = useState<GridCellState[][] | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [simulationSpeed, setSimulationSpeed] = useState(500); 
  const simIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    const config = activeStep?.simulationConfig;
    if (config) {
      setAgentState({
        ...config.initialAgentState,
        internalModel: { knownObstacles: [], knownChargingStation: null },
        lowBatteryThreshold: config.initialAgentState.lowBatteryThreshold ?? config.lowBatteryThreshold ?? 20,
        inventory: [],
        goalDefinition: config.initialAgentState.goalDefinition,
        currentGoalDescription: "Initialize goals",
      });
      setGridState(config.initialGridState);
      speak("2D Agent Simulation ready. Press Play to start.");
    }
  }, [activeStep, speak]);

  const runSimulationStep = useCallback(() => {
    console.log("Simulation step executed (placeholder)");
  }, []);

  const togglePlayPause = () => {
    if (isRunning) {
      if (simIntervalRef.current) clearInterval(simIntervalRef.current);
      setIsRunning(false);
      speak("Simulation paused.");
    } else {
      setIsRunning(true);
      speak("Simulation resumed.");
      runSimulationStep(); 
      simIntervalRef.current = window.setInterval(runSimulationStep, simulationSpeed);
    }
  };

  const resetSimulation = () => {
    if (simIntervalRef.current) clearInterval(simIntervalRef.current);
    setIsRunning(false);
    const config = activeStep?.simulationConfig;
    if (config) {
      setAgentState({
        ...config.initialAgentState,
        internalModel: { knownObstacles: [], knownChargingStation: null },
        lowBatteryThreshold: config.initialAgentState.lowBatteryThreshold ?? config.lowBatteryThreshold ?? 20,
        inventory: [],
        goalDefinition: config.initialAgentState.goalDefinition,
        currentGoalDescription: "Initialize goals",
      });
      setGridState(config.initialGridState);
    }
    speak("Simulation reset.");
  };


  if (!activeStep?.simulationConfig) {
    return (
      <div className="p-4 text-center text-slate-400">
        Agent Simulation: No configuration loaded for the current step.
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full p-2 md:p-4 items-center bg-slate-800/70 rounded-lg shadow-inner">
      <h3 className="text-lg font-semibold text-sky-300 mb-2">2D Agent Simulation</h3>
      <div className="flex items-center space-x-2 mb-3 p-2 bg-slate-700/50 rounded-md">
        <button onClick={togglePlayPause} className={`p-2 rounded-md ${isRunning ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-green-500 hover:bg-green-600'} text-white`}>
          {isRunning ? <Pause size={18} /> : <Play size={18} />}
        </button>
        <button onClick={resetSimulation} className="p-2 rounded-md bg-red-500 hover:bg-red-600 text-white">
          <RotateCcw size={18} />
        </button>
        <Rabbit size={18} className="text-slate-400" />
        <input type="range" min="50" max="1000" step="50" value={1050 - simulationSpeed} onChange={(e) => setSimulationSpeed(1050 - parseInt(e.target.value))} className="w-24 h-2 accent-sky-500"/>
      </div>

      <div className="flex-grow w-full max-w-md aspect-square bg-slate-700 border border-slate-600 rounded-md flex items-center justify-center">
        <p className="text-slate-500">Grid Area</p>
      </div>

      {agentState && (
        <div className="mt-3 p-2 bg-slate-700/50 rounded-md text-xs text-slate-300 w-full max-w-md">
          <p>Agent: Pos ({agentState.x},{agentState.y}) Dir: {agentState.direction} Bat: {agentState.batteryLevel}%</p>
        </div>
      )}
    </div>
  );
};

export default AgentSimulation2DView;
