import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; 
import { Icon } from './Icon.tsx'; 
import { Quest, QuestStep } from '../types.ts'; 
import { IS_CONTENT_UNLOCKED_FOR_TESTING } from '../constants.ts';

const PHASE_DESCRIPTIONS: Record<string, string> = {
    "Phase AA1: Foundations of AI Agents": "Start your journey by understanding what AI agents are, their key characteristics, and the different types of agent architectures that exist.",
    "Phase AA2: Building Blocks of Intelligent Agents": "Delve into the core components that make agents tick: how they perceive their environment, plan their actions, and execute decisions.",
    "Phase AA3: Agents in Action (Simulations)": "Step into the sandbox! In this phase, you'll observe different types of AI agents operating in simulated 2D grid worlds. See firsthand how reflex, model-based, and goal-based agents perceive their environment, make decisions, and execute actions to achieve their objectives. It's all about watching AI 'think' and act in real-time.",
    "Phase AA4: Advanced Agent Design & Experimentation": "Become an agent architect! This phase challenges you to actively design and configure agents. You'll assemble conceptual agent components to solve specific tasks and experiment by tweaking crucial agent parameters to understand their impact on behavior and efficiency. Time to get hands-on with agent design!",
    "Phase AA5: Advanced Orchestrator Applications": "Learn to connect multiple AI components into powerful workflows. You'll tackle complex tasks by designing sequences of operations, from fetching live data to analyzing it and generating structured outputs.",
    "Phase AA6: Emergent Behavior & Swarm Intelligence": "Explore how simple individual agent rules can lead to complex and intelligent group behaviors. Understand the principles behind swarm intelligence and its potential applications."
};


const AgentAcademyLogView: React.FC = () => {
    const { 
        quests, 
        userProgress, 
        speak, 
        setUserProgress: setAppContextUserProgress, 
        setCurrentView,
        activeQuest: currentGlobalActiveQuest, 
        activeStep: currentGlobalActiveStep  
    } = useAppContext();
    
    const [expandedPhases, setExpandedPhases] = useState<Record<string, boolean>>({});
    const [expandedQuests, setExpandedQuests] = useState<Record<string, boolean>>({});

    const academyQuests = useMemo(() => quests.filter(q => q.academy === 'agentAcademy'), [quests]);

    const questsByPhase = useMemo(() => {
        return academyQuests.reduce((acc, quest) => {
            const phaseKey = quest.phase || "Uncategorized";
            if (!acc[phaseKey]) {
                acc[phaseKey] = [];
            }
            acc[phaseKey].push(quest);
            return acc;
        }, {} as Record<string, Quest[]>);
    }, [academyQuests]);

     useEffect(() => {
        if (currentGlobalActiveQuest && currentGlobalActiveQuest.academy === 'agentAcademy' && currentGlobalActiveQuest.phase) {
            setExpandedPhases(prev => ({ ...prev, [currentGlobalActiveQuest.phase!]: true }));
            setExpandedQuests(prev => ({ ...prev, [currentGlobalActiveQuest.id]: true }));
        }
    }, [currentGlobalActiveQuest]);


    const togglePhaseExpansion = (phaseName: string) => {
        setExpandedPhases(prev => ({ ...prev, [phaseName]: !prev[phaseName] }));
    };

    const toggleQuestExpansion = (questId: string) => {
        setExpandedQuests(prev => ({ ...prev, [questId]: !prev[questId] }));
    };

    const handleStepClick = useCallback((questId: string, stepId: string) => {
        const targetQuest = quests.find(q => q.id === questId);
        const targetStep = targetQuest?.steps.find(s => s.id === stepId);

        if (!targetQuest || !targetStep) return;

        const isStepCompleted = userProgress?.completedQuestSteps[stepId];
        const isCurrentStep = stepId === userProgress?.currentStepId && questId === userProgress?.currentQuestId;
        const isFirstStepOfQuest = targetQuest.steps[0].id === stepId;
        
        let canAccessStep = IS_CONTENT_UNLOCKED_FOR_TESTING || isStepCompleted || isCurrentStep;
        if (!canAccessStep && !isStepCompleted && isFirstStepOfQuest) {
            canAccessStep = true;
        } else if (!canAccessStep && !isStepCompleted && !isFirstStepOfQuest) {
            const stepIndex = targetQuest.steps.findIndex(s => s.id === stepId);
            if (stepIndex > 0) {
                const prevStepId = targetQuest.steps[stepIndex - 1].id;
                if (userProgress?.completedQuestSteps[prevStepId]) {
                    canAccessStep = true;
                }
            }
        }


        if (canAccessStep) {
            speak(`Navigating to ${targetStep.title}.`);
            setAppContextUserProgress(prev => {
                if (!prev) return null;
                return { ...prev, currentQuestId: questId, currentStepId: stepId };
            });
            setCurrentView('interaction');
        } else {
            speak(`You need to unlock or complete previous steps to access "${targetStep.title}".`);
        }
    }, [quests, speak, setAppContextUserProgress, userProgress, setCurrentView]);

    if (!userProgress) {
        return (
          <div className="p-6 text-center text-slate-400 flex-grow flex flex-col items-center justify-center">
            <Icon name="Loader2" className="animate-spin h-12 w-12 text-sky-500 mb-4" />
            <p>Loading Agent Academy Log...</p>
          </div>
        );
    }
    
    const phaseOrder = Object.keys(questsByPhase).sort((a, b) => {
        const matchA = a.match(/Phase AA(\d+)/);
        const matchB = b.match(/Phase AA(\d+)/);
        if (matchA && matchB) {
            return parseInt(matchA[1], 10) - parseInt(matchB[1], 10);
        }
        return a.localeCompare(b);
    });


    return (
        <div className="p-4 md:p-6 h-full flex flex-col bg-slate-900 text-slate-100">
            <div className="mb-6 text-center">
                <Icon name="Network" size={48} className="text-purple-400 mx-auto mb-3" />
                <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-sky-500">
                    Agent Academy Log
                </h1>
                <p className="text-slate-400 mt-1">Track your progress and revisit lessons in AI agent development.</p>
            </div>

            {academyQuests.length === 0 ? (
                 <div className="text-center text-slate-500 py-10 flex-grow flex flex-col items-center justify-center">
                    <Icon name="ArchiveX" size={40} className="mx-auto mb-3"/>
                    <p>No Agent Academy quests found.</p>
                 </div>
            ) : (
                <div className="flex-grow overflow-y-auto custom-scrollbar pr-1 space-y-6">
                    {phaseOrder.map(phaseName => (
                        <div key={phaseName} className="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
                            <button
                                onClick={() => togglePhaseExpansion(phaseName)}
                                className="w-full flex justify-between items-center text-left mb-2 p-2 rounded-md hover:bg-slate-700/70 transition-colors"
                                aria-expanded={!!expandedPhases[phaseName]}
                            >
                                <h2 className="text-xl font-semibold text-sky-300">{phaseName}</h2>
                                {expandedPhases[phaseName] ? <Icon name="ChevronUp" size={20} className="text-slate-400"/> : <Icon name="ChevronRight" size={20} className="text-slate-400"/>}
                            </button>
                            {PHASE_DESCRIPTIONS[phaseName] && (
                                <p className="text-sm text-slate-400 mb-3 px-2 italic">{PHASE_DESCRIPTIONS[phaseName]}</p>
                            )}

                            {expandedPhases[phaseName] && (
                                <div className="space-y-3 pl-2">
                                    {questsByPhase[phaseName].map(quest => (
                                        <div key={quest.id} className="bg-slate-700/60 p-3 rounded-md border border-slate-600">
                                            <button
                                                onClick={() => toggleQuestExpansion(quest.id)}
                                                className="w-full flex justify-between items-center text-left mb-1 p-1.5 rounded-md hover:bg-slate-600/50 transition-colors"
                                                aria-expanded={!!expandedQuests[quest.id]}
                                            >
                                                <div className="flex items-center">
                                                    <Icon name={quest.badge.icon} size={18} className="mr-2 text-purple-400 flex-shrink-0" />
                                                    <h3 className={`text-md font-medium ${quest.id === currentGlobalActiveQuest?.id ? 'text-purple-300' : 'text-slate-200'}`}>{quest.title}</h3>
                                                </div>
                                                {expandedQuests[quest.id] ? <Icon name="ChevronDown" size={18} className="text-slate-400"/> : <Icon name="ChevronRight" size={18} className="text-slate-400"/>}
                                            </button>
                                            {expandedQuests[quest.id] && (
                                                <ul className="space-y-1 ml-4 mt-1 pl-3 border-l-2 border-slate-500/70">
                                                    {quest.steps.map(step => {
                                                        const isCompleted = userProgress.completedQuestSteps[step.id];
                                                        const isCurrent = step.id === currentGlobalActiveStep?.id && quest.id === currentGlobalActiveQuest?.id;
                                                        
                                                        const isFirstStepOfThisQuest = quest.steps[0].id === step.id;
                                                        let isPreviousStepCompleted = false;
                                                        if (!isFirstStepOfThisQuest) {
                                                            const stepIndex = quest.steps.findIndex(s => s.id === step.id);
                                                            if (stepIndex > 0) {
                                                                isPreviousStepCompleted = !!userProgress.completedQuestSteps[quest.steps[stepIndex-1].id];
                                                            }
                                                        }
                                                        const isClickableForStyle = IS_CONTENT_UNLOCKED_FOR_TESTING || isCompleted || isCurrent || isFirstStepOfThisQuest || isPreviousStepCompleted;

                                                        let stepIconName: string = 'Circle';
                                                        let iconColor = 'text-slate-500';
                                                        if (isCompleted) { stepIconName = 'CheckCircle2'; iconColor = 'text-green-400'; }
                                                        else if (isCurrent) { stepIconName = 'ListChecks'; iconColor = 'text-purple-200'; } 
                                                        else if (!isClickableForStyle) { stepIconName = 'Construction'; iconColor = 'text-yellow-500';}
                                                        
                                                        return (
                                                            <li key={step.id}>
                                                                <button
                                                                    onClick={() => handleStepClick(quest.id, step.id)}
                                                                    disabled={!isClickableForStyle && !IS_CONTENT_UNLOCKED_FOR_TESTING}
                                                                    className={`w-full text-left text-sm px-2 py-1.5 rounded-md flex items-center group transition-colors
                                                                        ${isCurrent ? 'bg-purple-600/50 text-purple-100 font-semibold' : 'text-slate-300 hover:bg-slate-600/50'}
                                                                        ${(!isClickableForStyle && !IS_CONTENT_UNLOCKED_FOR_TESTING) ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}`}
                                                                >
                                                                    <Icon name={stepIconName} size={14} className={`mr-2 flex-shrink-0 ${iconColor}`} />
                                                                    <span className="truncate">{step.title}</span>
                                                                    {step.xpAward > 0 && <span className="ml-auto text-xs text-yellow-400 opacity-70 group-hover:opacity-100">+{step.xpAward} XP</span>}
                                                                </button>
                                                            </li>
                                                        );
                                                    })}
                                                </ul>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default AgentAcademyLogView;