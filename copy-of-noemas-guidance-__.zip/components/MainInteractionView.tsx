
import React from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { InteractionType, OrchestratorComponentDefinition } from '../types.ts'; 
import AgentSimulation2DView from './AgentSimulation2DView.tsx';
import AgentAssemblyView from './AgentAssemblyView.tsx';
import { AgentOrchestratorView } from './AgentOrchestratorView.tsx';
import ChatInteraction from './interactions/ChatInteraction.tsx'; 
import { ORCHESTRATOR_COMPONENT_DEFS } from '../constants.ts';


const MainInteractionView: React.FC = () => {
  const { activeStep, activeQuest, speak } = useAppContext();

  console.log('[MainInteractionView] Rendering for step:', activeStep?.title || 'No active step');

  if (!activeStep || !activeQuest) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center bg-slate-800/50 rounded-lg">
        <Icon name="Compass" size={48} className="text-sky-400 mb-4 opacity-70" />
        <h2 className="text-2xl font-semibold text-slate-100 mb-2">
          Welcome to Noema's Guidance!
        </h2>
        <p className="text-slate-300 max-w-md">
          Please select a quest and step from the sidebar to begin your learning journey.
          Noema is ready to assist you in exploring the fascinating world of AI.
        </p>
      </div>
    );
  }

  const renderInteractionComponent = () => {
    if (!activeStep) return null;
    switch (activeStep.interactionType) {
      case 'AI_CHAT':
        return <ChatInteraction />;
      case 'AI_IMAGE_GEN':
         return <div className="interaction-placeholder p-4 bg-pink-900/30 rounded-md text-pink-300">Image Generation Area for {activeStep.title}</div>;
      case 'AI_IMAGE_UPLOAD_ANALYSIS':
         return <div className="interaction-placeholder p-4 bg-indigo-900/30 rounded-md text-indigo-300">Image Upload & Analysis Area for {activeStep.title}</div>;
      case 'USER_REFLECTION':
         return <div className="interaction-placeholder p-4 bg-yellow-900/30 rounded-md text-yellow-300">User Reflection Area for {activeStep.title}</div>;
      case 'AGENT_SIMULATION_2D':
        return <AgentSimulation2DView />;
      case 'AGENT_ASSEMBLY':
        return <AgentAssemblyView />;
      case 'AGENT_ORCHESTRATOR':
        return <AgentOrchestratorView 
                  availablePaletteComponentsOverride={activeStep.orchestratorConfig?.availableComponentDefs?.map(id => ORCHESTRATOR_COMPONENT_DEFS.find(def => def.id === id)).filter(Boolean) as OrchestratorComponentDefinition[] || undefined}
                  isExplicitSandbox={false} 
               />;
      default:
        return <p className="text-yellow-400 p-4 bg-yellow-900/50 rounded-md">Unsupported interaction type: {activeStep.interactionType}</p>;
    }
  };
  
  return (
    <div className="p-4 md:p-6 h-full flex flex-col bg-slate-800/30 rounded-lg shadow-md">
      <div className="mb-4 pb-3 border-b border-slate-700">
        <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-sky-300 flex items-center">
              <Icon name={activeStep.icon || 'ClipboardList'} size={24} className="mr-3 text-sky-400 flex-shrink-0" />
              {activeStep.title}
            </h2>
            <span className="text-xs text-slate-400 bg-slate-700 px-2 py-1 rounded-full">
              Quest: {activeQuest.title}
            </span>
        </div>
        <p className="text-sm text-slate-400 mt-1 ml-10 italic">
          Learning Objective: {activeStep.learningObjective}
        </p>
      </div>

      <div className="prose prose-sm prose-invert max-w-none text-slate-200 mb-4 custom-scrollbar overflow-y-auto flex-shrink" style={{ maxHeight: '20vh' }}>
        <p dangerouslySetInnerHTML={{ __html: activeStep.noemaIntro }} />
      </div>
      
      <div className="flex-grow mt-2 overflow-y-auto custom-scrollbar p-1 rounded-md bg-slate-700/20 border border-slate-700/50 relative">
         {renderInteractionComponent()}
      </div>

    </div>
  );
};

export default MainInteractionView;
