
import React, { useState, useMemo, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { PromptItem, IconName } from '../types.ts';

const PromptCard: React.FC<{
    item: PromptItem;
    onUse: (prompt: PromptItem) => void;
    onDelete: (id: string) => void;
    onCopy: (text: string) => void;
}> = ({ item, onUse, onDelete, onCopy }) => {
  const [expanded, setExpanded] = useState(false);
  const isLongText = item.text.length > 100;

  return (
    <div className="bg-slate-800 p-4 rounded-lg shadow-lg border border-slate-700 hover:shadow-purple-900/50 transition-shadow duration-300 flex flex-col justify-between">
      <div>
        <h3 className="text-lg font-semibold text-purple-300 mb-1">{item.title}</h3>
        <div className="flex items-center space-x-2 text-xs text-slate-400 mb-2">
          <span className={`px-2 py-0.5 rounded-full text-white ${item.type === 'text' ? 'bg-sky-600' : item.type === 'image' ? 'bg-teal-600' : 'bg-indigo-600'}`}>
            {item.type}
          </span>
          <span>Category: {item.category || 'Uncategorized'}</span>
        </div>
        <p className={`text-slate-300 text-sm mb-2 leading-relaxed ${!expanded && isLongText ? 'line-clamp-3' : ''}`}>
          {item.text}
        </p>
        {isLongText && (
          <button onClick={() => setExpanded(!expanded)} className="text-xs text-sky-400 hover:underline mb-2">
            {expanded ? 'Show Less' : 'Show More'}
          </button>
        )}
        {item.notes && (
          <p className="text-xs text-slate-500 mt-1 italic">Notes: {item.notes}</p>
        )}
      </div>
      <div className="mt-3 pt-3 border-t border-slate-700 flex items-center space-x-2">
        <button></button>
      </div>
    </div>
  );
};

const PromptLibraryView: React.FC = () => {
  const { promptLibrary, deletePromptFromLibrary, speak, addToast, setCurrentView, setActiveWorkshopMode, setInputValue: setGlobalInputValue } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterType, setFilterType] = useState<'all' | 'text' | 'image' | 'multi-modal'>('all');

  useEffect(() => {
    speak("Welcome to your Prompt Library. Here you can manage and reuse your favorite prompts.");
  }, [speak]);

  const categories = useMemo(() => {
    const allCategories = new Set(promptLibrary.map(p => p.category || 'Uncategorized'));
    return ['all', ...Array.from(allCategories)];
  }, [promptLibrary]);

  const filteredPrompts = useMemo(() => {
    return promptLibrary
      .filter(p => {
        const termMatch = searchTerm.trim() === '' ||
          p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (p.notes && p.notes.toLowerCase().includes(searchTerm.toLowerCase()));
        const categoryMatch = filterCategory === 'all' || (p.category || 'Uncategorized') === filterCategory;
        const typeMatch = filterType === 'all' || p.type === filterType;
        return termMatch && categoryMatch && typeMatch;
      })
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [promptLibrary, searchTerm, filterCategory, filterType]);

  const handleUsePrompt = (prompt: PromptItem) => {
    if (setGlobalInputValue) {
        setGlobalInputValue(prompt.text); 
        addToast(`Prompt "${prompt.title}" copied to input. Set workshop mode if needed.`, "info");
    } else {
        navigator.clipboard.writeText(prompt.text)
        .then(() => addToast(`Prompt "${prompt.title}" copied to clipboard.`, "success"))
        .catch(() => addToast("Failed to copy prompt.", "error"));
    }
    
    if (prompt.type === 'image') {
        setActiveWorkshopMode('image');
    } else if (prompt.type === 'text' || prompt.type === 'multi-modal') {
        setActiveWorkshopMode('chat');
    }
    setCurrentView('workshop');
  };
  
  const handleCopyPrompt = (text: string) => {
    navigator.clipboard.writeText(text)
      .then(() => addToast("Prompt text copied to clipboard!", "success"))
      .catch(() => addToast("Failed to copy prompt text.", "error"));
  };

  return (
    <div className="p-4 md:p-6 h-full flex flex-col">
      <div className="mb-6 text-center">
        <Icon name="Library" size={48} className="text-purple-400 mx-auto mb-3" />
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-sky-500">
          Prompt Library
        </h1>
        <p className="text-slate-400 mt-1">Curate and reuse your powerful AI prompts.</p>
      </div>

      <div className="mb-4 sticky top-0 bg-slate-900 py-3 z-10 flex flex-col md:flex-row gap-3 items-center border-b border-slate-700 pb-4">
        <div className="relative flex-grow w-full md:w-auto">
          <input
            type="text"
            placeholder="Search prompts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-3 pl-10 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:ring-2 focus:ring-purple-500 outline-none transition-colors"
          />
          <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500" />
        </div>
        <select
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
          className="p-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:ring-2 focus:ring-purple-500 outline-none md:h-full"
        >
          {categories.map((cat: string) => <option key={cat} value={cat}>{cat === 'all' ? 'All Categories' : cat}</option>)}
        </select>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value as any)}
          className="p-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:ring-2 focus:ring-purple-500 outline-none md:h-full"
        >
          <option value="all">All Types</option>
          <option value="text">Text</option>
          <option value="image">Image</option>
          <option value="multi-modal">Multi-modal</option>
        </select>
      </div>

      {filteredPrompts.length > 0 ? (
        <div className="flex-grow overflow-y-auto custom-scrollbar pr-1 pb-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
            {filteredPrompts.map(item => (
              <PromptCard
                key={item.id}
                item={item}
                onUse={handleUsePrompt}
                onDelete={deletePromptFromLibrary}
                onCopy={handleCopyPrompt}
              />
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center text-slate-500 py-10 flex-grow flex flex-col items-center justify-center">
          <Icon name="ArchiveX" size={40} className="mx-auto mb-3"/>
          <p>{promptLibrary.length === 0 ? "Your Prompt Library is empty." : "No prompts match your filters."}</p>
          <p className="text-xs mt-2">You can save prompts from the Main Interaction or Workshop views.</p>
        </div>
      )}
    </div>
  );
};

export default PromptLibraryView;
