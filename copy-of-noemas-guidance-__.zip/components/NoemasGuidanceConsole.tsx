
import React from 'react';
import { OrchestratorComponentDefinition, OrchestratorWorkflow, Quest, QuestStep, OrchestratorActionPayload, NoemaInsight } from '../types.ts'; 
import { Icon } from '../components/Icon.tsx'; // Updated import path
import { ORCHESTRATOR_COMPONENT_DEFS } from '../constants.ts'; 

interface NoemasGuidanceConsoleProps {
  isOpen: boolean;
  onToggleOpen: () => void;
  activeSelectedComponentDefId?: string;
  activeSelectedInstanceId?: string | null;
  activeSelectedInstanceError?: string;
  currentWorkflow: OrchestratorWorkflow | null;
  activeQuest?: Quest | null;
  activeStepId?: string | null;
  onPerformOrchestratorAction?: (action: OrchestratorActionPayload) => void;
}

export const NoemasGuidanceConsole: React.FC<NoemasGuidanceConsoleProps> = ({
  isOpen,
  onToggleOpen,
  activeSelectedComponentDefId,
  activeSelectedInstanceId,
  activeSelectedInstanceError,
  currentWorkflow,
  activeQuest,
  activeStepId,
  onPerformOrchestratorAction,
}) => {
  if (!isOpen) {
    return (
        <button 
            onClick={onToggleOpen} 
            className="fixed bottom-4 right-4 p-3 bg-purple-600 hover:bg-purple-700 text-white rounded-full shadow-lg z-50"
            title="Open Noema's Guidance Console"
            aria-label="Open Noema's Guidance Console"
        >
            <Icon name="MessageCircleMore" size={24} />
        </button>
    );
  }

  const selectedDef = ORCHESTRATOR_COMPONENT_DEFS.find(def => def.id === activeSelectedComponentDefId);

  return (
    <div className="fixed inset-y-0 right-0 w-80 md:w-96 bg-slate-800 text-slate-100 shadow-2xl z-50 p-4 flex flex-col border-l border-slate-700 transform transition-transform duration-300 ease-in-out"
         style={{ transform: isOpen ? 'translateX(0)' : 'translateX(100%)' }}
         role="complementary"
         aria-labelledby="guidance-console-title"
    >
      <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-700">
        <h2 id="guidance-console-title" className="text-lg font-semibold text-sky-300 flex items-center">
            <Icon name="Lightbulb" size={20} className="mr-2 text-yellow-400"/>
            Noema's Guidance
        </h2>
        <button onClick={onToggleOpen} className="p-1 text-slate-400 hover:text-white" title="Close Console" aria-label="Close Guidance Console">
            <Icon name="XSquare" size={20} />
        </button>
      </div>
      
      <div className="flex-grow overflow-y-auto custom-scrollbar space-y-4 pr-1">
        <p className="text-sm text-slate-300 italic">
          Guidance Console Placeholder. Detailed contextual help and insights will appear here.
        </p>
        {activeSelectedComponentDefId && selectedDef && (
            <div className="p-3 bg-slate-700/50 rounded-md border border-slate-600">
                <h4 className="text-md font-semibold text-sky-200 mb-1 flex items-center">
                    <Icon name={selectedDef.icon} size={16} className="mr-2"/>
                    Selected: {selectedDef.name}
                </h4>
                <p className="text-xs text-slate-300 mb-1">{selectedDef.description}</p>
                {activeSelectedInstanceId && (
                    <p className="text-xs text-teal-300">Instance ID: {activeSelectedInstanceId.substring(0,8)}...</p>
                )}
                {activeSelectedInstanceError && (
                    <div className="mt-2 p-2 bg-red-800/70 rounded-md">
                        <p className="text-xs font-semibold text-red-300">Error:</p>
                        <p className="text-xs text-red-200">{activeSelectedInstanceError}</p>
                    </div>
                )}
            </div>
        )}
        {/* Add more contextual information based on other props like currentWorkflow, activeQuest, etc. */}
      </div>
    </div>
  );
};
