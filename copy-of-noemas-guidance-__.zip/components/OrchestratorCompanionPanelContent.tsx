import React, { useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; 
import { Icon } from './Icon.tsx'; 
import { OrchestratorInstance, OrchestratorComponentDefinition, OrchestratorNodeDefinition, OrchestratorComponentConfigField, OrchestratorWorkflow } from '../types.ts';
import { ORCHESTRATOR_COMPONENT_DEFS } from '../constants.ts';
import { HelpCircle, Info, SlidersHorizontal } from 'lucide-react';
import Tooltip from './Tooltip.tsx';

const OrchestratorCompanionPanelContent: React.FC = () => {
  const { selectedOrchestratorInstanceId, orchestratorWorkflowForContext } = useAppContext();

  const getDefById = (id?: string): OrchestratorComponentDefinition | undefined => {
    return id ? ORCHESTRATOR_COMPONENT_DEFS.find(def => def.id === id) : undefined;
  };

  const selectedInstance: OrchestratorInstance | null | undefined = useMemo(() => {
    if (!selectedOrchestratorInstanceId || !orchestratorWorkflowForContext) return null;
    return orchestratorWorkflowForContext.instances.find(inst => inst.id === selectedOrchestratorInstanceId);
  }, [selectedOrchestratorInstanceId, orchestratorWorkflowForContext]);

  const selectedDefinition: OrchestratorComponentDefinition | null | undefined = useMemo(() => {
    return selectedInstance ? getDefById(selectedInstance.componentDefId) : null;
  }, [selectedInstance]);

  const renderNodeList = (nodes: OrchestratorNodeDefinition[], type: 'Input' | 'Output') => (
    <div className="mt-2">
      <h4 className="text-sm font-semibold text-purple-300 mb-1">{type}s:</h4>
      {nodes.length === 0 ? (
        <p className="text-xs text-slate-400 italic">No {type.toLowerCase()}s defined.</p>
      ) : (
        <ul className="space-y-1 text-xs">
          {nodes.map(node => (
            <li key={node.id} className="p-1.5 bg-slate-700/50 rounded-md">
              <div className="flex justify-between items-center">
                <span className="font-medium text-slate-200">{node.label}</span>
                <span className="px-1.5 py-0.5 bg-slate-600 text-slate-300 rounded-full text-[10px]">{node.dataType}</span>
              </div>
              {node.nodeDescription && <p className="text-slate-400 mt-0.5">{node.nodeDescription}</p>}
              {node.isOptional && <p className="text-slate-500 text-[10px]">(Optional)</p>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );

  const renderConfigFields = (fields: OrchestratorComponentConfigField[], currentValues: Record<string, any>) => (
    <div className="mt-3">
      <h4 className="text-sm font-semibold text-purple-300 mb-1 flex items-center">
        <SlidersHorizontal size={14} className="mr-1.5" />
        Configuration:
      </h4>
      {fields.length === 0 ? (
        <p className="text-xs text-slate-400 italic">No configurable parameters.</p>
      ) : (
        <ul className="space-y-1.5 text-xs">
          {fields.map(field => {
            const value = currentValues[field.id] ?? field.defaultValue ?? 'Not set';
            let displayValue = String(value);
            if (typeof value === 'boolean') displayValue = value ? 'Enabled' : 'Disabled';
            if (displayValue.length > 50 && field.type !== 'textarea') displayValue = displayValue.substring(0, 47) + '...';

            return (
              <li key={field.id} className="p-1.5 bg-slate-700/50 rounded-md">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-slate-200">{field.label}</span>
                  {field.helpText && (
                    <Tooltip content={field.helpText} position="left" delay={100}>
                       <HelpCircle size={12} className="text-slate-400 hover:text-sky-300 cursor-help" />
                    </Tooltip>
                  )}
                </div>
                <p className="text-slate-300 mt-0.5 whitespace-pre-wrap break-words">Value: <span className="text-sky-300">{displayValue}</span></p>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );

  return (
    <div className="p-3 h-full overflow-y-auto custom-scrollbar bg-slate-800 text-slate-100">
      <h3 className="text-lg font-semibold text-sky-400 mb-2 flex items-center">
        <Icon name="Binary" size={20} className="mr-2"/>
        Orchestrator Companion
      </h3>
      
      {!selectedInstance || !selectedDefinition ? (
        <div className="text-center text-slate-400 mt-10">
          <Icon name="MousePointer" size={32} className="mx-auto mb-2 opacity-50"/>
          <p className="text-sm">Select a component on the canvas to see its details here.</p>
          <p className="text-xs mt-4 italic">You can also ask Noema in the main console for help with specific components or general workflow patterns.</p>
        </div>
      ) : (
        <div className="space-y-3">
          <div>
            <div className="flex items-center mb-0.5">
                <Icon name={selectedDefinition.icon} size={18} className="mr-2 text-sky-300 flex-shrink-0" />
                <h2 className="text-md font-bold text-sky-300 truncate" title={selectedInstance.customName || selectedDefinition.name}>
                {selectedInstance.customName || selectedDefinition.name}
                </h2>
            </div>
            <p className="text-xs text-purple-400 uppercase tracking-wider ml-7">{selectedDefinition.category}</p>
          </div>

          <div className="p-2 bg-slate-700/30 rounded-md">
            <p className="text-xs text-slate-300 leading-relaxed">{selectedDefinition.description}</p>
          </div>

          {selectedDefinition.usageAnalogy && (
            <div className="p-2 bg-teal-800/40 rounded-md border border-teal-700">
                <h4 className="text-xs font-semibold text-teal-300 mb-0.5 flex items-center">
                    <Icon name="Lightbulb" size={12} className="mr-1"/> Usage Analogy:
                </h4>
                <p className="text-xs text-teal-200 italic">{selectedDefinition.usageAnalogy}</p>
            </div>
          )}
          
          {renderNodeList(selectedDefinition.inputs, 'Input')}
          {renderNodeList(selectedDefinition.outputs, 'Output')}
          {renderConfigFields(selectedDefinition.configFields || [], selectedInstance.configValues)}
        </div>
      )}
    </div>
  );
};

export default OrchestratorCompanionPanelContent;