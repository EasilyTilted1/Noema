
import React from 'react'; 
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { IS_CONTENT_UNLOCKED_FOR_TESTING } from '../constants.ts';
import OrchestratorCompanionPanelContent from './OrchestratorCompanionPanelContent.tsx';

const Sidebar: React.FC = () => {
  const {
    userProgress,
    resetUserProgressAndLibrary,
    userId,
    toggleTTS, isTTSEnabled,
    currentView,
  } = useAppContext();

  if (!userProgress) return null;

  if (currentView === 'agent_orchestrator_sandbox') {
    return (
      <aside className="w-64 md:w-72 bg-slate-800 p-0 space-y-0 overflow-y-auto custom-scrollbar border-r border-slate-700 flex-shrink-0">
        <OrchestratorCompanionPanelContent />
      </aside>
    );
  }

  return (
    <aside className="w-64 md:w-72 bg-slate-800 p-4 space-y-4 overflow-y-auto custom-scrollbar border-r border-slate-700 flex-shrink-0">
      <div>
        <h2 className="text-lg font-semibold text-sky-400 mb-2 flex items-center">
          <Icon name="UserCircle" size={20} className="mr-2"/> User Profile
        </h2>
        <div className="text-sm space-y-1.5 text-slate-300 bg-slate-700/50 p-3 rounded-md">
          <p><strong className="text-slate-100">Name:</strong> {userProgress.displayName}</p>
          <p><strong className="text-slate-100">XP:</strong> {userProgress.xp}</p>
          <p><strong className="text-slate-100">Badges:</strong> {userProgress.unlockedBadgeIds.length}</p>
          {IS_CONTENT_UNLOCKED_FOR_TESTING && userId && (
             <p className="text-xs text-slate-400">
                <strong className="text-slate-300">UID:</strong> <span className="break-all">{userId.substring(0,8)}...</span>
            </p>
          )}
        </div>
      </div>

      <div className="pt-4 border-t border-slate-700 space-y-2">
         <button
            onClick={toggleTTS}
            title={isTTSEnabled ? "Disable Text-to-Speech" : "Enable Text-to-Speech"}
            className="w-full flex items-center justify-center px-3 py-2 bg-slate-600 hover:bg-slate-500 text-white rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-1 focus:ring-sky-500"
        >
            <Icon name={isTTSEnabled ? "Volume2" : "VolumeX"} size={16} className="mr-2" />
            {isTTSEnabled ? "TTS On" : "TTS Off"}
        </button>
        <button
          onClick={resetUserProgressAndLibrary}
          className="w-full flex items-center justify-center px-3 py-2 bg-red-700 hover:bg-red-600 text-white rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-1 focus:ring-red-500"
          title="Reset all progress, library, notebook, and story vault entries. This cannot be undone."
        >
          <Icon name="RotateCcw" size={16} className="mr-2" />
          Reset Progress
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
