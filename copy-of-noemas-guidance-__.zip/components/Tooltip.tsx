
import React, { useState, useCallback } from 'react';

interface TooltipProps {
  content: React.ReactNode;
  children: React.ReactElement<React.HTMLAttributes<HTMLElement>>; 
  delay?: number; 
  position?: 'top' | 'bottom' | 'left' | 'right' | 'mouse'; 
}

const Tooltip: React.FC<TooltipProps> = ({ content, children, delay = 300, position = 'mouse' }) => {
  const [visible, setVisible] = useState(false);
  const [coords, setCoords] = useState({ x: 0, y: 0 });
  let timeoutId: ReturnType<typeof setTimeout> | null = null;

  const showTooltip = useCallback((e: React.MouseEvent) => {
    if (timeoutId) clearTimeout(timeoutId);
    
    const targetElement = e.currentTarget;
    if (!(targetElement instanceof HTMLElement)) {
        return; 
    }

    timeoutId = setTimeout(() => {
      const rect = targetElement.getBoundingClientRect();
      let xPos = 0, yPos = 0;

      if (position === 'mouse') {
        xPos = e.clientX + 10;
        yPos = e.clientY + 10;
      } else if (position === 'top') {
        xPos = rect.left + rect.width / 2; 
        yPos = rect.top - 10; 
      } else if (position === 'bottom') {
        xPos = rect.left + rect.width / 2; 
        yPos = rect.bottom + 10; 
      } else { 
        xPos = e.clientX + 10;
        yPos = e.clientY + 10;
      }
      setCoords({ x: xPos, y: yPos });
      setVisible(true);
    }, delay);
  }, [delay, position]);

  const hideTooltip = useCallback(() => {
    if (timeoutId) clearTimeout(timeoutId);
    setVisible(false);
  }, []);
  
  const handleMouseMove = (e: React.MouseEvent) => {
      if (visible && position === 'mouse') {
          setCoords({ x: e.clientX + 10, y: e.clientY + 10 });
      }
  };
  
  let transformOriginClass = '';
  if (position === 'top') transformOriginClass = 'transform-origin-bottom';
  if (position === 'bottom') transformOriginClass = 'transform-origin-top';

  return (
    <>
      {React.cloneElement(children, {
        onMouseEnter: showTooltip,
        onMouseLeave: hideTooltip,
        onMouseMove: handleMouseMove,
      })}
      {visible && (
        <div
          style={{
            position: 'fixed',
            top: coords.y,
            left: coords.x,
            pointerEvents: 'none',
            zIndex: 1050, 
            transform: position === 'top' || position === 'bottom' ? 'translateX(-50%)' : 'none', 
          }}
          className={`bg-slate-700 text-slate-100 text-xs p-2 rounded-md shadow-xl border border-slate-600 max-w-sm break-words ${transformOriginClass}`}
          role="tooltip"
        >
          {content}
        </div>
      )}
    </>
  );
};

export default Tooltip;
