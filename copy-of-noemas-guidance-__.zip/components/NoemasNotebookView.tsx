
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { NotebookEntry, NotebookEntryType, StoryForgeSession, IconName, TextPart, ChatMessagePart, ScenarioOutput } from '../types.ts'; 
import { ALL_QUESTS } from '../constants.ts';

const NOTE_TYPE_ICONS: Record<NotebookEntryType, IconName> = {
  user_note: 'StickyNote',
  aha_moment: 'Lightbulb',
  question_for_later: 'HelpCircle',
  story_fragment: 'Scroll',
  lore_entry: 'Gem',
  story_snapshot: 'BookCopy',
  scenario_lab_result: 'FlaskConical', 
};

const NOTE_TYPE_LABELS: Record<NotebookEntryType, string> = {
  user_note: 'User Note',
  aha_moment: 'Aha! Moment',
  question_for_later: 'Question for Later',
  story_fragment: 'Story Fragment',
  lore_entry: 'Lore Entry',
  story_snapshot: 'Story Snapshot',
  scenario_lab_result: 'Scenario Lab Result', 
};

const selectableNoteTypesForForm: Exclude<NotebookEntryType, 'story_snapshot' | 'scenario_lab_result'>[] = [
  'user_note',
  'aha_moment',
  'question_for_later',
  'story_fragment',
  'lore_entry',
];

interface NotebookEntryFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: Omit<NotebookEntry, 'id' | 'createdAt' | 'updatedAt'> | NotebookEntry) => void;
  entryToEdit?: NotebookEntry | null;
}

const NotebookEntryFormModal: React.FC<NotebookEntryFormModalProps> = ({ isOpen, onClose, onSave, entryToEdit }) => {
  const { addToast } = useAppContext(); 
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [type, setType] = useState<Exclude<NotebookEntryType, 'story_snapshot' | 'scenario_lab_result'>>('user_note');
  const [questId, setQuestId] = useState<string | undefined>(undefined);
  const [stepId, setStepId] = useState<string | undefined>(undefined);
  const [tags, setTags] = useState('');

  useEffect(() => {
    if (entryToEdit) {
      setTitle(entryToEdit.title || '');
      setContent(typeof entryToEdit.content === 'string' ? entryToEdit.content : '');
      setType(entryToEdit.type === 'story_snapshot' || entryToEdit.type === 'scenario_lab_result' ? 'user_note' : entryToEdit.type); 
      setQuestId(entryToEdit.questId);
      setStepId(entryToEdit.stepId);
      setTags((entryToEdit.tags || []).join(', '));
    } else {
      setTitle(''); setContent(''); setType('user_note');
      setQuestId(undefined); setStepId(undefined); setTags('');
    }
  }, [entryToEdit, isOpen]);

  const availableSteps = useMemo(() => {
    if (!questId) return [];
    const selectedQuest = ALL_QUESTS.find(q => q.id === questId);
    return selectedQuest ? selectedQuest.steps : [];
  }, [questId]);


  const handleSubmit = (e?: React.FormEvent) => { 
    if (e) e.preventDefault();
    
    const isEditingSpecialType = entryToEdit && (entryToEdit.type === 'story_snapshot' || entryToEdit.type === 'scenario_lab_result');

    if (!isEditingSpecialType && !content.trim()) {
      addToast("Content cannot be empty for this note type.", "error");
      return;
    }

    let finalTitle: string;
    let finalContent: any;
    let finalType: NotebookEntryType;

    if (isEditingSpecialType && entryToEdit) {
        finalTitle = title.trim() || (entryToEdit.title || `Untitled ${NOTE_TYPE_LABELS[entryToEdit.type]}`);
        finalContent = entryToEdit.content; 
        finalType = entryToEdit.type;
    } else {
        finalTitle = title.trim() || `Untitled ${NOTE_TYPE_LABELS[type]}`;
        finalContent = content;
        finalType = type; 
    }
    
    const entryData = {
      title: finalTitle,
      content: finalContent,
      type: finalType,
      questId: questId || undefined,
      stepId: stepId || undefined,
      tags: tags.split(',').map(tag => tag.trim()).filter(Boolean),
    };

    if (entryToEdit && 'id' in entryToEdit) { 
        onSave({ ...entryToEdit, ...entryData, updatedAt: Date.now() } as NotebookEntry);
    } else {
        onSave(entryData as Omit<NotebookEntry, 'id' | 'createdAt' | 'updatedAt'>);
    }
    onClose();
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[100] p-4 backdrop-blur-sm">
      <div className="bg-slate-800 p-6 rounded-lg shadow-2xl max-w-lg w-full border border-slate-700 max-h-[90vh] flex flex-col">
        <h3 className="text-xl font-semibold text-sky-300 mb-4">{entryToEdit ? 'Edit Entry' : 'Add New Entry'}</h3>
        
        {entryToEdit?.type === 'story_snapshot' || entryToEdit?.type === 'scenario_lab_result' ? (
          <div className="text-slate-300 mb-4 flex-grow overflow-y-auto custom-scrollbar pr-2">
            <p className="text-sm">Editing metadata for a {NOTE_TYPE_LABELS[entryToEdit.type]}. Content is viewed separately.</p>
             <div className="mt-3">
              <label htmlFor="entryTypeDisplay" className="block text-sm font-medium text-slate-300 mb-1">Type</label>
              <input type="text" id="entryTypeDisplay" value={NOTE_TYPE_LABELS[entryToEdit.type]} readOnly className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-400 cursor-not-allowed"/>
            </div>
            <div className="mt-3">
              <label htmlFor="entryTitleSnapshot" className="block text-sm font-medium text-slate-300 mb-1">Title</label>
              <input type="text" id="entryTitleSnapshot" value={title} onChange={e => setTitle(e.target.value)} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none" placeholder="Entry Title"/>
            </div>
             <div>
              <label htmlFor="entryQuest" className="block text-sm font-medium text-slate-300 mb-1 mt-2">Related Quest (Optional)</label>
              <select id="entryQuest" value={questId || ''} onChange={e => {setQuestId(e.target.value || undefined); setStepId(undefined);}} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none">
                <option value="">None</option>
                {ALL_QUESTS.map(q => <option key={q.id} value={q.id}>{q.title}</option>)}
              </select>
            </div>
            {questId && availableSteps.length > 0 && (
              <div>
                <label htmlFor="entryStep" className="block text-sm font-medium text-slate-300 mb-1 mt-2">Related Step (Optional)</label>
                <select id="entryStep" value={stepId || ''} onChange={e => setStepId(e.target.value || undefined)} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none">
                  <option value="">None</option>
                  {availableSteps.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                </select>
              </div>
            )}
            <div>
              <label htmlFor="entryTags" className="block text-sm font-medium text-slate-300 mb-1 mt-2">Tags (Optional, comma-separated)</label>
              <input type="text" id="entryTags" value={tags} onChange={e => setTags(e.target.value)} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none" placeholder="idea, important, chapter1"/>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto custom-scrollbar pr-2 flex-grow">
            <div>
              <label htmlFor="entryType" className="block text-sm font-medium text-slate-300 mb-1">Type</label>
              <select
                id="entryType"
                value={type} 
                onChange={e => setType(e.target.value as Exclude<NotebookEntryType, 'story_snapshot' | 'scenario_lab_result'>)}
                className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none"
              >
                {selectableNoteTypesForForm.map((typeKey) => (
                  <option key={typeKey} value={typeKey}>{NOTE_TYPE_LABELS[typeKey]}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="entryTitle" className="block text-sm font-medium text-slate-300 mb-1">Title (Optional)</label>
              <input type="text" id="entryTitle" value={title} onChange={e => setTitle(e.target.value)} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none" placeholder="My Brilliant Idea"/>
            </div>
            <div>
              <label htmlFor="entryContent" className="block text-sm font-medium text-slate-300 mb-1">Content</label>
              <textarea id="entryContent" value={content} onChange={e => setContent(e.target.value)} rows={5} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none custom-scrollbar" placeholder="Jot down your notes..."></textarea>
            </div>
            <div>
              <label htmlFor="entryQuest" className="block text-sm font-medium text-slate-300 mb-1">Related Quest (Optional)</label>
              <select id="entryQuest" value={questId || ''} onChange={e => {setQuestId(e.target.value || undefined); setStepId(undefined);}} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none">
                <option value="">None</option>
                {ALL_QUESTS.map(q => <option key={q.id} value={q.id}>{q.title}</option>)}
              </select>
            </div>
            {questId && availableSteps.length > 0 && (
              <div>
                <label htmlFor="entryStep" className="block text-sm font-medium text-slate-300 mb-1">Related Step (Optional)</label>
                <select id="entryStep" value={stepId || ''} onChange={e => setStepId(e.target.value || undefined)} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none">
                  <option value="">None</option>
                  {availableSteps.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                </select>
              </div>
            )}
            <div>
              <label htmlFor="entryTags" className="block text-sm font-medium text-slate-300 mb-1">Tags (Optional, comma-separated)</label>
              <input type="text" id="entryTags" value={tags} onChange={e => setTags(e.target.value)} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-sky-500 outline-none" placeholder="idea, important, chapter1"/>
            </div>
          </form>
        )}
         <div className="flex justify-end space-x-3 mt-5 pt-4 border-t border-slate-700">
          <button onClick={onClose} className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-100 rounded-md transition-colors">Cancel</button>
          <button onClick={() => handleSubmit()} className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-md transition-colors">
            {entryToEdit ? 'Save Changes' : 'Add Entry'}
          </button>
        </div>
      </div>
    </div>
  );
};

const ScenarioLabResultModal: React.FC<{isOpen: boolean, onClose: () => void, scenarioOutput: ScenarioOutput | null, originalConcept: string}> = ({isOpen, onClose, scenarioOutput, originalConcept}) => {
    if (!isOpen || !scenarioOutput) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
            <div className="bg-slate-800 p-5 rounded-lg shadow-2xl max-w-2xl w-full border border-slate-700 max-h-[90vh] flex flex-col">
                <div className="flex justify-between items-center mb-3">
                    <h3 className="text-xl font-semibold text-sky-300">Scenario: {scenarioOutput.titleSuggestion}</h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-white"><Icon name="XSquare" size={20}/></button>
                </div>
                <div className="flex-grow overflow-y-auto custom-scrollbar pr-2 space-y-3 text-sm">
                    <p className="text-xs text-slate-400">Based on concept: "{originalConcept}"</p>
                    
                    <div><strong className="text-purple-300">Key Elements/Characters:</strong><ul className="list-disc list-inside ml-4 text-slate-200">{scenarioOutput.keyElementsAndCharacters.map((el,i)=><li key={i}>{el}</li>)}</ul></div>
                    <div><strong className="text-purple-300">Potential Plot Points:</strong><ul className="list-disc list-inside ml-4 text-slate-200">{scenarioOutput.potentialPlotPoints.map((pp,i)=><li key={i}>{pp}</li>)}</ul></div>
                    <div><strong className="text-purple-300">Atmospheric Descriptors:</strong><p className="text-slate-200 italic">{scenarioOutput.atmosphericDescriptors.join(', ')}</p></div>
                    
                    <div>
                        <strong className="text-purple-300">Dialogue Snippet:</strong>
                        <blockquote className="mt-1 p-2 bg-slate-700/50 border-l-4 border-slate-500 text-slate-200 italic whitespace-pre-wrap">{scenarioOutput.dialogueSnippet}</blockquote>
                    </div>

                    <div>
                        <strong className="text-purple-300">Storyboard Prompts:</strong>
                        {scenarioOutput.storyboardPrompts.map((sp, i) => (
                            <div key={i} className="mt-1 p-2 bg-slate-700/50 rounded-md">
                            <p className="font-medium text-slate-100">Scene {i+1}: <span className="font-normal text-slate-300">{sp.description}</span></p>
                            <p className="text-xs text-teal-400 mt-0.5 truncate" title={sp.imageGenPrompt}>Prompt: {sp.imageGenPrompt}</p>
                            </div>
                        ))}
                    </div>
                </div>
                 <div className="mt-4 pt-3 border-t border-slate-600 text-right">
                    <button onClick={onClose} className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-100 rounded-md transition-colors">Close</button>
                </div>
            </div>
        </div>
    );
};


const StorySnapshotModal: React.FC<{isOpen: boolean, onClose: () => void, storySession: StoryForgeSession | null}> = ({isOpen, onClose, storySession}) => {
    if (!isOpen || !storySession) return null;
    
    const extractText = (parts: ChatMessagePart[]) => parts.filter(p => 'text' in p).map(p => (p as TextPart).text).join('\n');

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
            <div className="bg-slate-800 p-5 rounded-lg shadow-2xl max-w-2xl w-full border border-slate-700 max-h-[90vh] flex flex-col">
                <div className="flex justify-between items-center mb-3">
                    <h3 className="text-xl font-semibold text-sky-300">Story Snapshot: {storySession.title}</h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-white"><Icon name="XSquare" size={20}/></button>
                </div>
                <div className="flex-grow overflow-y-auto custom-scrollbar pr-2 space-y-4">
                    <div>
                        <h4 className="text-md font-semibold text-purple-300 mb-1">Story Content:</h4>
                        <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar bg-slate-700/50 p-2 rounded-md">
                            {storySession.fullStory.map(msg => ( 
                                <div key={msg.id} className={`p-1.5 rounded-md text-xs ${msg.role === 'user' ? 'bg-sky-800/50 text-right' : msg.role === 'model' ? 'bg-purple-800/40 text-left' : 'bg-slate-600/50 text-center'}`}>
                                    <span className="font-bold">{msg.role === 'user' ? 'You' : msg.role === 'model' ? 'Narrator' : 'System'}: </span>
                                    {extractText(msg.parts)}
                                </div>
                            ))}
                        </div>
                    </div>
                    {storySession.loreNotes && Object.keys(storySession.loreNotes).length > 0 && ( 
                        <div>
                            <h4 className="text-md font-semibold text-purple-300 mb-1">Lore Items:</h4>
                            <div className="grid grid-cols-2 gap-2 text-xs">
                                {Object.entries(storySession.loreNotes).map(([category, items]) => ( 
                                    items && items.length > 0 && <div key={category} className="bg-slate-700/50 p-2 rounded">
                                        <p className="font-semibold text-purple-400">{category}</p>
                                        <ul className="list-disc list-inside pl-1">
                                            {items.map((item: string, idx: number) => <li key={idx} className="text-slate-300">{item}</li>)}
                                        </ul>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    {storySession.generatedVisuals && Object.keys(storySession.generatedVisuals).length > 0 && (
                        <div>
                             <h4 className="text-md font-semibold text-purple-300 mb-1">Visuals:</h4>
                             <div className="grid grid-cols-2 gap-2">
                                {Object.entries(storySession.generatedVisuals).map(([key, vis]) => (
                                    <div key={key} className="bg-slate-700/50 p-1 rounded">
                                        <img src={`data:image/jpeg;base64,${vis.imageBase64}`} alt={`Visual for ${vis.imagePrompt}`} className="rounded max-h-32 object-contain mx-auto"/>
                                        <p className="text-xs text-slate-400 mt-1 truncate" title={vis.imagePrompt}>{vis.imagePrompt}</p>
                                    </div>
                                ))}
                             </div>
                        </div>
                    )}
                </div>
                 <div className="mt-4 pt-3 border-t border-slate-600 text-right">
                    <button onClick={onClose} className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-100 rounded-md transition-colors">Close</button>
                </div>
            </div>
        </div>
    );
};


const NotebookEntryCard: React.FC<{ entry: NotebookEntry; onEdit: (entry: NotebookEntry) => void; onDelete: (id: string) => void; onViewSnapshot: (session: StoryForgeSession) => void; onViewScenario: (scenario: ScenarioOutput, originalConcept: string) => void; }> = ({ entry, onEdit, onDelete, onViewSnapshot, onViewScenario }) => {
  const iconName = NOTE_TYPE_ICONS[entry.type] || ('FileText' as IconName); 
  const typeLabel = NOTE_TYPE_LABELS[entry.type] || entry.type;

  let displayContent = "";
  let originalConceptForScenario = "";

  if (entry.type === 'story_snapshot') {
    displayContent = `A snapshot of your story: "${(entry.content as StoryForgeSession)?.title || 'Untitled Story'}". Click "View Details".`;
  } else if (entry.type === 'scenario_lab_result') {
    const scenario = entry.content as ScenarioOutput;
    originalConceptForScenario = entry.tags?.find(tag => tag !== 'scenario_lab') || "Unknown Concept"; 
    displayContent = `Scenario: "${scenario.titleSuggestion || 'Untitled Scenario'}". Click "View Details".`;
  } else {
    displayContent = String(entry.content);
  }


  return (
    <div className="bg-slate-800 p-4 rounded-lg shadow-lg border border-slate-700 hover:shadow-purple-900/50 transition-shadow duration-300 flex flex-col justify-between">
      <div>
        <div className="flex items-start justify-between mb-1">
          <h3 className="text-md font-semibold text-purple-300 flex items-center">
            <Icon name={iconName} size={18} className="mr-2 text-purple-400" />
            {entry.title || `Untitled ${typeLabel}`}
          </h3>
          <span className="text-xs text-slate-500 whitespace-nowrap">{new Date(entry.createdAt).toLocaleDateString()}</span>
        </div>
        <p className="text-xs text-slate-400 mb-2 uppercase tracking-wider">{typeLabel}</p>
        
        <p className={`text-sm text-slate-300 leading-relaxed line-clamp-3 ${entry.type === 'story_snapshot' || entry.type === 'scenario_lab_result' ? 'italic' : ''}`}>{displayContent}</p>

        {entry.tags && entry.tags.length > 0 && (
          <div className="mt-2 space-x-1">
            {entry.tags.slice(0,3).map(tag => <span key={tag} className="text-xs bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded">{tag}</span>)}
            {entry.tags.length > 3 && <span className="text-xs text-slate-500">...</span>}
          </div>
        )}
      </div>
      <div className="mt-3 pt-3 border-t border-slate-700 flex items-center space-x-2">
        {entry.type === 'story_snapshot' && entry.content && typeof entry.content === 'object' ? ( 
           <button onClick={() => onViewSnapshot(entry.content as StoryForgeSession)} title="View Story Details" className="p-2 bg-sky-600 hover:bg-sky-700 text-white rounded-md transition-colors flex-grow flex items-center justify-center text-sm">
              <Icon name="BookOpen" size={16} className="mr-1.5" /> View Details
            </button>
        ) : entry.type === 'scenario_lab_result' && entry.content && typeof entry.content === 'object' ? (
            <button onClick={() => onViewScenario(entry.content as ScenarioOutput, originalConceptForScenario)} title="View Scenario Details" className="p-2 bg-teal-600 hover:bg-teal-700 text-white rounded-md transition-colors flex-grow flex items-center justify-center text-sm">
              <Icon name="TestTube2" size={16} className="mr-1.5" /> View Scenario
            </button>
        ) : ( 
            <button onClick={() => onEdit(entry)} title="Edit Entry" className="p-2 bg-sky-600 hover:bg-sky-700 text-white rounded-md transition-colors flex-grow flex items-center justify-center text-sm">
            <Icon name="Edit3" size={16} className="mr-1.5" /> Edit
            </button>
        )}
        <button onClick={() => onDelete(entry.id)} title="Delete Entry" className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-md transition-colors">
          <Icon name="Trash2" size={16} />
        </button>
      </div>
    </div>
  );
};

const NoemasNotebookView: React.FC = () => {
  const { userProgress, addNotebookEntry, updateNotebookEntry, deleteNotebookEntry, speak, showModal, hideModal } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | NotebookEntryType>('all');
  const [sortOrder, setSortOrder] = useState<'createdAt_desc' | 'createdAt_asc' | 'updatedAt_desc' | 'title_asc'>('createdAt_desc');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<NotebookEntry | null>(null);

  const [isSnapshotModalOpen, setIsSnapshotModalOpen] = useState(false);
  const [viewingSnapshot, setViewingSnapshot] = useState<StoryForgeSession | null>(null);

  const [isScenarioModalOpen, setIsScenarioModalOpen] = useState(false);
  const [viewingScenario, setViewingScenario] = useState<ScenarioOutput | null>(null);
  const [viewingScenarioOriginalConcept, setViewingScenarioOriginalConcept] = useState<string>("");


  useEffect(() => {
    speak("This is Noema's Notebook. Track your ideas and story snippets here.");
  }, [speak]);

  const entries = userProgress?.noemasNotebookEntries || [];

  const filteredAndSortedEntries = useMemo(() => {
    return entries
      .filter(item => {
        const typeMatch = filterType === 'all' || item.type === filterType;
        if (!typeMatch) return false;
        const lowerSearchTerm = searchTerm.toLowerCase();
        
        let contentForSearch = "";
        if (item.type === 'story_snapshot') {
            contentForSearch = (item.content as StoryForgeSession)?.title || '';
        } else if (item.type === 'scenario_lab_result') {
            contentForSearch = (item.content as ScenarioOutput)?.titleSuggestion || '';
        } else {
            contentForSearch = String(item.content);
        }

        return (
          (item.title || '').toLowerCase().includes(lowerSearchTerm) ||
          contentForSearch.toLowerCase().includes(lowerSearchTerm) ||
          (item.tags && item.tags.some(tag => tag.toLowerCase().includes(lowerSearchTerm)))
        );
      })
      .sort((a, b) => {
        switch (sortOrder) {
          case 'createdAt_asc': return a.createdAt - b.createdAt;
          case 'updatedAt_desc': return b.updatedAt - a.updatedAt;
          case 'title_asc': return (a.title || '').localeCompare(b.title || '');
          case 'createdAt_desc': default: return b.createdAt - a.createdAt;
        }
      });
  }, [entries, searchTerm, filterType, sortOrder]);

  const handleAddNew = () => { setEditingEntry(null); setIsModalOpen(true); };
  const handleEdit = (entry: NotebookEntry) => { setEditingEntry(entry); setIsModalOpen(true); };

  const handleDelete = (id: string) => {
    const entry = entries.find(e => e.id === id);
    showModal({
        title: "Confirm Delete", content: `Delete "${entry?.title || 'this note'}"?`,
        confirmText: "Delete", onConfirm: () => { deleteNotebookEntry(id); hideModal(); },
        cancelText: "Cancel", onCancel: hideModal
    });
  };
  
  const handleSaveEntry = (entryData: Omit<NotebookEntry, 'id' | 'createdAt' | 'updatedAt'> | NotebookEntry) => {
    if ('id' in entryData) updateNotebookEntry(entryData as NotebookEntry);
    else addNotebookEntry(entryData);
  };

  const handleViewSnapshot = (session: StoryForgeSession) => { setViewingSnapshot(session); setIsSnapshotModalOpen(true); };
  const handleViewScenario = (scenario: ScenarioOutput, originalConcept: string) => { setViewingScenario(scenario); setViewingScenarioOriginalConcept(originalConcept); setIsScenarioModalOpen(true); };


  return (
    <div className="p-4 md:p-6 h-full flex flex-col">
      <div className="mb-6 text-center"><Icon name="NotebookText" size={48} className="text-purple-400 mx-auto mb-3" /><h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-sky-500">Noema's Notebook</h1><p className="text-slate-400 mt-1">Your space for ideas, reflections, and story elements.</p></div>
      <div className="mb-4 sticky top-0 bg-slate-900 py-3 z-10 flex flex-col md:flex-row gap-3 items-center border-b border-slate-700 pb-4">
        <div className="relative flex-grow w-full md:w-auto"><input type="text" placeholder="Search notes..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full p-3 pl-10 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:ring-2 focus:ring-purple-500 outline-none transition-colors"/><Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500" /></div>
        <select value={filterType} onChange={(e) => setFilterType(e.target.value as any)} className="p-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:ring-2 focus:ring-purple-500 outline-none md:h-full"><option value="all">All Types</option>{Object.entries(NOTE_TYPE_LABELS).map(([key, label]) => (<option key={key} value={key}>{label}</option>))}</select>
        <select value={sortOrder} onChange={(e) => setSortOrder(e.target.value as any)} className="p-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:ring-2 focus:ring-purple-500 outline-none md:h-full"><option value="createdAt_desc">Newest</option><option value="createdAt_asc">Oldest</option><option value="updatedAt_desc">Updated</option><option value="title_asc">Title</option></select>
        <button onClick={handleAddNew} className="px-4 py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-medium flex items-center space-x-2 w-full md:w-auto justify-center md:h-full"><Icon name="PlusCircle" size={18} /><span>Add New</span></button>
      </div>
      {filteredAndSortedEntries.length > 0 ? (<div className="flex-grow overflow-y-auto custom-scrollbar pr-1 pb-4"><div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">{filteredAndSortedEntries.map(item => (<NotebookEntryCard key={item.id} entry={item} onEdit={handleEdit} onDelete={handleDelete} onViewSnapshot={handleViewSnapshot} onViewScenario={handleViewScenario}/>))}</div></div>) 
      : (<div className="text-center text-slate-500 py-10 flex-grow flex flex-col items-center justify-center"><Icon name="ArchiveX" size={40} className="mx-auto mb-3"/><p>{entries.length === 0 ? "Notebook is empty. Add an entry!" : "No entries match."}</p></div>)}
      <NotebookEntryFormModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSaveEntry} entryToEdit={editingEntry}/>
      <StorySnapshotModal isOpen={isSnapshotModalOpen} onClose={() => setIsSnapshotModalOpen(false)} storySession={viewingSnapshot}/>
      <ScenarioLabResultModal isOpen={isScenarioModalOpen} onClose={() => setIsScenarioModalOpen(false)} scenarioOutput={viewingScenario} originalConcept={viewingScenarioOriginalConcept} />
    </div>);
};
export default NoemasNotebookView;
