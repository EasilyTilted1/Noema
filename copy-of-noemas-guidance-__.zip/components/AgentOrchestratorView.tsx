
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { OrchestratorInstance, OrchestratorConnection, OrchestratorWorkflow, OrchestratorComponentDefinition, OrchestratorNodeDefinition, ModelConfigOverrides, ChatMessage, TextPart, ImagePart, ChatMessagePart, MappingRule, SocraticPromptDefinition, SocraticContext, IconName as AppIconName, OrchestratorActionPayload, AddAndConnectDisplayActionPayload, ScaffoldWorkflowBlueprintPayload, BlueprintComponentToScaffold } from '../types.ts';
import { generateSimpleTextResponse, generateChatResponseMultiModal, generateTextWithGoogleSearch, analyzeImageWithPrompt, generateImageFromPrompt } from '../services/geminiService.ts';
import { Zap, Play, Settings, Trash2, Maximize2, Minimize2, ChevronDown, ChevronUp, GripVertical, AlertTriangle, PlusCircle, RotateCcw, CheckCircle2, Loader2, PlayCircle, MessageCircleMore, FileOutput, Image as ImageIconLucide, Workflow as WorkflowIcon, Lightbulb, Send, Eye, X, HelpCircle } from 'lucide-react';
import { ORCHESTRATOR_COMPONENT_DEFS as allGlobalDefs } from '../constants.ts';
import * as geminiServiceModule from '../services/geminiService.ts';
import Tooltip from './Tooltip.tsx';
import { Icon } from './Icon.tsx'; // Ensure custom Icon is imported if used


// Helper function to get a value from an object using a simple dot notation path
const getValueByPath = (obj: any, path: string): any => {
  if (!path || typeof path !== 'string') return obj;
  const parts = path.split(/[.[\]'"]/).filter(Boolean);
  let current = obj;
  for (const part of parts) {
    if (current && typeof current === 'object' && part in current) {
      current = current[part];
    } else if (current && Array.isArray(current) && !isNaN(parseInt(part))) {
      const index = parseInt(part);
      if (index >= 0 && index < current.length) {
        current = current[index];
      } else {
        return undefined;
      }
    } else {
      return undefined;
    }
  }
  return current;
};

interface AgentOrchestratorViewProps {
  availablePaletteComponentsOverride?: OrchestratorComponentDefinition[];
  isExplicitSandbox?: boolean;
  onOrchestratorEventTrigger?: (triggerType: SocraticPromptDefinition['trigger'], context: SocraticContext) => void;
  onComponentSelectionChange?: (selectedDefId: string | null, selectedInstanceId: string | null) => void;
  onWorkflowChange?: (workflow: OrchestratorWorkflow) => void;
  onSelectedInstanceErrorChange?: (errorMessage: string | null) => void;
  requestOrchestratorActionFromConsoleRef?: React.MutableRefObject<((action: OrchestratorActionPayload) => void) | null>;
  requestCanvasFocusOnIssueRef?: React.MutableRefObject<((instanceId: string, nodeId?: string) => void) | null>;
}

interface ComponentInstanceCardProps extends React.HTMLAttributes<HTMLDivElement> {
  instance: OrchestratorInstance;
  definition: OrchestratorComponentDefinition;
  onInstanceDragStart: (e: React.DragEvent<HTMLDivElement>, instanceId: string) => void;
  onNodeClick: (instanceId: string, nodeId: string, nodeType: 'input' | 'output') => void;
  onConfigClick: (instance: OrchestratorInstance) => void;
  onDeleteInstance: (instanceId: string) => void;
  onPeekOutput: (instance: OrchestratorInstance, targetElement: HTMLElement) => void;
  isCollapsed: boolean;
  onToggleCollapse: (instanceId: string) => void;
  isSelected?: boolean;
  isConnectingFromThis?: boolean;
  draggingInstanceId?: string | null;
  isFocusHighlighted?: boolean;
  isNodeFocusHighlighted?: (nodeId: string) => boolean;
  isCompatibleTargetNode?: (nodeId: string) => boolean;
  isCompatibleTargetInstance?: boolean;
}


const ComponentInstanceCard: React.FC<ComponentInstanceCardProps> = ({
  instance,
  definition,
  onInstanceDragStart,
  onNodeClick,
  onConfigClick,
  onDeleteInstance,
  onPeekOutput,
  isCollapsed,
  onToggleCollapse,
  className,
  style,
  isSelected,
  isConnectingFromThis,
  draggingInstanceId,
  isFocusHighlighted,
  isNodeFocusHighlighted,
  isCompatibleTargetNode,
  isCompatibleTargetInstance,
  ...rest
}) => {
  const nodeBaseClasses = "w-3 h-3 rounded-full border-2 absolute transform -translate-y-1/2 cursor-pointer focus:outline-none focus:ring-2 z-10";
  const inputNodeClasses = `${nodeBaseClasses} bg-sky-400 border-sky-600 left-[-7px] ring-sky-300`;
  const outputNodeClasses = `${nodeBaseClasses} bg-green-400 border-green-600 right-[-7px] ring-green-300`;

  const statusIndicator = instance.isRunning ? <Loader2 size={14} className="animate-spin text-yellow-300" aria-label="Executing"/> :
                          instance.error ? <AlertTriangle size={14} className="text-red-300" aria-label="Error"/> :
                          instance.isCompleted ? <CheckCircle2 size={14} className="text-green-300" aria-label="Completed successfully"/> :
                          null;

  const cardRef = useRef<HTMLDivElement>(null);

  const canPeekOutput = useMemo(() => {
    if (instance.isCompleted && instance.outputData && Object.keys(instance.outputData).length > 0 && !instance.error) {
      if (definition.category === 'OUTPUT') return true;
      const primaryOutputNode = definition.outputs.find(o => !o.label.toLowerCase().includes("error")) || definition.outputs[0];
      if (primaryOutputNode && instance.outputData[primaryOutputNode.id] !== undefined) {
        const outputValue = instance.outputData[primaryOutputNode.id];
        if (typeof outputValue === 'string') return true;
        if (typeof outputValue === 'object' && outputValue !== null && 'data' in outputValue && 'mimeType' in outputValue && typeof outputValue.data === 'string' && typeof outputValue.mimeType === 'string' && outputValue.mimeType.startsWith('image/')) return true;
      }
    }
    return false;
  }, [instance.isCompleted, instance.outputData, instance.error, definition.category, definition.outputs]);

  const outputPreview = useMemo(() => {
    if (instance.isCompleted && instance.outputData && Object.keys(instance.outputData).length > 0 && !instance.error) {
        const firstOutputKey = Object.keys(instance.outputData)[0];
        let firstOutputValue = instance.outputData[firstOutputKey];

        if (typeof firstOutputValue === 'object' && firstOutputValue !== null &&
            firstOutputValue.hasOwnProperty('data') && typeof firstOutputValue.data === 'string' &&
            firstOutputValue.hasOwnProperty('mimeType') && typeof firstOutputValue.mimeType === 'string' &&
            firstOutputValue.mimeType.startsWith('image/')) {
            return <img src={`data:${firstOutputValue.mimeType};base64,${firstOutputValue.data}`} alt="Output preview" className="max-h-12 max-w-full object-contain rounded-sm my-0.5"/>;
        }

        const outputNodeDef = definition.outputs.find(o => o.id === firstOutputKey);

        if (outputNodeDef?.dataType === 'image_ref' && typeof firstOutputValue === 'string' && firstOutputValue.startsWith('data:image')) {
            return <img src={firstOutputValue} alt="Generated output" className="max-h-12 max-w-full object-contain rounded-sm my-0.5"/>;
        } else if (outputNodeDef?.dataType === 'image_ref' && typeof firstOutputValue === 'string' && firstOutputValue.length > 100 && !firstOutputValue.startsWith('data:')) {
             return <img src={`data:image/jpeg;base64,${firstOutputValue}`} alt="Generated output" className="max-h-12 max-w-full object-contain rounded-sm my-0.5"/>;
        } else if (typeof firstOutputValue === 'string') {
            return `Output: ${firstOutputValue.substring(0,25)}${firstOutputValue.length > 25 ? '...' : ''}`;
        } else if (firstOutputValue !== undefined && firstOutputValue !== null) {
            try {
                return `Output: ${JSON.stringify(firstOutputValue).substring(0,25)}...`;
            } catch {
                return `Output: [Complex Object]`;
            }
        }
    }
    return null;
  }, [instance.isCompleted, instance.outputData, instance.error, definition.outputs]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    // Placeholder for future keyboard controls
  };


  return (
    <div
      id={instance.id}
      ref={cardRef}
      draggable
      onDragStart={(e) => onInstanceDragStart(e, instance.id)}
      tabIndex={0}
      role="group"
      aria-labelledby={`instance-title-${instance.id}`}
      aria-describedby={`instance-desc-${instance.id} instance-status-${instance.id}`}
      aria-grabbed={draggingInstanceId === instance.id}
      onKeyDown={handleKeyDown}
      data-testid={`instance-card-${instance.id}`}
      className={`absolute p-2 rounded-lg shadow-lg border-2 cursor-move select-none
                  ${definition.category === 'INPUT' ? 'bg-blue-700/80 border-blue-500' :
                    definition.category === 'PROCESS' ? 'bg-purple-700/80 border-purple-500' :
                    definition.category === 'OUTPUT' ? 'bg-teal-700/80 border-teal-500' :
                    definition.category === 'TOOL' ? 'bg-orange-700/80 border-orange-500' :
                    definition.category === 'DATA' ? 'bg-indigo-700/80 border-indigo-500' :
                    definition.category === 'LOGIC' ? 'bg-yellow-600/80 border-yellow-400' :
                    'bg-slate-700/80 border-slate-500'}
                  ${instance.isRunning ? 'ring-2 ring-yellow-300 animate-pulseSlow' : ''}
                  ${instance.error ? 'border-red-500 ring-2 ring-red-400' : ''}
                  ${instance.isCompleted && !instance.error ? (instance.error ? '' : 'border-green-500 ring-2 ring-green-400') : ''}
                  ${isSelected ? 'ring-2 ring-pink-500 shadow-2xl' : ''}
                  ${isFocusHighlighted ? 'ring-4 ring-offset-2 ring-offset-slate-900 ring-yellow-400 shadow-2xl animate-pulse' : ''}
                  ${isCompatibleTargetInstance ? 'ring-2 ring-teal-400 shadow-md' : ''}
                  transition-all duration-150 ease-in-out group ${className || ''}`}
      style={{
        left: instance.position.x,
        top: instance.position.y,
        width: isCollapsed ? '130px' : '180px',
        zIndex: isFocusHighlighted || isSelected ? 20 : 10,
        ...(style || {}),
      }}
      {...rest}
    >
      <div className="flex items-center justify-between mb-1">
        <div id={`instance-title-${instance.id}`} className="flex items-center text-xs font-semibold text-white truncate">
          <Icon name={definition.icon as AppIconName} size={12} className="mr-1 flex-shrink-0" />
          <span className="truncate" title={instance.customName || definition.name}>{instance.customName || definition.name}</span>
        </div>
        <div className="flex items-center opacity-60 group-hover:opacity-100 transition-opacity">
          {canPeekOutput && (
            <button
              onClick={(e) => { e.stopPropagation(); if (cardRef.current) onPeekOutput(instance, cardRef.current); }}
              className="p-0.5 hover:bg-slate-600/50 rounded"
              title="Peek Output" aria-label={`Peek output of ${instance.customName || definition.name}`}
              data-peek-trigger="true"
            >
              <Eye size={10} className="text-sky-300" />
            </button>
          )}
          {statusIndicator && <div className="mr-0.5" id={`instance-status-${instance.id}`}>{statusIndicator}</div>}
          <button onClick={(e) => { e.stopPropagation(); onConfigClick(instance);}} className="p-0.5 hover:bg-slate-600/50 rounded" title="Configure" aria-label={`Configure ${instance.customName || definition.name}`}><Settings size={10} /></button>
          <button onClick={(e) => { e.stopPropagation(); onToggleCollapse(instance.id);}} className="p-0.5 hover:bg-slate-600/50 rounded" title={isCollapsed ? "Expand" : "Collapse"} aria-label={isCollapsed ? `Expand ${instance.customName || definition.name}` : `Collapse ${instance.customName || definition.name}`}>{isCollapsed ? <Maximize2 size={10} /> : <Minimize2 size={10} />}</button>
          <button onClick={(e) => { e.stopPropagation(); onDeleteInstance(instance.id);}} className="p-0.5 hover:bg-red-600/50 rounded" title="Delete" aria-label={`Delete ${instance.customName || definition.name}`}><Trash2 size={10} /></button>
        </div>
      </div>
      {!isCollapsed && (
        <>
          <p id={`instance-desc-${instance.id}`} className="text-[9px] text-slate-300 mb-1.5 truncate" title={definition.description}>{definition.description}</p>
          {definition.inputs.map((node, i) => {
            const isNodeHighlighted = isNodeFocusHighlighted ? isNodeFocusHighlighted(node.id) : false;
            const isCompatible = isCompatibleTargetNode ? isCompatibleTargetNode(node.id) : false;
            return (
                <button
                    key={node.id} data-node-id={node.id} data-node-type="input"
                    onClick={(e) => {e.stopPropagation(); onNodeClick(instance.id, node.id, 'input');}}
                    className={`${inputNodeClasses}
                                ${isNodeHighlighted ? 'ring-4 ring-yellow-300 animate-pulse' : ''}
                                ${isCompatible ? 'ring-4 ring-teal-300 animate-pulse bg-teal-300 border-teal-500' : ''}`}
                    style={{ top: `${(i * 18) + 40}px` }}
                    aria-label={`Input: ${node.label} (${node.dataType})`}
                >
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[8px] text-slate-200 max-w-[50px] truncate pointer-events-none">{node.label}</span>
                </button>
            );
          })}
          {definition.outputs.map((node, i) => {
            const isNodeHighlighted = isNodeFocusHighlighted ? isNodeFocusHighlighted(node.id) : false;
            return (
                <button
                    key={node.id} data-node-id={node.id} data-node-type="output"
                    onClick={(e) => {e.stopPropagation(); onNodeClick(instance.id, node.id, 'output');}}
                    className={`${outputNodeClasses} ${isNodeHighlighted ? 'ring-4 ring-yellow-300 animate-pulse' : ''}`}
                    style={{ top: `${(i * 18) + 40}px` }}
                    aria-label={`Output: ${node.label} (${node.dataType})`}
                >
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[8px] text-slate-200 max-w-[50px] truncate text-right pointer-events-none">{node.label}</span>
                </button>
            );
          })}
          {outputPreview && !instance.error && <div className="text-[9px] text-green-200 bg-slate-800/60 p-0.5 mt-2 rounded max-h-12 overflow-y-auto custom-scrollbar" title={typeof outputPreview === 'string' ? outputPreview : 'Output preview'}>{outputPreview}</div>}
          {instance.error && <p className="text-red-300 text-[9px] mt-1 break-words" role="alert"><AlertTriangle size={10} className="inline mr-0.5"/>{instance.error.substring(0,50)}...</p>}
        </>
      )}
    </div>
  );
};

interface ConfigModalProps {
  instance: OrchestratorInstance;
  definition: OrchestratorComponentDefinition | null;
  onClose: () => void;
  onSave: (instanceId: string, newCustomName: string, newConfigValues: Record<string, any>) => void;
}

const ConfigModalComponent: React.FC<ConfigModalProps> = ({ instance, definition, onClose, onSave }) => {
  const [customName, setCustomName] = useState(instance.customName || '');
  const [formValues, setFormValues] = useState<Record<string, any>>({ ...instance.configValues });

  useEffect(() => {
    setCustomName(instance.customName || definition?.name || '');
    setFormValues({ ...instance.configValues });
  }, [instance, definition]);

  if (!definition) return null;

  const handleFieldChange = (fieldId: string, value: any) => {
    setFormValues(prev => ({ ...prev, [fieldId]: value }));
  };

  const handleSubmit = () => {
    onSave(instance.id, customName.trim() || definition.name, formValues);
  };

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center p-4 z-[100]"
         onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="bg-slate-800 p-5 rounded-lg shadow-xl w-full max-w-lg border border-slate-600 max-h-[90vh] flex flex-col"
           onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-lg font-semibold text-sky-300 flex items-center">
            <Icon name={definition.icon as AppIconName} size={20} className="mr-2" />
            Configure: {definition.name}
          </h3>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white"><X size={20} /></button>
        </div>
        <div className="flex-grow overflow-y-auto custom-scrollbar pr-2 space-y-3">
          <div>
            <label htmlFor="instanceCustomName" className="block text-xs font-medium text-slate-300 mb-0.5">Custom Name</label>
            <input
              id="instanceCustomName"
              type="text"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              placeholder={definition.name}
              className="w-full p-1.5 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-sky-500 outline-none"
            />
          </div>
          {(definition.configFields || []).map(field => (
            <div key={field.id}>
              <label htmlFor={field.id} className="block text-xs font-medium text-slate-300 mb-0.5 flex items-center">
                <span>
                  {field.label} {field.type === 'number' && (field.min !== undefined || field.max !== undefined) ? `(${field.min ?? ''}-${field.max ?? ''})` : ''}
                </span>
                {field.helpText && (
                  <Tooltip content={field.helpText} position="right" delay={100}>
                    <HelpCircle size={14} className="ml-1.5 text-slate-400 hover:text-sky-400 cursor-help" />
                  </Tooltip>
                )}
              </label>
              {field.type === 'textarea' ? (
                <textarea
                  id={field.id}
                  rows={3}
                  value={formValues[field.id] ?? ''}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  placeholder={field.placeholder || ''}
                  className="w-full p-1.5 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-sky-500 outline-none custom-scrollbar"
                />
              ) : field.type === 'select' ? (
                <select
                  id={field.id}
                  value={formValues[field.id] ?? ''}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  className="w-full p-1.5 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-sky-500 outline-none"
                >
                  {field.options?.map(opt => <option key={opt.value.toString()} value={opt.value}>{opt.label}</option>)}
                </select>
              ) : field.type === 'boolean' ? (
                  <div className="flex items-center">
                    <input
                      id={field.id}
                      type="checkbox"
                      checked={!!formValues[field.id]}
                      onChange={(e) => handleFieldChange(field.id, e.target.checked)}
                      className="h-4 w-4 text-sky-500 border-slate-600 rounded focus:ring-sky-400 bg-slate-700"
                    />
                    <span className="ml-2 text-xs text-slate-200">{field.placeholder || (formValues[field.id] ? 'Enabled' : 'Disabled')}</span>
                  </div>
              ) : (
                <input
                  id={field.id}
                  type={field.type === 'number' ? 'number' : 'text'}
                  value={formValues[field.id] ?? ''}
                  onChange={(e) => handleFieldChange(field.id, field.type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value)}
                  placeholder={field.placeholder || ''}
                  min={field.min}
                  max={field.max}
                  step={field.step}
                  className="w-full p-1.5 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-sky-500 outline-none"
                />
              )}
            </div>
          ))}
        </div>
        <div className="mt-4 pt-3 border-t border-slate-700 flex justify-end space-x-2">
          <button onClick={onClose} className="px-3 py-1.5 text-sm bg-slate-600 hover:bg-slate-500 rounded-md">Cancel</button>
          <button onClick={handleSubmit} className="px-3 py-1.5 text-sm bg-sky-600 hover:bg-sky-500 text-white rounded-md">Save Configuration</button>
        </div>
      </div>
    </div>
  );
};


export const AgentOrchestratorView: React.FC<AgentOrchestratorViewProps> = ({
  availablePaletteComponentsOverride,
  isExplicitSandbox,
  onOrchestratorEventTrigger,
  onComponentSelectionChange,
  onWorkflowChange,
  onSelectedInstanceErrorChange,
  requestOrchestratorActionFromConsoleRef,
  requestCanvasFocusOnIssueRef
}) => {
  const {
    activeStep,
    addToast,
    completeStep,
    activeQuest,
    setSelectedOrchestratorInstanceId: setGlobalSelectedInstanceId
  } = useAppContext();
  const [instances, setInstances] = useState<OrchestratorInstance[]>([]);
  const [connections, setConnections] = useState<OrchestratorConnection[]>([]);
  const [draggingInstanceId, setDraggingInstanceId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{x: number, y: number} | null>(null);
  const [connectingNode, setConnectingNode] = useState<{instanceId: string, nodeId: string, nodeType: 'input' | 'output', nodeDataType: string} | null>(null);
  const [tempLinePoints, setTempLinePoints] = useState<{x1:number, y1:number, x2:number, y2:number} | null>(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [configuringInstance, setConfiguringInstance] = useState<OrchestratorInstance | null>(null);
  const [executionLog, setExecutionLog] = useState<string[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [finalOutputData, setFinalOutputData] = useState<Record<string, any> | null>(null);
  const [selectedInstanceIdLocal, setSelectedInstanceIdLocal] = useState<string | null>(null);
  const [currentWorkflowMeetsQuestCriteria, setCurrentWorkflowMeetsQuestCriteria] = useState(false);


  const [peekOutputForInstanceId, setPeekOutputForInstanceId] = useState<string | null>(null);
  const [peekOutputContent, setPeekOutputContent] = useState<React.ReactNode | null>(null);
  const [peekOutputPosition, setPeekOutputPosition] = useState<{top: number; left: number} | null>(null);
  const peekOutputRef = useRef<HTMLDivElement>(null);

  const [focusHighlightedInstanceId, setFocusHighlightedInstanceId] = useState<string | null>(null);
  const [focusHighlightedNodeInfo, setFocusHighlightedNodeInfo] = useState<{ instanceId: string; nodeId: string } | null>(null);
  const highlightTimeoutRef = useRef<number | null>(null);


  const canvasRef = useRef<HTMLDivElement>(null);
  const effectiveSandboxMode = isExplicitSandbox || !activeStep;

  const paletteComponents = useMemo(() => {
    if (effectiveSandboxMode) return allGlobalDefs;
    if (availablePaletteComponentsOverride) return availablePaletteComponentsOverride;
    const configDefIds = activeStep?.orchestratorConfig?.availableComponentDefs || [];
    return allGlobalDefs.filter(def => configDefIds.includes(def.id));
  }, [effectiveSandboxMode, availablePaletteComponentsOverride, activeStep]);

  const addLog = useCallback((message: string, type: 'info' | 'error' | 'success' | 'noema' = 'info') => {
    const prefix = type === 'error' ? '🛑 Error: ' : type === 'success' ? '✅ Success: ' : type === 'noema' ? '💡 Noema: ' : '➡️ ';
    setExecutionLog(prev => [`${new Date().toLocaleTimeString()} ${prefix}${message}`, ...prev.slice(0, 49)]);
  }, []);

  const handleSetSelectedInstanceId = useCallback((instanceId: string | null) => {
    setSelectedInstanceIdLocal(instanceId);
    if (setGlobalSelectedInstanceId) {
      setGlobalSelectedInstanceId(instanceId);
    }
  }, [setGlobalSelectedInstanceId]);


  const getComponentDefByIdFn = useCallback((defId: string | undefined): OrchestratorComponentDefinition | undefined =>
        defId ? allGlobalDefs.find(d => d.id === defId) : undefined,
    []);

  const handleClearCanvas = () => {
    setInstances([]);
    setConnections([]);
    setExecutionLog([]);
    setFinalOutputData(null);
    handleSetSelectedInstanceId(null);
    setPeekOutputForInstanceId(null);
    setCurrentWorkflowMeetsQuestCriteria(false);
    addToast("Canvas cleared.", "info");
  };

  useEffect(() => {
    if (activeStep?.orchestratorConfig?.initialWorkflow && !effectiveSandboxMode) {
      setInstances(activeStep.orchestratorConfig.initialWorkflow.instances.map(inst => ({...inst, configValues: inst.configValues || {}, customName: inst.customName || getComponentDefByIdFn(inst.componentDefId)?.name || 'Untitled'})) || []);
      setConnections(activeStep.orchestratorConfig.initialWorkflow.connections || []);
    } else {
        setInstances([]);
        setConnections([]);
    }
    setExecutionLog([]);
    setFinalOutputData(null);
    handleSetSelectedInstanceId(null);
    setPeekOutputForInstanceId(null);
    setCurrentWorkflowMeetsQuestCriteria(false);
    if (!effectiveSandboxMode && activeStep) {
        addLog(`New step: ${activeStep.title}. Objective: ${activeStep.learningObjective}`);
        if(onOrchestratorEventTrigger) onOrchestratorEventTrigger('STEP_START', {});
    }
  }, [activeStep, effectiveSandboxMode, addLog, onOrchestratorEventTrigger, getComponentDefByIdFn, handleSetSelectedInstanceId]);

  useEffect(() => {
    if (onWorkflowChange) {
      onWorkflowChange({ instances, connections });
    }
  }, [instances, connections, onWorkflowChange]);

  useEffect(() => {
    if (requestCanvasFocusOnIssueRef) {
      requestCanvasFocusOnIssueRef.current = (instanceId, nodeId) => {
        if (highlightTimeoutRef.current) {
          clearTimeout(highlightTimeoutRef.current);
        }
        handleSetSelectedInstanceId(instanceId);
        setFocusHighlightedInstanceId(instanceId);
        if (nodeId) {
          setFocusHighlightedNodeInfo({ instanceId, nodeId });
        } else {
          setFocusHighlightedNodeInfo(null);
        }

        highlightTimeoutRef.current = window.setTimeout(() => {
          setFocusHighlightedInstanceId(null);
          setFocusHighlightedNodeInfo(null);
          highlightTimeoutRef.current = null;
        }, 3500);
      };
    }
    return () => {
      if (requestCanvasFocusOnIssueRef) {
        requestCanvasFocusOnIssueRef.current = null;
      }
      if (highlightTimeoutRef.current) {
        clearTimeout(highlightTimeoutRef.current);
      }
    };
  }, [requestCanvasFocusOnIssueRef, handleSetSelectedInstanceId]);


  useEffect(() => {
    const selectedInstance = instances.find(inst => inst.id === selectedInstanceIdLocal);
    if (onComponentSelectionChange) {
      const defId = selectedInstance ? selectedInstance.componentDefId : null;
      onComponentSelectionChange(defId, selectedInstanceIdLocal);
    }
    if (onSelectedInstanceErrorChange) {
      onSelectedInstanceErrorChange(selectedInstance?.error || null);
    }
  }, [selectedInstanceIdLocal, instances, onComponentSelectionChange, onSelectedInstanceErrorChange]);


  const addInstance = useCallback((componentDef: OrchestratorComponentDefinition, position?: {x: number, y: number}, instanceCustomName?: string) => {
    const existingInstancesOfTypeCount = instances.filter(i => i.componentDefId === componentDef.id).length;
    const defaultName = `${componentDef.name} ${existingInstancesOfTypeCount + 1}`;
    
    const defaultConfigs = componentDef.configFields?.reduce((acc, field) => {
      if (field.defaultValue !== undefined) {
        acc[field.id] = field.defaultValue;
      }
      return acc;
    }, {} as Record<string, any>) || {};

    const newInstance: OrchestratorInstance = {
      id: `inst_${crypto.randomUUID().substring(0,8)}`,
      componentDefId: componentDef.id,
      customName: instanceCustomName || defaultName,
      position: position || { x: 50 + Math.random()*50, y: 50 + Math.random()*50 },
      configValues: defaultConfigs, 
    };
    setInstances(prev => [...prev, newInstance]);
    addLog(`Added: ${newInstance.customName}`);
    if(onOrchestratorEventTrigger) onOrchestratorEventTrigger('ORCHESTRATOR_WORKFLOW_EVENT', { orchestratorWorkflowStatus: 'user_added_inputs' });
  }, [instances, addLog, onOrchestratorEventTrigger]);

  return (
    <div className="flex flex-col h-full p-2 bg-slate-900 text-slate-100">
      <div className="flex items-center justify-between mb-2 p-2 bg-slate-800 rounded-md shadow">
        <h2 className="text-lg font-semibold text-sky-400 flex items-center">
          <WorkflowIcon size={20} className="mr-2" /> Agent Orchestrator {effectiveSandboxMode ? "(Sandbox)" : ""}
        </h2>
        <div className="flex space-x-2">
          <button
            onClick={() => { addLog("Execute clicked (not fully implemented).")}}
            className="px-3 py-1.5 text-xs bg-green-600 hover:bg-green-500 text-white rounded-md flex items-center"
            disabled={isExecuting || instances.length === 0}
            title="Execute Workflow"
          >
            <PlayCircle size={14} className="mr-1" /> Execute
          </button>
          <button
            onClick={handleClearCanvas}
            className="px-3 py-1.5 text-xs bg-red-600 hover:bg-red-500 text-white rounded-md flex items-center"
            title="Clear Canvas"
          >
            <RotateCcw size={14} className="mr-1" /> Clear
          </button>
        </div>
      </div>

      <div className="flex flex-grow overflow-hidden space-x-2">
        <div className="w-48 p-2 bg-slate-800 rounded-md shadow overflow-y-auto custom-scrollbar flex-shrink-0">
          <h3 className="text-sm font-semibold text-purple-300 mb-2">Components</h3>
          {paletteComponents.map(def => (
            <div
              key={def.id}
              draggable
              onDragStart={(e) => { /* Placeholder */ }}
              className="p-1.5 mb-1.5 bg-slate-700 hover:bg-slate-600 rounded cursor-grab text-xs flex items-center"
              title={def.description}
            >
              <Icon name={def.icon as AppIconName} size={12} className="mr-1.5 flex-shrink-0" />
              <span className="truncate">{def.name}</span>
            </div>
          ))}
        </div>

        <div
          ref={canvasRef}
          className="flex-grow bg-slate-800/70 rounded-md shadow-inner relative overflow-auto custom-scrollbar border border-slate-700"
          onDrop={(e) => { /* Placeholder */ }}
          onDragOver={(e) => e.preventDefault()}
        >
          {instances.map(inst => {
            const def = getComponentDefByIdFn(inst.componentDefId);
            if (!def) return null;
            return (
              <ComponentInstanceCard
                key={inst.id}
                instance={inst}
                definition={def}
                onInstanceDragStart={() => {}}
                onNodeClick={() => {}}
                onConfigClick={() => {}}
                onDeleteInstance={() => {}}
                onPeekOutput={() => {}}
                isCollapsed={!!inst.isCollapsed}
                onToggleCollapse={() => {}}
                isSelected={selectedInstanceIdLocal === inst.id}
              />
            );
          })}
           <svg className="absolute top-0 left-0 w-full h-full pointer-events-none z-0" style={{ minWidth: '100%', minHeight: '100%' }}>
              {connections.map(conn => (
                <line key={conn.id} x1={0} y1={0} x2={100} y2={100} stroke="#60a5fa" strokeWidth="2" /> 
              ))}
              {tempLinePoints && (
                <line
                    x1={tempLinePoints.x1} y1={tempLinePoints.y1}
                    x2={tempLinePoints.x2} y2={tempLinePoints.y2}
                    stroke="#f472b6" strokeWidth="2" strokeDasharray="4 2"
                />
              )}
            </svg>
        </div>
      </div>

      <div className="h-28 p-2 mt-2 bg-slate-800 rounded-md shadow overflow-y-auto custom-scrollbar flex-shrink-0 border-t border-slate-700">
        <h3 className="text-sm font-semibold text-purple-300 mb-1 sticky top-0 bg-slate-800 py-0.5 z-10">Execution Log</h3>
        {executionLog.length === 0 && <p className="text-xs text-slate-500 italic">No execution logs yet.</p>}
        {executionLog.map((log, i) => (
          <p key={i} className="text-xs text-slate-300 mb-0.5 whitespace-pre-wrap break-all leading-tight">
            {log}
          </p>
        ))}
      </div>

      {showConfigModal && configuringInstance && (
        <ConfigModalComponent
          instance={configuringInstance}
          definition={getComponentDefByIdFn(configuringInstance.componentDefId)}
          onClose={() => setShowConfigModal(false)}
          onSave={() => { /* Placeholder */ }}
        />
      )}

       {peekOutputForInstanceId && peekOutputContent && peekOutputPosition && (
        <div
          ref={peekOutputRef}
          className="fixed bg-slate-700 text-slate-100 p-3 rounded-md shadow-2xl border border-slate-500 text-xs max-w-xs max-h-48 overflow-auto custom-scrollbar z-[110]"
          style={{ top: peekOutputPosition.top, left: peekOutputPosition.left }}
          role="tooltip"
          aria-live="polite"
        >
          <div className="flex justify-between items-center mb-1">
            <h4 className="font-semibold text-sky-300">Output Preview</h4>
            <button onClick={() => setPeekOutputForInstanceId(null)} className="p-0.5 text-slate-400 hover:text-white">
              <X size={14}/>
            </button>
          </div>
          {peekOutputContent}
        </div>
      )}
    </div>
  );
};
