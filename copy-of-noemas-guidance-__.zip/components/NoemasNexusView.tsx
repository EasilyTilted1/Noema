
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useAppContext } from '../contexts/AppContext.tsx'; // Updated import path
import { Icon } from './Icon.tsx'; 
import { GlossaryItem, IconName } from '../types.ts';
import { INITIAL_GLOSSARY_DATA } from '../constants.ts';
import { generateAnalogies, generateTermExplanation } from '../services/geminiService.ts';

const InteractivePixelGrid: React.FC = () => {
  const gridSize = 5;
  const [grid, setGrid] = useState(() =>
    Array(gridSize).fill(null).map(() => Array(gridSize).fill(false))
  );

  const togglePixel = (r: number, c: number) => {
    setGrid(prevGrid => {
      const newGrid = prevGrid.map(row => [...row]);
      newGrid[r][c] = !newGrid[r][c];
      return newGrid;
    });
  };

  return (
    <div className="my-2 p-2 bg-slate-700/70 rounded">
      <p className="text-xs text-slate-300 mb-1 text-center">Interactive Demo: Click pixels</p>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${gridSize}, 1fr)`, gap: '2px', width: '100px', margin: 'auto' }}>
        {grid.map((row, rIndex) =>
          row.map((isActive, cIndex) => (
            <div
              key={`${rIndex}-${cIndex}`}
              onClick={() => togglePixel(rIndex, cIndex)}
              className="aspect-square cursor-pointer transition-colors duration-150"
              style={{ backgroundColor: isActive ? '#34d399' : '#475569' }}
              title={`Pixel (${rIndex + 1}, ${cIndex + 1}) - ${isActive ? 'Active' : 'Inactive'}`}
            />
          ))
        )}
      </div>
    </div>
  );
};

const DataSkewVisualizer: React.FC = () => {
  const totalDots = 50;
  const [bluePercentage, setBluePercentage] = useState(50);

  const blueCount = Math.round((bluePercentage / 100) * totalDots);
  const orangeCount = totalDots - blueCount;

  const dots = useMemo(() => {
    const d = [];
    for (let i = 0; i < blueCount; i++) d.push({ color: '#60a5fa', id: `blue-${i}` });
    for (let i = 0; i < orangeCount; i++) d.push({ color: '#fb923c', id: `orange-${i}` });
    return d.sort(() => Math.random() - 0.5);
  }, [blueCount, orangeCount]);

  return (
    <div className="my-2 p-3 bg-slate-700/70 rounded text-center">
      <p className="text-xs text-slate-300 mb-2">Dataset Skew Demo:</p>
      <div className="mb-2">
        <label htmlFor="skewSlider" className="block text-xs text-slate-400 mb-1">
          Skew towards Blue: {bluePercentage}% (Blue: {blueCount}, Orange: {orangeCount})
        </label>
        <input
          type="range"
          id="skewSlider"
          min="0"
          max="100"
          value={bluePercentage}
          onChange={(e) => setBluePercentage(parseInt(e.target.value, 10))}
          className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-sky-500"
        />
      </div>
      <div className="h-24 w-full bg-slate-600/50 p-1 rounded grid grid-cols-10 gap-0.5 items-center justify-center overflow-hidden">
        {dots.map(dot => (
          <div key={dot.id} className="w-2 h-2 rounded-full mx-auto" style={{ backgroundColor: dot.color }} />
        ))}
      </div>
      <p className="text-xs text-slate-400 mt-2 italic">
        If an AI is trained on data skewed like this, it might become more accurate for the 'blue' category and less for 'orange', potentially leading to biased outcomes.
      </p>
    </div>
  );
};

const interactiveComponentMap: Record<string, React.FC<any>> = {
  'PIXEL_GRID_DEMO': InteractivePixelGrid,
  'DATA_SKEW_DEMO': DataSkewVisualizer,
};

const GlossaryCard: React.FC<{ item: GlossaryItem }> = ({ item }) => {
  const InteractiveComponent = item.interactiveComponentKey ? interactiveComponentMap[item.interactiveComponentKey] : null;

  return (
    <div className="bg-slate-800 p-5 rounded-lg shadow-lg border border-slate-700 hover:shadow-sky-900/50 transition-shadow duration-300 flex flex-col">
      <div className="flex items-center mb-2">
        {item.icon && <Icon name={item.icon as IconName} size={20} className="mr-2 text-sky-400 flex-shrink-0" />}
        <h3 className="text-xl font-semibold text-sky-300">{item.term}</h3>
      </div>
      <p className="text-xs text-purple-400 mb-2 uppercase tracking-wider">{item.category}</p>
      {item.generatedImageBase64 && (
        <div className="my-2 rounded-md overflow-hidden border border-slate-700">
          <img src={`data:image/jpeg;base64,${item.generatedImageBase64}`} alt={`Visualization for ${item.term}`} className="w-full h-auto object-contain max-h-48"/>
        </div>
      )}
      <p className="text-slate-300 text-sm mb-3 leading-relaxed flex-grow">{item.explanation}</p>

      {item.example && (
        <div className="mt-2 pt-2 border-t border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Example:</p>
          <p className="text-sm text-slate-300 italic bg-slate-700/50 p-2 rounded-md">{item.example}</p>
        </div>
      )}

      {InteractiveComponent && (
        <div className="mt-3 pt-3 border-t border-slate-700">
           <h4 className="text-xs text-slate-400 mb-1 font-semibold">Interactive Element:</h4>
          <InteractiveComponent />
        </div>
      )}
    </div>
  );
};

const NoemasNexusView: React.FC = () => {
  const { speak, addToast } = useAppContext();
  const [glossaryData] = useState<GlossaryItem[]>(INITIAL_GLOSSARY_DATA);

  const [exploreTermInput, setExploreTermInput] = useState('');
  const [selectedNexusTermForExplore, setSelectedNexusTermForExplore] = useState('');
  const [termExplanation, setTermExplanation] = useState<string | null>(null);
  const [analogyResults, setAnalogyResults] = useState<string[] | null>(null);
  const [isLoadingExploration, setIsLoadingExploration] = useState(false);

  useEffect(() => {
    speak("Welcome to Noema's Nexus. Explore AI terms dynamically using the 'Explore Term' tool, or browse the glossary below.");
  }, [speak]);

  const sortedFullGlossary = useMemo(() =>
    [...glossaryData].sort((a,b) => a.term.localeCompare(b.term)),
  [glossaryData]);

  const handleNexusTermSelectForExplore = (term: string) => {
    setSelectedNexusTermForExplore(term);
    setExploreTermInput(term);
  };

  const handleExploreTerm = useCallback(async () => {
    if (!exploreTermInput.trim()) {
      addToast("Please enter or select a term to explore.", "warning");
      return;
    }
    setIsLoadingExploration(true);
    setTermExplanation(null);
    setAnalogyResults(null);
    try {
      const [explanation, analogies] = await Promise.all([
        generateTermExplanation(exploreTermInput),
        generateAnalogies(exploreTermInput)
      ]);

      setTermExplanation(explanation);
      setAnalogyResults(analogies);

      if (explanation || (analogies && analogies.length > 0)) {
        speak(`Here's what I found for ${exploreTermInput}.`);
      } else {
        addToast("No explanation or analogies could be generated for this term.", "info");
        speak(`Hmm, I couldn't find much on ${exploreTermInput}.`);
      }
    } catch (error: any) {
      addToast(`Term exploration failed: ${error.message}`, "error");
      speak("Sorry, I encountered an error trying to explore that term.");
    } finally {
      setIsLoadingExploration(false);
    }
  }, [exploreTermInput, addToast, speak]);

  return (
    <div className="p-4 md:p-6 h-full flex flex-col">
      <div className="mb-6 text-center">
        <Icon name="BookOpenCheck" size={48} className="text-sky-400 mx-auto mb-3" />
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-500">
          Noema's Nexus
        </h1>
        <p className="text-slate-400 mt-1">Your dynamic guide to AI terminology and idea exploration.</p>
      </div>

      <div className="mb-8 p-4 bg-slate-800 rounded-lg shadow-md border border-slate-700 sticky top-0 z-10">
        <div className="text-center mb-4">
          <Icon name="Lightbulb" size={32} className="text-teal-400 mx-auto mb-2" />
          <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-cyan-500">
            Explore AI Concepts
          </h2>
          <p className="text-slate-400 mt-1 text-sm">Get explanations and analogies. Select a Nexus term or type your own.</p>
        </div>
        <div className="max-w-xl mx-auto">
          <div className="flex flex-col md:flex-row gap-2 mb-3">
            <select
              value={selectedNexusTermForExplore}
              onChange={(e) => handleNexusTermSelectForExplore(e.target.value)}
              className="flex-grow md:flex-grow-0 md:w-1/2 p-2.5 bg-slate-700 border border-slate-600 rounded-md text-slate-100 placeholder-slate-400 focus:ring-2 focus:ring-teal-500 outline-none custom-scrollbar text-sm"
              aria-label="Select a Nexus term to explore"
            >
              <option value="">-- Select Nexus Term (Optional) --</option>
              {sortedFullGlossary.map(item => (
                <option key={item.id} value={item.term}>{item.term}</option>
              ))}
            </select>
            <input
              type="text"
              value={exploreTermInput}
              onChange={e => { setExploreTermInput(e.target.value); if (selectedNexusTermForExplore && e.target.value !== selectedNexusTermForExplore) setSelectedNexusTermForExplore('');}}
              placeholder="Or type concept (e.g., AI Hallucination)"
              className="flex-grow p-2.5 bg-slate-700 border border-slate-600 rounded-md text-slate-100 placeholder-slate-400 focus:ring-2 focus:ring-teal-500 outline-none text-sm"
              aria-label="Concept to explore"
            />
          </div>
          <button
            onClick={handleExploreTerm}
            disabled={isLoadingExploration || !exploreTermInput.trim()}
            className="w-full p-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-md disabled:opacity-50 flex items-center justify-center font-medium transition-colors"
          >
            {isLoadingExploration ? <Icon name="Loader2" className="animate-spin mr-2"/> : <Icon name="Zap" size={18} className="mr-2"/>}
            Explore Term
          </button>

          {termExplanation && !isLoadingExploration && (
            <div className="mt-4 p-3 bg-slate-700/70 rounded-md border border-slate-600">
              <h4 className="text-md font-semibold text-teal-300 mb-1">Explanation:</h4>
              <p className="text-sm text-slate-200 whitespace-pre-wrap">{termExplanation}</p>
            </div>
          )}
          {analogyResults && analogyResults.length > 0 && !isLoadingExploration && (
            <div className="mt-3 p-3 bg-slate-700/70 rounded-md border border-slate-600 space-y-2">
              <h4 className="text-md font-semibold text-teal-300">Analogies:</h4>
              {analogyResults.map((analogy, index) => (
                <div key={index} className="p-2 bg-slate-600/50 rounded-md text-sm text-slate-200">
                  {analogy}
                </div>
              ))}
            </div>
          )}
           {analogyResults && analogyResults.length === 0 && !termExplanation && !isLoadingExploration && (
              <p className="text-sm text-slate-400 mt-3 text-center">No specific details found for this term.</p>
          )}
        </div>
      </div>

      <div className="flex-grow overflow-y-auto custom-scrollbar pr-1 pb-4">
        <h3 className="text-lg font-semibold text-sky-300 mb-3 sticky top-0 bg-slate-900 py-2 z-5">Full Glossary:</h3>
        {sortedFullGlossary.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-5">
            {sortedFullGlossary.map(item => (
                <GlossaryCard key={item.id} item={item} />
            ))}
            </div>
        ) : (
            <div className="text-center text-slate-500 py-10">
            <Icon name="ArchiveX" size={40} className="mx-auto mb-3"/>
            <p>Glossary is currently empty.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default NoemasNexusView;
