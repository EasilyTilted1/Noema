
import { QuestStep, Quest, GlossaryItem, NoemaInsight } from '../types';
import { INITIAL_GLOSSARY_DATA, ALL_QUESTS } from '../constants';

const MIN_KEYWORD_LENGTH = 4; // Minimum length for a word to be considered a keyword
const MAX_INSIGHTS = 5; // Max number of insights to return
// Curated list, reviewed to keep potentially important educational terms
const COMMON_WORDS_TO_IGNORE = new Set([
  'the', 'is', 'and', 'a', 'of', 'to', 'in', 'it', 'that', 'this', 'for', 'with', 'can', 'you', 'how',
  'what', 'why', 'when', 'an', 'are', 'as', 'at', 'be', 'by', 'from', 'has', 'have', 'he', 'her', 'his',
  'him', 'its', 'not', 'on', 'or', 'she', 'so', 'was', 'we', 'were', 'your', 'about', 'then', 'them', 'they',
  'will', // 'with' is already present
  // Removed: 'learn', 'like', 'some', 'explore', 'guide', 'help', 'see', 'try', 'use', 'using', 'based',
  // 'example', 'concept', 'concepts', 'different', 'main', 'understand', 'understanding', 'discuss', 'step'
  // These might be important for matching educational content.
]);

const extractKeywords = (text: string): Set<string> => {
  if (!text) return new Set();
  return new Set(
    text
      .toLowerCase()
      .split(/[^a-z0-9_'-]+/) // Split by non-alphanumeric (keeping underscore, apostrophe, hyphen)
      .map(word => word.replace(/^['-]|['-]$/g, '')) // Remove leading/trailing apostrophes/hyphens
      .filter(word => word.length >= MIN_KEYWORD_LENGTH && !COMMON_WORDS_TO_IGNORE.has(word))
  );
};

export const analyzeTextForInsights = (
  currentStepText: string,
  allNexusTerms: GlossaryItem[], 
  allQuests: Quest[],
  currentQuestId?: string,
  currentStepId?: string
): NoemaInsight[] => {
  const insights: NoemaInsight[] = [];
  if (!currentStepText || !currentStepText.trim()) {
    return insights;
  }

  const stepKeywords = extractKeywords(currentStepText);
  if (stepKeywords.size === 0) return insights;

  const addedInsightTargets = new Set<string>(); // To avoid duplicate insights for the same targetId

  // 1. Find related Nexus terms
  for (const term of allNexusTerms) {
    if (insights.length >= MAX_INSIGHTS) break;
    if (addedInsightTargets.has(term.id)) continue;

    const termKeywords = extractKeywords(term.term + ' ' + term.explanation + ' ' + (term.example || ''));
    
    let matchScore = 0;
    if (currentStepText.toLowerCase().includes(term.term.toLowerCase())) {
        matchScore += 5; // Strong match if term itself is present
    }
    stepKeywords.forEach(kw => {
      if (termKeywords.has(kw)) {
        matchScore++;
      }
      // Check if keyword is part of the term name (even if not a standalone keyword in termKeywords after processing)
      if (term.term.toLowerCase().includes(kw)) matchScore +=2; 
      // Lower weight for keywords just in explanation if they are not primary keywords of the term
      if (term.explanation.toLowerCase().includes(kw)) matchScore +=0.5; 
    });

    if (matchScore > 2.5) { // Adjusted threshold for relevance, slightly higher to ensure quality
      insights.push({
        id: `insight-nexus-${term.id}`,
        type: 'nexus',
        title: term.term,
        targetId: term.id,
        relevanceContext: `Related to: ${term.category}`
      });
      addedInsightTargets.add(term.id);
    }
  }

  // 2. Find related Quest Steps
  for (const quest of allQuests) {
    if (insights.length >= MAX_INSIGHTS) break;
    for (const step of quest.steps) {
      if (insights.length >= MAX_INSIGHTS) break;
      if (quest.id === currentQuestId && step.id === currentStepId) continue; // Skip current step
      if (addedInsightTargets.has(step.id)) continue;

      // Concatenate relevant text fields for keyword extraction from the target step
      const targetStepTextForKeywords = (step.title + ' ' + step.learningObjective + ' ' + step.noemaIntro.substring(0,150) + ' ' + step.keyTakeaway.substring(0,100)).toLowerCase();
      const targetStepKeywords = extractKeywords(targetStepTextForKeywords);
      let matchScore = 0;

      stepKeywords.forEach(kw => {
        if (targetStepKeywords.has(kw)) {
          matchScore++;
        }
        if (step.title.toLowerCase().includes(kw)) matchScore +=2;
        if (step.learningObjective.toLowerCase().includes(kw)) matchScore +=1;
      });
      
      // Phrase Matching (as previously discussed, a good feature)
      const stepKeywordsArray = Array.from(stepKeywords);
      for(let i = 0; i < stepKeywordsArray.length -1; i++) {
          const phrase2 = `${stepKeywordsArray[i]} ${stepKeywordsArray[i+1]}`;
          if(targetStepTextForKeywords.includes(phrase2)) matchScore +=3;
          if(i < stepKeywordsArray.length -2) {
            const phrase3 = `${phrase2} ${stepKeywordsArray[i+2]}`;
            if(targetStepTextForKeywords.includes(phrase3)) matchScore +=4;
          }
      }

      if (matchScore > 3.5) { // Adjusted threshold for quest step relevance
        insights.push({
          id: `insight-quest-${step.id}`,
          type: 'quest_step',
          title: `${quest.title.substring(0,25)}${quest.title.length > 25 ? '...' : ''} - ${step.title.substring(0,30)}${step.title.length > 30 ? '...' : ''}`,
          targetId: step.id,
          questId: quest.id,
          relevanceContext: `Relevant to: ${step.learningObjective.substring(0,40)}${step.learningObjective.length > 40 ? '...' : ''}`
        });
        addedInsightTargets.add(step.id);
      }
    }
  }
  
  // Sort insights by a conceptual relevance score if desired, or keep as found.
  // For now, it's capped by MAX_INSIGHTS and order of discovery.
  return insights.slice(0, MAX_INSIGHTS);
};
