
import { GoogleGenAI, GenerateContentResponse, Content, Part, GenerateContentParameters, GenerateImagesResponse, GenerateImagesParameters, FunctionCall, Tool, FunctionDeclaration } from "@google/genai";
import { ChatMessage, TextPart, ImagePart, StoryForgeLoreCategory, ChatMessagePart, ModelConfigOverrides, AvailableTools, ToolDefinition, ScenarioOutput } from "../types"; // Added ScenarioOutput
import { GEMINI_TEXT_MODEL, GEMINI_IMAGE_MODEL, GEMINI_VISION_MODEL, MAX_CHAT_HISTORY_FOR_CONTEXT, PREDEFINED_TOOLS } from '../constants';

let genAI: GoogleGenAI | null = null;

const getGenAI = (): GoogleGenAI => {
  if (!genAI) {
    let apiKeyFromEnv: string | undefined;
    if (typeof process !== 'undefined' && typeof process.env !== 'undefined') {
      apiKeyFromEnv = process.env.API_KEY;
    }
    if (!apiKeyFromEnv) {
      const errorMessage = "ConfigurationError: API_KEY is missing. Please ensure it is set in the environment.";
      console.error(errorMessage);
      throw new Error(errorMessage);
    }
    genAI = new GoogleGenAI({ apiKey: apiKeyFromEnv });
  }
  return genAI;
};

const convertAppMessagesToGeminiContent = (messages: ChatMessage[]): Content[] => {
  return messages
    .filter(msg => msg.role === 'user' || msg.role === 'model') 
    .map(msg => {
      const geminiParts: Part[] = [];
      
      msg.parts.forEach(part => {
        if ('text' in part) {
          geminiParts.push({ text: part.text });
        } else if ('inlineData' in part) {
          geminiParts.push({ inlineData: { mimeType: part.inlineData.mimeType, data: part.inlineData.data } });
        }
      });

      if (msg.isToolCallRequest && msg.toolName && msg.toolArgs) {
          geminiParts.push({
              functionCall: { name: msg.toolName, args: msg.toolArgs }
          });
      }

      if (msg.isToolResponse && msg.toolName && msg.toolResult) {
          geminiParts.push({
              functionResponse: { name: msg.toolName, response: msg.toolResult }
          });
      }
      
      return {
        role: msg.role as 'user' | 'model', 
        parts: geminiParts,
      };
    })
    .filter(content => content.parts.length > 0);
};

export const generateChatResponseMultiModal = async (
  chatHistory: ChatMessage[], 
  additionalParts?: Array<TextPart | ImagePart>, 
  configOverrides?: ModelConfigOverrides, 
  modelName?: string 
): Promise<{text: string, fullResponse?: GenerateContentResponse}> => {
  try {
    const ai = getGenAI();
    
    const historyContents = convertAppMessagesToGeminiContent(chatHistory.slice(-MAX_CHAT_HISTORY_FOR_CONTEXT));
    
    let currentTurnParts: Part[] = [];
    if (additionalParts) {
        currentTurnParts = additionalParts.map(p => 'text' in p ? {text: p.text} : {inlineData: p.inlineData});
    }

    const usesImages = chatHistory.some(msg => msg.parts.some(p => 'inlineData' in p)) || (additionalParts && additionalParts.some(p => 'inlineData' in p));
    const effectiveModel = modelName || (usesImages ? GEMINI_VISION_MODEL : GEMINI_TEXT_MODEL);

    const contentsToGenerate = [...historyContents];
    if (currentTurnParts.length > 0) {
        const lastContent = contentsToGenerate[contentsToGenerate.length -1];
        if (lastContent && lastContent.role === 'user') {
            lastContent.parts.push(...currentTurnParts);
        } else {
            contentsToGenerate.push({role: 'user', parts: currentTurnParts});
        }
    }
    
    const params: GenerateContentParameters = {
      model: effectiveModel,
      contents: contentsToGenerate,
    };

    if (configOverrides) {
      params.config = { ...params.config, ...configOverrides };
    }
    
    const response: GenerateContentResponse = await ai.models.generateContent(params);
    return {text: response.text, fullResponse: response};
  } catch (error) {
    console.error("Gemini API Error (generateChatResponseMultiModal):", error);
    const errorText = error instanceof Error ? error.message : 'Unknown error generating chat response';
    return {text: `Error: ${errorText}`};
  }
};


export const generateImageFromPrompt = async (
  prompt: string,
  negativePrompt?: string,
  numberOfImages: number = 1
): Promise<string> => { 
  try {
    const ai = getGenAI();
    const fullPrompt = negativePrompt ? `${prompt} ${negativePrompt}` : prompt;

    const params: GenerateImagesParameters = {
      model: GEMINI_IMAGE_MODEL,
      prompt: fullPrompt,
      config: { numberOfImages: numberOfImages, outputMimeType: 'image/jpeg' } 
    };

    const response: GenerateImagesResponse = await ai.models.generateImages(params);
    if (response.generatedImages && response.generatedImages.length > 0) {
        return response.generatedImages[0].image.imageBytes; 
    }
    throw new Error("No image generated or API error.");
  } catch (error) {
    console.error("Gemini API Error (generateImageFromPrompt):", error);
    throw error; 
  }
};

export const generatePromptVariations = async (originalPrompt: string): Promise<string[]> => {
  try {
    const ai = getGenAI();
    const metaPrompt = `Generate 3 creative and diverse variations of the following prompt. Return them as a JSON array of strings. For example, if the prompt is "A cat", return ["A fluffy ginger cat napping in a sunbeam", "A sleek black cat stalking through a neon-lit cyberpunk city", "A cartoon cat astronaut floating in space"]. The prompt is: "${originalPrompt}"`;
    
    const params: GenerateContentParameters = {
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: 'user', parts: [{ text: metaPrompt }] }],
      config: { responseMimeType: "application/json" }
    };

    const response: GenerateContentResponse = await ai.models.generateContent(params);
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    const variations = JSON.parse(jsonStr) as string[];
    return Array.isArray(variations) ? variations.slice(0,3) : [];
  } catch (error) {
    console.error("Gemini API Error (generatePromptVariations):", error);
    return [originalPrompt]; // Fallback to original prompt on error
  }
};

export const analyzeImageWithPrompt = async (base64ImageData: string, mimeType: string, prompt: string): Promise<string> => {
  try {
    const ai = getGenAI();
    const imagePartGemini: Part = {
      inlineData: {
        data: base64ImageData,
        mimeType: mimeType,
      },
    };
    const textPartGemini: Part = { text: prompt };

    const params: GenerateContentParameters = {
      model: GEMINI_VISION_MODEL,
      contents: [{ role: 'user', parts: [imagePartGemini, textPartGemini] }],
    };
    
    const response: GenerateContentResponse = await ai.models.generateContent(params);
    return response.text;
  } catch (error) {
    console.error("Gemini API Error (analyzeImageWithPrompt):", error);
    throw error;
  }
};

export const suggestLoreItemFromText = async (
    textSelection: string, 
    existingCategories: StoryForgeLoreCategory[] = []
): Promise<{name: string, category: StoryForgeLoreCategory, isNewCategory?: boolean} | null> => {
  try {
    const ai = getGenAI();
    const categoriesString = existingCategories.length > 0 ? existingCategories.join(', ') : 'Characters, Locations, Items, Concepts, PlotPoints, Factions';
    const prompt = `Analyze the following text selection: "${textSelection}". Suggest a single prominent potential lore item (like a character name, location, key object, faction, or abstract concept).
Respond ONLY with a JSON object containing "name" (string, the item itself) and "category" (string, one of [${categoriesString}, or a fitting new category if none match well]).
If suggesting a new category, ensure "category" reflects the new category name.
Example for existing: {"name": "The Crystal Goblet", "category": "Items"}
Example for new: {"name": "Chronomancers Guild", "category": "Factions"}
If no clear item can be extracted, return null.`;

    const params: GenerateContentParameters = {
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: { responseMimeType: "application/json" }
    };
    
    const response: GenerateContentResponse = await ai.models.generateContent(params);
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    if (jsonStr.toLowerCase() === "null") return null;
    const parsed = JSON.parse(jsonStr) as {name: string, category: string};
    
    if (!parsed.name || !parsed.category) return null;

    const isNewCategory = !existingCategories.includes(parsed.category as StoryForgeLoreCategory) && parsed.category !== "New Category";

    return { name: parsed.name, category: parsed.category as StoryForgeLoreCategory, isNewCategory };

  } catch (error) {
    console.error("Gemini API Error (suggestLoreItemFromText):", error);
    return null; 
  }
};

export const generateSimpleTextResponse = async (prompt: string, systemInstruction?: string, temperature?: number): Promise<string> => {
  try {
    const ai = getGenAI();
    const params: GenerateContentParameters = {
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
    };
    
    const config: ModelConfigOverrides = {};
    if (systemInstruction) config.systemInstruction = systemInstruction;
    if (temperature !== undefined) config.temperature = temperature;
    
    if (Object.keys(config).length > 0) {
      params.config = config;
    }

    const response: GenerateContentResponse = await ai.models.generateContent(params);
    return response.text;
  } catch (error) {
    console.error("Gemini API Error (generateSimpleTextResponse):", error);
    throw error;
  }
};

export const developCharacterAspect = async (characterName: string, storyContext: string, existingCharacters: string[]): Promise<string> => {
  const prompt = `
Character Name: ${characterName}
Story Context: "${storyContext.slice(-1000)}"
Existing Characters in Lore: ${existingCharacters.join(', ') || 'N/A'}

Based on the above, provide 2-3 distinct, creative ideas to further develop an interesting aspect of "${characterName}". This could be related to their backstory, motivations, a secret, a unique skill, a flaw, or a relationship. Be concise and evocative.
Format as bullet points.`;
  return generateSimpleTextResponse(prompt, "You are an AI creative writing assistant specializing in character development.");
};

export const describeLocationAspect = async (locationName: string, storyContext: string, existingLocations: string[]): Promise<string> => {
  const prompt = `
Location Name: ${locationName}
Story Context: "${storyContext.slice(-1000)}"
Existing Locations in Lore: ${existingLocations.join(', ') || 'N/A'}

Based on the above, provide a vivid and concise (2-3 sentences) description of "${locationName}", focusing on a unique or defining characteristic (e.g., atmosphere, key feature, sensory details, hidden secret).
Aim for a tone that matches a fantasy or sci-fi setting.`;
  return generateSimpleTextResponse(prompt, "You are an AI world-building assistant specializing in atmospheric location descriptions.");
};

export const generateDialogueSnippets = async (charactersInvolved: string, sceneContext: string, tone: string, storyContext: string): Promise<string[]> => {
  const prompt = `
Characters Involved: ${charactersInvolved}
Scene Context/Goal: ${sceneContext}
Desired Tone: ${tone || 'neutral'}
Brief Story Context: "${storyContext.slice(-1000)}"

Generate 3-4 short, distinct dialogue snippets (1-2 lines per character involved in the snippet) that fit the scene, characters, and tone.
Each snippet should be a separate item in a JSON array of strings.
Example: ["Character A: 'We need to find it before nightfall.'\\nCharacter B: 'And if we don't?'", "Character A (whispering): 'Did you hear that?'\\nCharacter B: 'It's just the wind... I hope.'"]`;
  
  const responseText = await generateSimpleTextResponse(prompt, "You are an AI dialogue writer, skilled at crafting believable and engaging character interactions.");
  try {
    let jsonStr = responseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    const snippets = JSON.parse(jsonStr) as string[];
    return Array.isArray(snippets) ? snippets : [responseText]; 
  } catch (e) {
    return [responseText]; 
  }
};

export const generateDebateTopics = async (relatedToTopic?: string): Promise<string[]> => {
  const prompt = `Generate 3-5 engaging and nuanced debate topics.
${relatedToTopic ? `These topics should ideally be related to or inspired by: "${relatedToTopic}".` : "They can be on general knowledge, ethics, philosophy, or future technologies."}
Return as a JSON array of strings.
Example: ["Is artificial general intelligence an existential threat or a utopian promise?", "Should artistic creation by AI be eligible for copyright?"]`;
  
  const responseText = await generateSimpleTextResponse(prompt, "You are an AI that generates thought-provoking debate topics.");
  try {
    let jsonStr = responseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    const topics = JSON.parse(jsonStr) as string[];
    return Array.isArray(topics) ? topics : [responseText];
  } catch (e) {
    return [responseText];
  }
};

export const blendConcepts = async (conceptA: string, conceptB: string, conceptC?: string): Promise<string> => {
  const concepts = [conceptA, conceptB, conceptC].filter(Boolean).join('", "');
  const prompt = `
Blend the following concepts: "${concepts}".
Describe the resulting blended concept in a creative and engaging way (2-4 sentences). 
Consider its unique properties, potential applications, or a short imaginative scenario involving it.
What would be a cool name for this blend?`;
  return generateSimpleTextResponse(prompt, "You are an AI idea synthesizer, expert at creatively combining disparate concepts.");
};

export const generateAnalogies = async (concept: string): Promise<string[]> => {
  const prompt = `
Generate 3 distinct and insightful analogies or metaphors for the concept: "${concept}".
Each analogy should be concise (1-2 sentences) and help to understand the concept from a different perspective.
Return the analogies as a JSON array of strings.
Example for "AI bias": ["AI bias is like a skewed lens, distorting how the AI perceives the world.", "It's like a recipe where one ingredient overpowers all others, leading to an unbalanced dish."]`;
  
  const responseText = await generateSimpleTextResponse(prompt, "You are an AI skilled at creating illuminating analogies and metaphors.");
  try {
    let jsonStr = responseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    const analogies = JSON.parse(jsonStr) as string[];
    return Array.isArray(analogies) ? analogies : [responseText]; 
  } catch (e) {
    return [responseText]; 
  }
};

export const exploreWhatIfScenarios = async (premise: string): Promise<string[]> => {
  const prompt = `
Explore the premise: "${premise}".
Generate 3 distinct "What if...?" scenarios or consequences stemming from this premise.
Each scenario should be a short paragraph (2-4 sentences) outlining a potential outcome or ramification.
Focus on creative and thought-provoking possibilities.
Return the scenarios as a JSON array of strings.`;

  const responseText = await generateSimpleTextResponse(prompt, "You are an AI scenario explorer, adept at imagining diverse consequences of a given premise.");
  try {
    let jsonStr = responseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    const scenarios = JSON.parse(jsonStr) as string[];
    return Array.isArray(scenarios) ? scenarios : [responseText]; 
  } catch (e) {
    return [responseText]; 
  }
};

export const suggestPlotTwists = async (storyContext: string, userInput?: string): Promise<string[]> => {
    const contextPrompt = userInput ? `Current user input/idea for a twist: "${userInput}"\n` : "";
    const prompt = `
Given the following story context:
"${storyContext.slice(-2000)}"
${contextPrompt}
Suggest 2-3 intriguing and unexpected plot twists that could occur next, considering the user's input if provided.
Each twist should be a concise sentence or two.
Return as a JSON array of strings.
Example: ["It turns out the trusted advisor was secretly working for the villain all along.", "The ancient prophecy was misinterpreted, and the hero's true destiny is far darker."]`;
    
    const responseText = await generateSimpleTextResponse(prompt, "You are an AI specializing in narrative twists and turns for creative writing.");
    try {
        let jsonStr = responseText.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; 
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) { 
            jsonStr = match[2].trim(); 
        }
        
        if (!jsonStr.startsWith('[')) {
             if (jsonStr.startsWith('"') && jsonStr.endsWith('"')) {
                 jsonStr = `[${jsonStr}]`;
             } else if (!jsonStr.includes(',')) { 
                 jsonStr = `["${jsonStr.replace(/"/g, '\\"')}"]`; 
             }
        }

        const twists = JSON.parse(jsonStr) as string[];
        return Array.isArray(twists) ? twists.filter(t => typeof t === 'string' && t.trim() !== '') : [];
    } catch (e) { 
      console.error("Error parsing plot twists:", e, "Original text:", responseText, "Processed JSON string:", responseText.trim().match(/^```(\w*)?\s*\n?(.*?)\n?\s*```$/s)?.[2]?.trim() || responseText.trim());
      if (typeof responseText === 'string' && !responseText.includes('{') && !responseText.includes('[')) {
        const lines = responseText.split('\n').map(line => line.replace(/^- /,'').trim()).filter(line => line.length > 5);
        if (lines.length > 0) return lines;
      }
      return []; 
    }
};

export const generateConflictIdeas = async (storyContext: string, characterNames?: string): Promise<string[]> => {
    const prompt = `
Story Context:
"${storyContext.slice(-2000)}"
${characterNames ? `Relevant Characters: ${characterNames}` : ""}

Suggest 2-3 potential conflict ideas (internal or external) that could arise or be explored further in this story.
Each idea should be briefly described (1-2 sentences).
Return as a JSON array of strings.
Example: ["Character A struggles with their loyalty to their family versus their duty to the kingdom.", "A natural disaster strikes, forcing rival factions to cooperate or perish."]`;
    const responseText = await generateSimpleTextResponse(prompt, "You are an AI assistant for writers, skilled at generating conflict ideas.");
    try {
        let jsonStr = responseText.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) { jsonStr = match[2].trim(); }
        const conflicts = JSON.parse(jsonStr) as string[];
        return Array.isArray(conflicts) ? conflicts : [responseText];
    } catch (e) { return [responseText]; }
};

export const enhanceWithSensoryDetails = async (textSnippet: string): Promise<string> => {
    const prompt = `
Original Text Snippet:
"${textSnippet}"

Rewrite or enhance this snippet by adding vivid sensory details (sight, sound, smell, touch, taste) to make it more immersive.
Return only the enhanced text.`;
    return generateSimpleTextResponse(prompt, "You are an AI creative writing assistant focused on descriptive language and sensory details.");
};

export const exploreThemes = async (storyContext: string): Promise<string[]> => {
    const prompt = `
Analyze the following story context:
"${storyContext.slice(-3000)}"

Suggest 2-3 potential underlying themes that are emerging or could be further developed in this narrative.
For each theme, briefly explain your reasoning or suggest how it could be emphasized.
Return as a JSON array of strings, where each string is a theme and its explanation.
Example: ["Betrayal and its consequences: The recent actions of Character X hint at a deeper betrayal, which could lead to widespread distrust.", "The corrupting nature of power: As Character Y gains more influence, their methods become more questionable, exploring this classic theme."]`;
    const responseText = await generateSimpleTextResponse(prompt, "You are an AI literary analyst, skilled at identifying and exploring narrative themes.");
    try {
        let jsonStr = responseText.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) { jsonStr = match[2].trim(); }
        const themes = JSON.parse(jsonStr) as string[];
        return Array.isArray(themes) ? themes : [responseText];
    } catch (e) { return [responseText]; }
};

export const generateWorldbuildingDetail = async (aspect: string, storyContext: string): Promise<string> => {
    const prompt = `
Worldbuilding Aspect to Detail: "${aspect}"
Brief Story Context (for tone and relevance, if any):
"${storyContext.slice(-1000)}"

Generate a creative and concise (2-4 sentences) description or set of ideas for the specified worldbuilding aspect.
Make it consistent with a fantasy/sci-fi or user-implied genre.`;
    return generateSimpleTextResponse(prompt, "You are an AI worldbuilding assistant, adept at generating specific cultural, technological, or environmental details.");
};

export const generateWhatIfStoryPrompts = async (storyContext: string): Promise<string[]> => {
    const prompt = `
Based on the following story context:
"${storyContext.slice(-2000)}"

Suggest 2-3 intriguing "What if...?" questions or alternative scenario premises that are directly relevant to the current plot, characters, or unresolved mysteries in the story.
Each question/premise should be concise and thought-provoking.
Return as a JSON array of strings.
Example: ["What if the hero's lost sibling is actually the antagonist's second-in-command?", "What if the magical artifact they seek has a terrible curse tied to its power?"]`;
    const responseText = await generateSimpleTextResponse(prompt, "You are an AI skilled at generating contextual 'What if...?' prompts for stories.");
    try {
        let jsonStr = responseText.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) { jsonStr = match[2].trim(); }
        const prompts = JSON.parse(jsonStr) as string[];
        return Array.isArray(prompts) ? prompts : [responseText];
    } catch (e) { return [responseText]; }
};

export const generateAiChapter = async (
    storyHistory: ChatMessage[],
    loreSummary: string,
    storyTitle: string,
    instruction: "continue_normal" | "incorporate_twist",
    twistIdea?: string 
): Promise<string> => {
    const ai = getGenAI();

    const storyHistoryForPrompt = storyHistory.slice(-7).map(msg => { 
        const prefix = msg.role === 'user' ? 'User Input/Direction' : 'Narrator';
        const textContent = msg.parts.filter(p => 'text' in p).map(p => (p as TextPart).text).join(' ');
        return `${prefix}: ${textContent}`;
    }).join('\n').slice(-2000); 

    let specificInstruction = "Continue the story by writing the next chapter. Focus on developing the plot, characters, and atmosphere naturally from the preceding events. Aim for a chapter length of roughly 300-500 words.";
    if (instruction === "incorporate_twist" && twistIdea) {
        specificInstruction = `Based on the story so far, incorporate the following plot twist/conflict idea: "${twistIdea}". Then, write the next chapter of the story, developing this new element and advancing the plot. Aim for a chapter length of roughly 300-500 words.`;
    } else if (instruction === "incorporate_twist") {
        specificInstruction = "Based on the story so far, come up with an unexpected plot twist or conflict idea, and then incorporate that into the next chapter you write. Aim for a chapter length of roughly 300-500 words.";
    }

    const systemInstruction = `You are 'Noema's Quill', a master storyteller AI.
The user is crafting a story titled: "${storyTitle}".
Current Lore Notes: ${loreSummary || 'None yet.'}
Follow this specific instruction for the next chapter: ${specificInstruction}
Maintain narrative consistency and adapt to the story's established tone and genre.
The existing story so far (last ~7 exchanges or ~2000 chars):
${storyHistoryForPrompt}`;

    const contentsForAI = convertAppMessagesToGeminiContent(storyHistory.slice(-MAX_CHAT_HISTORY_FOR_CONTEXT));
    
    contentsForAI.push({ role: 'user', parts: [{text: "Please write the next part of the story as instructed."}]});

    const params: GenerateContentParameters = {
        model: GEMINI_TEXT_MODEL,
        contents: contentsForAI,
        config: { systemInstruction },
    };

    const response: GenerateContentResponse = await ai.models.generateContent(params);
    return response.text;
};

export const analyzeUserFeedback = async (hypotheticalResponse: string, userFeedback: string): Promise<string> => {
  const prompt = `
Context: The user is practicing giving feedback to an AI.
Hypothetical AI Response (that the user is reacting to):
"${hypotheticalResponse}"

User's Feedback:
"${userFeedback}"

Analyze the user's feedback. Is it specific? Actionable? Clear? Polite? What makes it effective or ineffective? How could it be improved to better guide an AI towards a desired outcome?
Provide a concise analysis (2-4 sentences) of the user's feedback, focusing on constructive advice for them.`;
  return generateSimpleTextResponse(prompt, "You are an AI Feedback Coach, helping users learn to provide better feedback to AI models.");
};

export const generateTermExplanation = async (term: string): Promise<string> => {
  const prompt = `Provide a concise and clear explanation of the AI term: "${term}". 
Focus on its core meaning and significance in the field of AI. 
Keep it to 2-3 sentences. If it's a very common term, assume some basic understanding. If it's more niche, define it more thoroughly but still concisely.`;
  return generateSimpleTextResponse(prompt, "You are an AI expert, skilled at explaining complex terms simply.");
};

export const generateToolChatResponse = async (
  chatHistoryWithUserPrompt: ChatMessage[],
  availableTools: AvailableTools,
  systemInstruction?: string
): Promise<ChatMessage[]> => {
  const ai = getGenAI();
  const localChatHistory: ChatMessage[] = [];

  const geminiTools: Tool[] = [{
    functionDeclarations: Object.values(availableTools).map(t => t.definition as unknown as FunctionDeclaration) 
  }];

  const currentContents = convertAppMessagesToGeminiContent(chatHistoryWithUserPrompt.slice(-MAX_CHAT_HISTORY_FOR_CONTEXT));

  const params: GenerateContentParameters = {
    model: GEMINI_TEXT_MODEL, 
    contents: currentContents,
    config: { 
      tools: geminiTools,
    }
  };
  if (systemInstruction) {
    params.config = { ...params.config, systemInstruction };
  }
  
  let response: GenerateContentResponse = await ai.models.generateContent(params);

  let functionCallPart = response.candidates?.[0]?.content?.parts?.find(part => part.functionCall) as Part | undefined;

  while (functionCallPart && functionCallPart.functionCall) {
    const fc = functionCallPart.functionCall as FunctionCall;
    const toolName = fc.name;
    const toolArgs = fc.args || {};

    localChatHistory.push({
      id: crypto.randomUUID(),
      role: 'model',
      parts: [{text: `Attempting to use tool: ${toolName} with arguments: ${JSON.stringify(toolArgs)}`}],
      timestamp: Date.now(),
      isToolCallRequest: true,
      toolName: toolName,
      toolArgs: toolArgs,
    });

    let toolResult;
    if (availableTools[toolName]) {
      try {
        toolResult = await availableTools[toolName].execute(toolArgs);
      } catch (e: any) {
        toolResult = { error: `Error executing tool ${toolName}: ${e.message}` };
      }
    } else {
      toolResult = { error: `Tool ${toolName} not found or not implemented.` };
    }

     localChatHistory.push({
      id: crypto.randomUUID(),
      role: 'model', 
      parts: [{text: `Tool ${toolName} executed. Result: ${JSON.stringify(toolResult)}`}], 
      timestamp: Date.now(),
      isToolResponse: true,
      toolName: toolName,
      toolResult: toolResult,
    });
    
    const toolResponseParams: GenerateContentParameters = {
      model: GEMINI_TEXT_MODEL,
      contents: [
        ...currentContents, 
        { role: 'model', parts: [functionCallPart] }, 
        { role: 'model', parts: [{ functionResponse: { name: toolName, response: toolResult } }] } 
      ],
      config: { 
        tools: geminiTools,
      }
    };
     if (systemInstruction) {
      toolResponseParams.config = { ...toolResponseParams.config, systemInstruction };
    }

    response = await ai.models.generateContent(toolResponseParams);
    functionCallPart = response.candidates?.[0]?.content?.parts?.find(part => part.functionCall) as Part | undefined;
  }

  localChatHistory.push({
    id: crypto.randomUUID(),
    role: 'model',
    parts: [{ text: response.text }],
    timestamp: Date.now(),
  });
  
  return localChatHistory;
};

// --- Scenario Lab Service ---
export const generateScenarioFromConcept = async (concept: string): Promise<ScenarioOutput | null> => {
  const ai = getGenAI();
  const prompt = `
You are an expert scenario developer AI. Based on the user's core concept: "${concept}", generate a comprehensive story scenario.
The output MUST be a single, valid JSON object string, with no other text before or after it.
The JSON object should have the following structure and content:
{
  "titleSuggestion": "string (A catchy title based on the concept)",
  "keyElementsAndCharacters": ["string", "string", "... (3-5 key entities, characters, or core ideas)"],
  "potentialPlotPoints": ["string", "string", "... (3-5 potential major plot events or conflicts)"],
  "atmosphericDescriptors": ["string", "string", "... (3-5 adjectives describing the mood/atmosphere, e.g., Eerie, Digital, Ancient, Uplifting, Mysterious)"],
  "storyboardPrompts": [
    { "description": "string (A brief visual description of a key scene)", "imageGenPrompt": "string (A detailed prompt for an AI image generator to create this scene)" },
    { "description": "string", "imageGenPrompt": "string" },
    "... (2-3 storyboard prompts total)"
  ],
  "dialogueSnippet": "string (A short, impactful dialogue snippet (2-4 lines) between 2 characters hinting at the scenario's core tension or mystery)"
}

Example for "keyElementsAndCharacters": ["Ancient Sentient Forest", "Lost Explorer Anya", "Corrupted Crystal Heart", "Guardian Spirit of the Woods"]
Example for "potentialPlotPoints": ["Anya discovers the Forest is dying due to the Crystal's corruption.", "Anya must choose between escaping or trying to heal the Forest.", "The Guardian Spirit tests Anya's worthiness."]
Example for "atmosphericDescriptors": ["Mystical", "Ethereal", "Threatening", "Ancient"]
Example for "storyboardPrompts": [{"description": "Anya entering a glowing, corrupted part of the forest.", "imageGenPrompt": "Fantasy art. Young female explorer, Anya, cautiously steps into a dark, twisted part of an ancient forest. Strange, sickly purple light glows from a corrupted crystal embedded in a giant tree. Eerie, magical atmosphere. Detailed."}]
Example for "dialogueSnippet": "Anya (whispering): The trees... they're crying.\\nGuardian Spirit (voice like rustling leaves): And you, little spark, will you listen?"

Generate the scenario for the concept: "${concept}".
Remember, ONLY return the JSON object string.`;

  const params: GenerateContentParameters = {
    model: GEMINI_TEXT_MODEL,
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    config: { responseMimeType: "application/json" }
  };

  try {
    const response = await ai.models.generateContent(params);
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim(); 
    }
    const parsedData = JSON.parse(jsonStr) as ScenarioOutput;

    // Basic validation of the parsed structure
    if (
      parsedData &&
      typeof parsedData.titleSuggestion === 'string' &&
      Array.isArray(parsedData.keyElementsAndCharacters) &&
      Array.isArray(parsedData.potentialPlotPoints) &&
      Array.isArray(parsedData.atmosphericDescriptors) &&
      Array.isArray(parsedData.storyboardPrompts) &&
      typeof parsedData.dialogueSnippet === 'string' &&
      parsedData.storyboardPrompts.every(sp => typeof sp.description === 'string' && typeof sp.imageGenPrompt === 'string')
    ) {
      return parsedData;
    } else {
      console.error("Generated scenario data does not match expected structure:", parsedData);
      throw new Error("AI response for scenario generation had an invalid structure.");
    }
  } catch (error) {
    console.error("Gemini API Error or JSON Parsing Error (generateScenarioFromConcept):", error);
    return null;
  }
};
// --- End Scenario Lab Service ---

export const generateTextWithGoogleSearch = async (query: string): Promise<{ text: string; groundingChunks?: any[] }> => {
  try {
    const ai = getGenAI();
    const params: GenerateContentParameters = {
      model: GEMINI_TEXT_MODEL,
      contents: [{ role: 'user', parts: [{ text: query }] }],
      config: {
        tools: [{ googleSearch: {} }],
      },
    };

    const response: GenerateContentResponse = await ai.models.generateContent(params);
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    return { text: response.text, groundingChunks: groundingMetadata?.groundingChunks };
  } catch (error) {
    console.error("Gemini API Error (generateTextWithGoogleSearch):", error);
    throw error;
  }
};
