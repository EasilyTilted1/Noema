
// index.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { AppProvider } from './contexts/AppContext.tsx'; // Updated import path for AppProvider
import { AppDisplayContent } from './App.tsx'; // AppDisplayContent remains in App.tsx

// --- Start of [NOEMA ROOT EXECUTION] Logging ---
const executionId = `exec_${Date.now()}_${Math.random().toString(16).slice(2)}`;
console.log(`[NOEMA ROOT EXECUTION - ${executionId}] index.tsx script PARSED & EXECUTING.`);

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Root element not found. Ensure your HTML has a div with id='root'.");
}

console.log(`[NOEMA ROOT EXECUTION - ${executionId}] Root element #root found. Proceeding to create new root.`);
// --- End of [NOEMA ROOT EXECUTION] Logging ---

const root = ReactDOM.createRoot(rootElement);
console.log(`[NOEMA ROOT EXECUTION - ${executionId}] ReactDOM.createRoot invoked. Rendering AppProvider & AppDisplayContent.`);

root.render(
  // <React.StrictMode> // StrictMode remains commented out for now
  <AppProvider>
    <AppDisplayContent />
  </AppProvider>
  // </React.StrictMode>
);
console.log(`[NOEMA ROOT EXECUTION - ${executionId}] root.render() called for AppProvider & AppDisplayContent.`);

// === SimplestPossibleCounter and related code is removed as we are restoring App.tsx ===
