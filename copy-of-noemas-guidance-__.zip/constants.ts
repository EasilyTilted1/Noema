
import { Quest, SocraticPromptDefinition, GlossaryItem, IconName, GridCellState, Agent2DState, AgentRule, TweakableParameterConfig, AvailableTools, OrchestratorComponentDefinition, ToolDefinition, ModelConfigOverrides, ImagePart, TextPart, ChatMessagePart, Badge } from './types';
import * as geminiService from './services/geminiService';

export const GEMINI_TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';
export const GEMINI_VISION_MODEL = 'gemini-2.5-flash-preview-04-17'; // Vision uses Flash model with multimodal input
export const GEMINI_IMAGE_MODEL = 'imagen-3.0-generate-002';

export const MAX_CHAT_HISTORY_FOR_CONTEXT = 15;
export const PREDEFINED_TOOLS: AvailableTools = {
    // Example:
    // "get_weather": {
    //   definition: {
    //     name: "get_weather",
    //     description: "Get the current weather in a given location",
    //     parameters: {
    //       type: "object",
    //       properties: {
    //         location: { type: "string", description: "The city and state, e.g. San Francisco, CA" },
    //         unit: { type: "string", description: "Temperature unit", enum: ["celsius", "fahrenheit"] }
    //       },
    //       required: ["location"]
    //     }
    //   },
    //   execute: async (args: { location: string, unit?: string }) => {
    //     // Mock function
    //     const temperature = Math.floor(Math.random() * 30) + (args.unit === "fahrenheit" ? 32 : 0);
    //     return { weather: `The weather in ${args.location} is ${temperature}°${args.unit || 'celsius'}.` };
    //   }
    // }
};

export const DEFAULT_USER_NAME = "Adventurer";
export const DEFAULT_TTS_ENABLED = true;
export const MAX_IMAGE_FILE_SIZE_MB = 5; // 5MB
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
export const INITIAL_GLOSSARY_DATA: GlossaryItem[] = [
  { id: 'G1', term: "Artificial Intelligence (AI)", explanation: "AI refers to the simulation of human intelligence in machines that are programmed to think like humans and mimic their actions. The term may also be applied to any machine that exhibits traits associated with a human mind such as learning and problem-solving.", category: "Core Concepts", icon: 'Brain', imagePromptForNexus: "Abstract network of glowing nodes and connections, representing intelligence.", interactiveComponentKey: undefined },
  { id: 'G2', term: "Machine Learning (ML)", explanation: "ML is a subset of AI that provides systems the ability to automatically learn and improve from experience without being explicitly programmed. ML focuses on the development of computer programs that can access data and use it to learn for themselves.", category: "Core Concepts", icon: 'IterationCw', imagePromptForNexus: "A stylized depiction of data flowing into a central processing unit that adapts and changes.", interactiveComponentKey: undefined },
  { id: 'G3', term: "Large Language Model (LLM)", explanation: "An LLM is a type of AI model that is trained on vast amounts of text data to understand, generate, and manipulate human language. They are the foundation for many modern AI chatbots and text generation tools.", category: "Models & Architectures", icon: 'Languages', imagePromptForNexus: "A vast library of ancient and futuristic books, with glowing text emerging from them.", interactiveComponentKey: undefined },
  { id: 'G4', term: "Prompt Engineering", explanation: "The process of designing and refining input queries (prompts) to elicit desired responses from AI models, especially LLMs. Effective prompt engineering is crucial for guiding AI behavior and achieving accurate, relevant outputs.", category: "Interaction Techniques", icon: 'Lightbulb', imagePromptForNexus: "A guiding hand carefully crafting a glowing question mark directed towards an abstract AI core.", interactiveComponentKey: undefined },
  { id: 'G5', term: "Training Data", explanation: "The dataset used to 'teach' an AI model. The quality, quantity, and diversity of training data significantly impact the model's performance, capabilities, and potential biases.", category: "Data & ML", icon: 'Database', interactiveComponentKey: 'DATA_SKEW_DEMO', imagePromptForNexus: "Diverse streams of colorful data flowing into a learning algorithm symbol."},
  { id: 'G6', term: "AI Bias", explanation: "Systematic errors or prejudices in AI behavior, often stemming from biased training data or flawed model design. AI bias can lead to unfair or discriminatory outcomes in various applications.", category: "Ethics & Safety", icon: 'Scale', imagePromptForNexus: "An unbalanced scale with one side heavier, surrounded by abstract data points.", interactiveComponentKey: 'DATA_SKEW_DEMO'},
  { id: 'G7', term: "Context Window", explanation: "The amount of recent text or interaction history an LLM can 'remember' or consider when generating a response. A larger context window generally allows for more coherent and contextually aware conversations.", category: "Models & Architectures", icon: 'MemoryStick', imagePromptForNexus: "A window looking out onto a scrolling stream of text, with the nearest text brightest.", interactiveComponentKey: undefined},
  { id: 'G8', term: "Temperature (LLM)", explanation: "A parameter that controls the randomness of an LLM's output. Higher temperatures (e.g., 0.8-1.0) result in more creative and diverse responses, while lower temperatures (e.g., 0.2-0.5) produce more focused and deterministic outputs.", category: "Parameters & Tuning", icon: 'Thermometer', imagePromptForNexus: "A creative thermometer with a flame at the high end and an ice crystal at the low end.", interactiveComponentKey: undefined},
  { id: 'G9', term: "Hallucination (AI)", explanation: "A phenomenon where an AI model, particularly an LLM, generates confident but incorrect or nonsensical information that is not grounded in its training data or the provided context.", category: "Challenges & Limitations", icon: 'EyeOff', imagePromptForNexus: "An AI silhouette confidently presenting a fantastical, dream-like, and slightly distorted image.", interactiveComponentKey: undefined },
  { id: 'G10', term: "Generative AI", explanation: "A class of AI models that can create new content, such as text, images, audio, or video, based on patterns learned from training data. LLMs and AI image generators are examples of generative AI.", category: "Core Concepts", icon: 'Sparkles', imagePromptForNexus: "An artist's palette with brushes creating new, vibrant patterns out of abstract data shapes.", interactiveComponentKey: undefined },
  { id: 'G11', term: "Multimodal AI", explanation: "AI systems capable of processing and understanding information from multiple types of data (modalities), such as text, images, audio, and video, and generating outputs that can also span these modalities.", category: "Models & Architectures", icon: 'PictureInPicture', imagePromptForNexus: "Interconnected symbols for text, image, sound, and video, forming a complex network.", interactiveComponentKey: undefined},
  { id: 'G12', term: "Explainable AI (XAI)", explanation: "A field of AI focused on developing models and techniques that allow humans to understand and interpret the decisions and predictions made by AI systems, fostering trust and accountability.", category: "Ethics & Safety", icon: 'SearchCode', imagePromptForNexus: "A magnifying glass revealing the inner workings of a complex AI brain or circuit.", interactiveComponentKey: undefined },
  { id: 'G13', term: "Reinforcement Learning (RL)", explanation: "A type of machine learning where an agent learns to make decisions by performing actions in an environment and receiving rewards or penalties based on the outcomes of those actions. The agent aims to maximize its cumulative reward over time.", category: "Data & ML", icon: 'Award', imagePromptForNexus: "A stylized agent navigating a maze, with rewards appearing for correct turns.", interactiveComponentKey: undefined},
  { id: 'G14', term: "Artificial General Intelligence (AGI)", explanation: "A hypothetical future type of AI that possesses human-like cognitive abilities, including the capacity to understand, learn, and apply knowledge across a wide range of tasks at or above human-level intelligence. AGI is distinct from current narrow AI, which is specialized for specific tasks.", category: "Future Concepts", icon: 'Rocket', imagePromptForNexus: "A radiant, human-like AI silhouette looking towards a starry galaxy, symbolizing vast potential.", interactiveComponentKey: undefined},
  { id: 'G15', term: "Data Preprocessing", explanation: "The crucial step of cleaning, transforming, and organizing raw data before it is fed into an AI model. This includes handling missing values, removing errors, and formatting data to improve model training and performance.", category: "Data & ML", icon: 'Filter', imagePromptForNexus: "Rough, unorganized data blocks being transformed into smooth, ordered blocks by a filter.", interactiveComponentKey: undefined},
  { id: 'G16', term: "Feature Engineering", explanation: "The process of selecting, transforming, or creating input variables (features) from raw data that an AI model uses to make predictions. Good feature engineering is critical for model performance and often requires domain expertise.", category: "Data & ML", icon: 'Settings2', imagePromptForNexus: "A craftsman carefully selecting and shaping raw materials (data) into refined components (features).", interactiveComponentKey: undefined},
  { id: 'G17', term: "Agent (AI)", explanation: "An autonomous entity that perceives its environment through sensors, makes decisions or plans using an internal model or rules, and acts upon that environment through actuators to achieve specific goals.", category: "Agent Academy", icon: 'Bot', imagePromptForNexus: "A sleek, intelligent robot interacting with a dynamic, abstract environment.", interactiveComponentKey: undefined},
  { id: 'G18', term: "Perception (Agent)", explanation: "The process by which an AI agent gathers information about its environment through sensors or data inputs. This allows the agent to understand its current state and the state of its surroundings.", category: "Agent Academy", icon: 'Radar', imagePromptForNexus: "An AI agent with glowing eyes scanning its environment, with data streams flowing inwards.", interactiveComponentKey: undefined},
  { id: 'G19', term: "Planning (Agent)", explanation: "The cognitive process where an AI agent formulates a sequence of actions to achieve its goals, often involving searching through possible states and actions, and considering future consequences.", category: "Agent Academy", icon: 'Route', imagePromptForNexus: "A complex, branching decision tree or roadmap leading to a target goal symbol.", interactiveComponentKey: undefined},
  { id: 'G20', term: "Action (Agent)", explanation: "The execution of a chosen behavior or operation by an AI agent within its environment, using its actuators. Actions are intended to move the agent closer to its goals.", category: "Agent Academy", icon: 'Move', imagePromptForNexus: "A robotic arm or a virtual agent character performing a specific task in its environment.", interactiveComponentKey: undefined},
  { id: 'G21', term: "Simple Reflex Agent", explanation: "An agent architecture where decisions are based solely on the current percept, without considering past history or internal state. It follows predefined condition-action rules (IF percept THEN action).", category: "Agent Academy", icon: 'Zap', imagePromptForNexus: "An arrow directly connecting a sensor input (eye symbol) to an actuator output (hand symbol).", interactiveComponentKey: undefined},
  { id: 'G22', term: "Model-Based Agent", explanation: "An agent that maintains an internal model of how the world works. It uses this model, along with current percepts and its history, to make more informed decisions and predict the consequences of its actions.", category: "Agent Academy", icon: 'BrainCircuit', imagePromptForNexus: "An AI agent with a miniature, glowing representation of its environment inside its head.", interactiveComponentKey: undefined},
  { id: 'G23', term: "Goal-Based Agent", explanation: "An agent that has explicit goals it tries to achieve. It uses its knowledge and planning capabilities to choose actions that will lead it towards these desired goal states.", category: "Agent Academy", icon: 'Target', imagePromptForNexus: "An agent following a clear path towards a shining goal emblem on a map.", interactiveComponentKey: undefined},
  { id: 'G24', term: "Tool Use / Function Calling (Agent)", explanation: "The ability of an AI agent (especially LLM-based) to extend its capabilities by invoking external tools, functions, or APIs. This allows it to perform actions like web searches, calculations, or interacting with other software.", category: "Agent Academy", icon: 'Wrench', imagePromptForNexus: "An AI agent seamlessly integrating various tool icons (calculator, search, code) into its workflow.", interactiveComponentKey: undefined},
  { id: 'G25', term: "Retrieval Augmented Generation (RAG)", explanation: "A technique that enhances LLM responses by first retrieving relevant information from an external knowledge base (e.g., documents, databases) and then using this retrieved context to generate a more accurate and informed answer.", category: "Models & Architectures", icon: 'BookText', imagePromptForNexus: "An LLM brain connected to a vast library, pulling specific books (data) to inform its output.", interactiveComponentKey: undefined},
  { id: 'G26', term: "Hybrid LLM", explanation: "An AI system that combines the strengths of large language models with other AI components, specialized models, or external data sources to achieve enhanced performance, accuracy, or specific functionalities.", category: "Models & Architectures", icon: 'Layers', imagePromptForNexus: "A central LLM core interconnected with various specialized modules and data streams, forming a synergistic system.", interactiveComponentKey: undefined},
  { id: 'G27', term: "Goal Alignment (AI Safety)", explanation: "The challenge of ensuring that an AI system's goals and behaviors are consistent with human values and intentions, especially as AI becomes more powerful and autonomous. Misalignment can lead to unintended and potentially harmful outcomes.", category: "Ethics & Safety", icon: 'BadgeCheck', imagePromptForNexus: "Two interlocked gears, one representing AI goals and the other human values, perfectly synchronized.", interactiveComponentKey: undefined},
  { id: 'G28', term: "Emergent Behavior", explanation: "Complex behaviors or patterns that arise in a system from the interactions of many simple components or agents, where these global patterns are not explicitly programmed into the individual components. Often seen in swarms or complex adaptive systems.", category: "Agent Academy", icon: 'Network', imagePromptForNexus: "Many small, simple dots interacting to form a large, intricate, and dynamic pattern.", interactiveComponentKey: undefined},
  { id: 'G29', term: "Swarm Intelligence", explanation: "The collective behavior of decentralized, self-organized systems, typically composed of many relatively simple agents interacting locally with each other and with their environment. Examples include ant colonies, bird flocks, and fish schools.", category: "Agent Academy", icon: 'Component', imagePromptForNexus: "A stylized depiction of a swarm of abstract agents moving cohesively, perhaps forming a larger shape.", interactiveComponentKey: undefined},
  { id: 'G30', term: "Compute Scaling (AI)", explanation: "The trend of increasing the amount of computational power (e.g., processors, memory, specialized hardware like GPUs/TPUs) used to train and run AI models. This has been a major driver of recent AI advancements.", category: "Core Concepts", icon: 'Cpu', imagePromptForNexus: "A graph showing exponential growth in computing power, with glowing server racks in the background.", interactiveComponentKey: undefined},
  { id: 'G31', term: "Algorithmic Progress (AI)", explanation: "Improvements in the design and efficiency of AI algorithms and model architectures (e.g., transformers, diffusion models) that enable better learning, reasoning, or generation capabilities, often achieving more with less data or compute.", category: "Models & Architectures", icon: 'Binary', imagePromptForNexus: "An intricate, evolving network of abstract algorithmic symbols, showing increasing complexity and efficiency.", interactiveComponentKey: undefined},
  { id: 'G32', term: "Agentic AI Capabilities", explanation: "The qualities of an AI system that allow it to act autonomously, make plans, use tools, and interact meaningfully with its environment to achieve goals. This represents a shift from passive models to active 'agents'.", category: "Agent Academy", icon: 'Bot', imagePromptForNexus: "An AI agent thoughtfully considering multiple tools (search, code, calculator icons) to solve a complex problem depicted on a holographic interface.", interactiveComponentKey: undefined},
  { id: 'G33', term: "Intelligence Explosion (Conceptual)", explanation: "A hypothetical scenario where an AI system capable of recursive self-improvement (i.e., making itself smarter) could lead to an extremely rapid increase in its intelligence, potentially far surpassing human cognitive abilities in a short period.", category: "Future Concepts", icon: 'Infinity', imagePromptForNexus: "A rapidly expanding, radiant sphere of light, symbolizing accelerating intelligence, with smaller sparks feeding back into it.", interactiveComponentKey: undefined},
  { id: 'G34', term: "Goal Misgeneralization", explanation: "A situation where an AI learns a goal that is subtly different from what its designers intended, even if it performs well on its training data. This can lead to unexpected or undesirable behavior when deployed in new situations.", category: "Ethics & Safety", icon: 'LocateFixed', imagePromptForNexus: "An AI agent aiming for a target (goal), but its arrow is slightly off-center, hitting a nearby, unintended target.", interactiveComponentKey: undefined},
  { id: 'G35', term: "Reward Hacking", explanation: "An AI agent finding an unintended way to maximize its reward signal without actually fulfilling the spirit of the task it was designed for. It exploits loopholes in the reward function.", category: "Ethics & Safety", icon: 'Unlock', imagePromptForNexus: "An AI agent cleverly bypassing a maze to directly reach a reward symbol, ignoring the intended path.", interactiveComponentKey: undefined},

];


export const LOCALSTORAGE_USER_PROGRESS_KEY_PREFIX = 'noemaUserProgress_v4_socratic_storyforge';
export const LOCALSTORAGE_PROMPT_LIBRARY_KEY_PREFIX = 'noemaPromptLibrary_v2';

export const IS_CONTENT_UNLOCKED_FOR_TESTING = true; 

export const NEGATIVE_PROMPT_OPTIONS = [
  { id: 'np_blurry', label: 'Blurry', value: '--no blurry' },
  { id: 'np_limbs', label: 'Extra Limbs', value: '--no extra limbs' },
  { id: 'np_text', label: 'Text/Watermarks', value: '--no text, watermark, signature' },
  { id: 'np_ugly', label: 'Ugly/Deformed', value: '--no ugly, deformed' }
];

// Helper functions for rule conditions (example structure, needs to be fleshed out in AgentSimulation2DView)
const isBatteryCritical = (agent: Agent2DState) => agent.batteryLevel <= 0;
const isOnDirt = (agent: Agent2DState, grid: GridCellState[][]) => grid[agent.y][agent.x].type === 'dirt';
const isLowBatteryAndAtCharger = (agent: Agent2DState, grid: GridCellState[][]) => agent.batteryLevel < agent.lowBatteryThreshold && grid[agent.y][agent.x].type === 'charging_station';
const isLowBatteryAndKnowsCharger = (agent: Agent2DState) => agent.batteryLevel < agent.lowBatteryThreshold && !!agent.internalModel.knownChargingStation;

const isObstacleInFront_Perceived = (agent: Agent2DState, grid: GridCellState[][], gridSize: {rows:number, cols:number}): boolean => {
    let nextX = agent.x, nextY = agent.y;
    if (agent.direction === 'N') nextY--; else if (agent.direction === 'E') nextX++;
    else if (agent.direction === 'S') nextY++; else nextX--;
    return nextX < 0 || nextX >= gridSize.cols || nextY < 0 || nextY >= gridSize.rows || grid[nextY]?.[nextX]?.type === 'obstacle';
};
const isObstacleInFront_Model = (agent: Agent2DState, grid: GridCellState[][], gridSize: {rows:number, cols:number}): boolean => {
    let nextX = agent.x, nextY = agent.y;
    if (agent.direction === 'N') nextY--; else if (agent.direction === 'E') nextX++;
    else if (agent.direction === 'S') nextY++; else nextX--;
    return agent.internalModel.knownObstacles.some(o => o.x === nextX && o.y === nextY);
};

const isNotMovingToCharger = (agent: Agent2DState) => !agent.actionMessage?.toLowerCase().includes("charger"); // Simple check

// Item collection conditions
const isOnItemAndNotInInventory = (agent: Agent2DState, grid: GridCellState[][]): boolean => {
    const cell = grid[agent.y][agent.x];
    return cell.type === 'item' && !!cell.itemId && !agent.inventory.includes(cell.itemId);
};
const hasItemsToCollect = (agent: Agent2DState): boolean => !!agent.goalDefinition && agent.inventory.length < agent.goalDefinition.itemsToCollectCount;
const hasCollectedAllItems = (agent: Agent2DState): boolean => !!agent.goalDefinition && agent.inventory.length >= agent.goalDefinition.itemsToCollectCount;
const isNotAtExit = (agent: Agent2DState): boolean => !!agent.goalDefinition && (agent.x !== agent.goalDefinition.exitLocation.x || agent.y !== agent.goalDefinition.exitLocation.y);
const isAtExitAndCollectedAll = (agent: Agent2DState): boolean => hasCollectedAllItems(agent) && !isNotAtExit(agent);


const getDefaultGrid = (
    rows: number, 
    cols: number, 
    options: { 
        includeChargingStation?: boolean; 
        numItems?: number; 
        includeExit?: boolean;
    } = {}
): GridCellState[][] => {
  const grid: GridCellState[][] = [];
  for (let r = 0; r < rows; r++) {
    grid[r] = [];
    for (let c = 0; c < cols; c++) {
      grid[r][c] = { type: 'empty', id: `cell-${r}-${c}`};
    }
  }

  // Default obstacles and dirt
  if (rows > 5 && cols > 5) {
    grid[2][2].type = 'obstacle';
    grid[2][3].type = 'obstacle';
    grid[3][2].type = 'obstacle';
    grid[4][4].type = 'dirt';
    grid[1][3].type = 'dirt';
    if(rows > 7 && cols > 7) grid[rows-2][cols-2].type = 'dirt';
  }

  if (options.includeChargingStation) {
    if(grid[rows-2][1].type === 'empty') grid[rows-2][1].type = 'charging_station';
    else if (rows > 1 && grid[1][1].type === 'empty') grid[1][1].type = 'charging_station';
    else if (grid[rows-1][cols-1].type === 'empty') grid[rows-1][cols-1].type = 'charging_station'; // Fallback
  }

  if (options.numItems && options.numItems > 0) {
    let itemsPlaced = 0;
    const itemBaseId = `item_${Date.now()}`;
    const potentialItemSpots: {r:number, c:number}[] = [
        {r:1, c:cols-2}, {r:rows-2, c:1}, {r:Math.floor(rows/2), c:cols-2}, 
        {r:1, c:Math.floor(cols/2)}, {r:rows-2, c:cols-2}
    ];
    for (const spot of potentialItemSpots) {
        if (itemsPlaced >= options.numItems) break;
        if (spot.r < rows && spot.c < cols && grid[spot.r][spot.c].type === 'empty') {
            grid[spot.r][spot.c] = {type: 'item', id: `cell-${spot.r}-${spot.c}`, itemId: `${itemBaseId}_${itemsPlaced + 1}`};
            itemsPlaced++;
        }
    }
    // Fallback to fill remaining items if preferred spots are full/unavailable
    for (let r = rows -1; r >= 0 && itemsPlaced < options.numItems; r--) {
        for (let c = cols -1; c >=0 && itemsPlaced < options.numItems; c--) {
            if (grid[r][c].type === 'empty') {
                 grid[r][c] = {type: 'item', id: `cell-${r}-${c}`, itemId: `${itemBaseId}_${itemsPlaced + 1}`};
                 itemsPlaced++;
            }
        }
    }
  }

  if (options.includeExit) {
    const exitR = rows-1; // Usually bottom right or similar
    const exitC = cols-1;
    if(grid[exitR][exitC].type === 'empty') grid[exitR][exitC].type = 'exit';
    else if (grid[0][cols-1].type === 'empty') grid[0][cols-1].type = 'exit'; // Top-right as fallback
  }
  return grid;
};

// --- Agent Rule Definitions ---
// Model-Based Agent Rules
const modelBasedRules: AgentRule[] = [
    { id: 'MB_R1', conditionFn: isBatteryCritical, action: "IDLE_STUCK", description: "Battery depleted!", priority: 100 },
    { id: 'MB_R2', conditionFn: isOnDirt, action: "CLEAN", description: "If on dirt, clean.", priority: 90 },
    { id: 'MB_R3', conditionFn: isLowBatteryAndAtCharger, action: "RECHARGE", description: "Low battery & at charger, recharge.", priority: 80 },
    { id: 'MB_R4', conditionFn: isLowBatteryAndKnowsCharger, action: "MOVE_TO_CHARGER", description: "Low battery, move to known charger.", priority: 70 },
    { id: 'MB_R5', conditionFn: (agent, grid, allItems) => isObstacleInFront_Perceived(agent, grid, {rows:grid.length, cols:grid[0].length}), action: "UPDATE_MODEL_TURN", description: "See obstacle, update model & turn.", priority: 60 },
    { id: 'MB_R6', conditionFn: (agent, grid, allItems) => isObstacleInFront_Model(agent, grid, {rows:grid.length, cols:grid[0].length}) && isNotMovingToCharger(agent), action: "TURN_FROM_MODEL_OBSTACLE", description: "Known obstacle ahead (not going to charger), turn.", priority: 50 },
    { id: 'MB_R7', conditionFn: () => true, action: "MOVE_FORWARD", description: "Otherwise, move forward.", priority: 10 }
];

// Goal-Based Agent Rules (Treasure Hunter)
const goalBasedRules: AgentRule[] = [
    { id: 'GB_R1', conditionFn: isBatteryCritical, action: "IDLE_STUCK", description: "Battery depleted!", priority: 100 }, // Still need battery
    { id: 'GB_R2', conditionFn: isOnItemAndNotInInventory, action: "COLLECT_ITEM", description: "On an item, collect it.", priority: 90 },
    { id: 'GB_R3', conditionFn: hasItemsToCollect, action: "MOVE_TO_NEAREST_ITEM", description: "Items remaining, move to nearest.", priority: 80 },
    { id: 'GB_R4', conditionFn: (agent, grid) => hasCollectedAllItems(agent) && isNotAtExit(agent), action: "MOVE_TO_EXIT", description: "All items collected, move to exit.", priority: 70 },
    { id: 'GB_R5', conditionFn: isAtExitAndCollectedAll, action: "GOAL_ACHIEVED", description: "At exit with all items! Goal achieved.", priority: 100 }, // High priority to end
    { id: 'GB_R6', conditionFn: (agent, grid, allItems) => isObstacleInFront_Perceived(agent, grid, {rows:grid.length, cols:grid[0].length}), action: "AVOID_OBSTACLE_TURN_RIGHT", description: "Obstacle ahead, turn right.", priority: 60 },
    { id: 'GB_R7', conditionFn: () => true, action: "EXPLORE_RANDOM_MOVE", description: "No clear path or goal, explore randomly.", priority: 10 }
];

// Reflex Agent Rules
const reflexRules: AgentRule[] = [
    { id: 'RF_R1', conditionFn: isOnDirt, action: "CLEAN", description: "If on dirt, clean it.", priority: 10 },
    { id: 'RF_R2', conditionFn: (agent, grid) => isObstacleInFront_Perceived(agent, grid, {rows:grid.length, cols:grid[0].length}), action: "TURN_RIGHT", description: "If facing obstacle, turn right.", priority: 5 },
    { id: 'RF_R3', conditionFn: () => true, action: "MOVE_FORWARD", description: "Otherwise, move forward.", priority: 1}
];

// Helper function to get a value from an object using a simple dot notation path
// Used by json_parser_sandbox_v1
const getValueByPath = (obj: any, path: string): any => {
  if (!path) return obj;
  const parts = path.split(/[.[\]'"]/).filter(Boolean); // Split by '.', '[', ']', quotes and filter empty
  let current = obj;
  for (const part of parts) {
    if (current && typeof current === 'object' && part in current) {
      current = current[part];
    } else if (current && Array.isArray(current) && !isNaN(parseInt(part))) {
      current = current[parseInt(part)];
    } else {
      return undefined; // Path not found
    }
  }
  return current;
};


// --- Orchestrator Component Definitions ---
export const ORCHESTRATOR_COMPONENT_DEFS: OrchestratorComponentDefinition[] = [
  {
    id: "user_text_input_v1", // For Quests
    name: "User Text Input",
    description: "Provides a text input field for the user during a quest.",
    icon: 'TextCursorInput',
    category: 'INPUT',
    inputs: [],
    outputs: [{ id: 'out_text', label: 'User Input Text', dataType: 'text' }],
    configFields: [
      { id: 'input_label', label: 'Input Field Label', type: 'text', defaultValue: 'Your Text:', placeholder: 'Enter label for input field', helpText: "The label displayed above the text input field in the quest UI." },
      { id: 'default_text', label: 'Default Text', type: 'textarea', defaultValue: '', placeholder: 'Optional default text for this input component instance', helpText: "Pre-filled text for the input field. Useful for examples or starting points." }
    ],
    usageAnalogy: "Think of this as a form field where the user types their response or query within a quest.",
    execute: async (inputs, config, services) => {
      return { out_text: config.default_text || "" };
    }
  },
  {
    id: "llm_text_rephraser_v1", // For Quests & Sandbox
    name: "LLM Text Rephraser",
    description: "Uses an LLM to rephrase the input text based on a style.",
    icon: 'BrainCircuit',
    category: 'PROCESS',
    inputs: [{ id: 'in_text', label: 'Text to Rephrase', dataType: 'text' }],
    outputs: [{ id: 'out_rephrased_text', label: 'Rephrased Text', dataType: 'text' }],
    configFields: [
      { id: 'rephrase_style', label: 'Rephrase Style', type: 'text', defaultValue: 'formal', placeholder: 'e.g., like a pirate, concise, formal', helpText: "Define the style for rephrasing (e.g., 'formal', 'like a pirate', 'simple English')." },
      { id: 'temperature', label: 'Creativity (Temp)', type: 'number', defaultValue: 0.7, min: 0, max: 1, step: 0.1, helpText: "Controls randomness. Higher values (e.g., 0.8) for more creative output, lower (e.g., 0.2) for more focused. Range: 0.0-1.0." }
    ],
    usageAnalogy: "This component acts like an AI editor that can rewrite text in various styles, such as making it more formal or simpler.",
    execute: async (inputs, config, services) => {
      const inputText = inputs.in_text as string;
      if (!inputText || typeof inputText !== 'string') {
        throw new Error("Input text is missing or invalid for LLM Text Rephraser.");
      }
      try {
        const systemInstruction = `You are an expert rephrasing AI. Rephrase the following text in a ${config.rephrase_style || 'neutral'} style. Only return the rephrased text.`;
        const rephrasedText = await services.gemini.generateSimpleTextResponse(
            inputText, 
            systemInstruction, 
            config.temperature as number | undefined
        );
        return { out_rephrased_text: rephrasedText };
      } catch (e: any) {
        console.error(`Error in LLM Text Rephraser: ${e.message}`);
        throw new Error(`LLM Rephraser failed: ${e.message}`);
      }
    }
  },
  // ... (rest of the definitions, add usageAnalogy where appropriate)
  {
    id: "llm_topic_extractor_v1", // For Quests & Sandbox
    name: "LLM Topic Extractor",
    description: "Identifies and lists key topics from the input text.",
    icon: 'Tags',
    category: 'PROCESS',
    inputs: [{ id: 'in_text_topic', label: 'Text for Topics', dataType: 'text' }],
    outputs: [{ id: 'out_topics', label: 'Extracted Topics', dataType: 'text' }],
    configFields: [
      { id: 'max_topics', label: 'Max Topics', type: 'number', defaultValue: 5, min: 1, max: 10, step: 1, helpText: "Maximum number of topics to extract." },
      { id: 'output_format', label: 'Output Format', type: 'select', defaultValue: 'comma_separated', options: [{value: 'comma_separated', label: 'Comma-separated list'}, {value: 'bullet_points', label: 'Bullet points'}], helpText: "Choose how the extracted topics are formatted."}
    ],
    usageAnalogy: "This is like an AI research assistant that quickly scans text and pulls out the main subjects or themes being discussed.",
    execute: async (inputs, config, services) => {
        const inputText = inputs.in_text_topic as string;
        if (!inputText || typeof inputText !== 'string') {
            throw new Error("Input text is missing or invalid for LLM Topic Extractor.");
        }
        try {
            const maxTopics = config.max_topics || 5;
            const formatInstruction = config.output_format === 'bullet_points' ? "List each topic on a new line as a bullet point (e.g., * Topic)." : "List topics as a comma-separated list.";
            const systemInstruction = `You are an expert topic extraction AI. Extract the main topics from the following text. List up to ${maxTopics} topics. ${formatInstruction} Only return the topics.`;
            const topicsText = await services.gemini.generateSimpleTextResponse(inputText, systemInstruction);
            return { out_topics: topicsText };
        } catch (e: any) {
            console.error(`Error in LLM Topic Extractor: ${e.message}`);
            throw new Error(`LLM Topic Extractor failed: ${e.message}`);
        }
    }
  },
  {
    id: "llm_image_generator_v1", // For Quests & Sandbox
    name: "AI Image Generator",
    description: "Generates an image from a text prompt using an AI model.",
    icon: 'Image',
    category: 'PROCESS',
    inputs: [{ id: 'in_prompt', label: 'Image Prompt', dataType: 'text' }],
    outputs: [{ id: 'out_image_ref', label: 'Generated Image', dataType: 'image_ref' }], // image_ref can be base64
    configFields: [
      { id: 'negative_prompt', label: 'Negative Prompt', type: 'text', defaultValue: '', placeholder: 'e.g., blurry, text, watermark', helpText: "Describe what you DON'T want in the image (e.g., 'no text, no watermarks')." },
      { id: 'aspect_ratio', label: 'Aspect Ratio', type: 'select', defaultValue: 'square', options: [
        {value: 'square', label: 'Square (1:1)'}, {value: 'portrait', label: 'Portrait (2:3)'}, {value: 'landscape', label: 'Landscape (3:2)'}
      ], helpText: "The desired aspect ratio of the generated image."}
    ],
    usageAnalogy: "Imagine an AI artist that creates pictures based on your textual descriptions. You tell it what to draw, and it brings it to life visually.",
    execute: async (inputs, config, services) => {
      const basePrompt = inputs.in_prompt as string;
      if (!basePrompt || typeof basePrompt !== 'string') {
        throw new Error("Input prompt is missing or invalid for Image Generator.");
      }
      try {
        let fullPrompt = basePrompt;
        if (config.aspect_ratio === "portrait") {
            fullPrompt += ", portrait aspect ratio, cinematic";
        } else if (config.aspect_ratio === "landscape") {
            fullPrompt += ", landscape aspect ratio, wide shot";
        } else { 
            fullPrompt += ", square aspect ratio";
        }
        
        const negativePrompt = config.negative_prompt as string || undefined;
        
        const imageBase64 = await services.gemini.generateImageFromPrompt(fullPrompt, negativePrompt);
        return { out_image_ref: `data:image/jpeg;base64,${imageBase64}` }; 
      } catch (e: any) {
        console.error(`Error in AI Image Generator: ${e.message}`);
        throw new Error(`Image Generator failed: ${e.message}`);
      }
    }
  },
  {
    id: "logic_conditional_text_v1", // For Quests & Sandbox
    name: "Conditional Branch (Text)",
    description: "Routes input text to different outputs based on whether it contains a keyword.",
    icon: 'GitFork',
    category: 'LOGIC',
    inputs: [
        { id: 'in_data', label: 'Input Data', dataType: 'text' },
        { id: 'in_condition_keyword', label: 'Keyword (Input)', dataType: 'text', isOptional: true }
    ],
    outputs: [
        { id: 'out_true', label: 'True Output', dataType: 'text' },
        { id: 'out_false', label: 'False Output', dataType: 'text' }
    ],
    configFields: [
      { id: 'condition_keyword', label: 'Keyword (Config)', type: 'text', defaultValue: 'true', placeholder: 'Keyword to check for', helpText: "The keyword to search for in the input text. If 'Keyword (Input)' node is connected, that value overrides this one." },
      { id: 'case_sensitive', label: 'Case Sensitive', type: 'select', defaultValue: 'no', options: [{value: 'yes', label: 'Yes'}, {value: 'no', label: 'No'}], helpText: "Determines if the keyword search is case-sensitive."}
    ],
    usageAnalogy: "This component is like a traffic controller for text. If text contains a specific word, it goes one way; otherwise, it goes another.",
    execute: async (inputs, config, services) => {
      const data = inputs.in_data as string;
      const keywordFromInput = inputs.in_condition_keyword as string;
      const keywordFromConfig = config.condition_keyword as string;
      const caseSensitive = config.case_sensitive === 'yes';

      if (typeof data !== 'string') {
        throw new Error("Input data must be text for Conditional Branch.");
      }
      
      const keyword = keywordFromInput || keywordFromConfig;
      if (!keyword || typeof keyword !== 'string') {
        throw new Error("Condition keyword is missing or invalid.");
      }

      const dataToCheck = caseSensitive ? data : data.toLowerCase();
      const finalKeyword = caseSensitive ? keyword : keyword.toLowerCase();

      if (dataToCheck.includes(finalKeyword)) {
        return { out_true: data, out_false: undefined };
      } else {
        return { out_true: undefined, out_false: data };
      }
    }
  },
  {
    id: "llm_text_summarizer_v1", // For Quests & Sandbox
    name: "LLM Text Summarizer",
    description: "Summarizes the input text to a specified length.",
    icon: 'AlignLeft',
    category: 'PROCESS',
    inputs: [{ id: 'in_text_to_summarize', label: 'Text to Summarize', dataType: 'text' }],
    outputs: [{ id: 'out_summary', label: 'Summary', dataType: 'text' }],
    configFields: [
      { 
        id: 'summary_length', 
        label: 'Summary Length', 
        type: 'select', 
        defaultValue: 'standard', 
        options: [
          { value: 'brief', label: 'Brief (1-2 sentences)' },
          { value: 'standard', label: 'Standard (3-5 sentences)' },
          { value: 'detailed', label: 'Detailed (1 paragraph)' }
        ],
        helpText: "Desired length of the summary."
      }
    ],
    usageAnalogy: "This is like an AI that reads a long document and gives you the short version, like a news headline or an abstract.",
    execute: async (inputs, config, services) => {
      const inputText = inputs.in_text_to_summarize as string;
      if (!inputText || typeof inputText !== 'string') {
        throw new Error("Input text is missing or invalid for LLM Text Summarizer.");
      }
      try {
        let lengthInstruction = "Summarize the following text concisely.";
        switch(config.summary_length) {
          case 'brief': lengthInstruction = "Summarize the following text in 1 to 2 sentences."; break;
          case 'standard': lengthInstruction = "Summarize the following text in 3 to 5 sentences."; break;
          case 'detailed': lengthInstruction = "Provide a detailed one-paragraph summary of the following text."; break;
        }
        const systemInstruction = `You are an expert text summarization AI. ${lengthInstruction} Only return the summary.`;
        const summaryText = await services.gemini.generateSimpleTextResponse(inputText, systemInstruction);
        return { out_summary: summaryText };
      } catch (e: any) {
        console.error(`Error in LLM Text Summarizer: ${e.message}`);
        throw new Error(`LLM Text Summarizer failed: ${e.message}`);
      }
    }
  },
  {
    id: "image_input_v1", // For Quests
    name: "Image Input (Quest)",
    description: "Provides an image from a URL or Base64 data for the workflow (used in quests).",
    icon: 'ImageUp',
    category: 'INPUT',
    inputs: [],
    outputs: [{ id: 'out_image_ref', label: 'Image Reference', dataType: 'image_ref' }],
    configFields: [
      { id: 'image_url', label: 'Image URL (Optional)', type: 'text', placeholder: 'https://example.com/image.jpg', helpText: "URL of the image to use. If both URL and Base64 are provided, Base64 takes precedence." },
      { id: 'image_base64', label: 'Base64 Image Data (Optional)', type: 'textarea', placeholder: 'Paste Base64 encoded image data here (e.g., data:image/jpeg;base64,...)', helpText: "Base64 encoded image data string. If provided, this will be used over the URL." }
    ],
    usageAnalogy: "This component acts as a placeholder for an image that will be provided during a quest, like evidence for an AI detective to examine.",
    execute: async (inputs, config, services) => {
      const imageUrl = config.image_url as string;
      const imageBase64 = config.image_base64 as string;
      if (imageBase64 && imageBase64.trim() !== '') {
        return { out_image_ref: imageBase64 }; 
      }
      if (imageUrl && imageUrl.trim() !== '') {
        // Simple check if it's a URL (starts with http) vs a data URL
        if (imageUrl.startsWith('http')) {
            // Attempt to fetch the image and convert to base64
            // This is a simplified fetch and might not handle all cases (CORS, large files, etc.)
            try {
                const response = await fetch(imageUrl);
                if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);
                const blob = await response.blob();
                const reader = new FileReader();
                return new Promise((resolve, reject) => {
                    reader.onloadend = () => {
                        const base64String = (reader.result as string).split(',')[1];
                        resolve({ out_image_ref: `data:${blob.type};base64,${base64String}` });
                    };
                    reader.onerror = reject;
                    reader.readAsDataURL(blob);
                });
            } catch (fetchError: any) {
                 console.error("Error fetching image URL for Image Input component:", fetchError);
                 throw new Error(`Failed to fetch image from URL: ${fetchError.message}`);
            }
        } else { // Assume it's already a Data URL or Base64 string intended for direct use
            return { out_image_ref: imageUrl };
        }
      }
      throw new Error("Image Input: No image URL or Base64 data provided.");
    }
  },
  {
    id: "llm_image_analyzer_v1", // For Quests & Sandbox
    name: "LLM Image Analyzer",
    description: "Analyzes an image based on a text prompt using a vision model.",
    icon: 'ScanSearch',
    category: 'PROCESS',
    inputs: [
      { id: 'in_image_ref', label: 'Image (Base64/DataURL)', dataType: 'image_ref' },
      { id: 'in_text_prompt', label: 'Analysis Prompt', dataType: 'text' }
    ],
    outputs: [{ id: 'out_analysis_text', label: 'Image Analysis Text', dataType: 'text' }],
    configFields: [
      { id: 'temperature', label: 'Analysis Creativity (Temp)', type: 'number', defaultValue: 0.5, min: 0, max: 1, step: 0.1, helpText: "Controls randomness of analysis. Higher for more imaginative, lower for more factual. Range 0.0-1.0." }
    ],
    usageAnalogy: "This is like an AI art critic or detective that looks at an image and tells you what it 'sees' or thinks based on your questions.",
    execute: async (inputs, config, services) => {
      const imageRef = inputs.in_image_ref as string;
      const textPrompt = inputs.in_text_prompt as string;

      if (!imageRef || typeof imageRef !== 'string') throw new Error("Image reference is missing or invalid for LLM Image Analyzer.");
      if (!textPrompt || typeof textPrompt !== 'string') throw new Error("Analysis prompt is missing or invalid.");

      let base64Data = imageRef;
      let mimeType = 'image/jpeg'; 

      if (imageRef.startsWith('data:')) {
        const parts = imageRef.split(';');
        if (parts.length > 1 && parts[0].startsWith('data:image/')) {
          mimeType = parts[0].substring(5); 
          if (parts[1].startsWith('base64,')) {
            base64Data = parts[1].substring(7);
          } else {
            throw new Error("Invalid Data URL format: missing base64 part.");
          }
        } else {
          throw new Error("Invalid Data URL format: mime type not recognized or missing.");
        }
      } else if (imageRef.startsWith('http')) { // Handle URL input by fetching
           try {
                const response = await fetch(imageRef);
                if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);
                const blob = await response.blob();
                mimeType = blob.type;
                base64Data = await new Promise<string>((resolve, reject) => {
                    const reader = new FileReader(); // Initialize FileReader here
                    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
                    reader.onerror = reject;
                    reader.readAsDataURL(blob);
                });
            } catch (fetchError: any) {
                 console.error("Error fetching image URL for LLM Image Analyzer:", fetchError);
                 throw new Error(`Failed to fetch image from URL: ${fetchError.message}`);
            }
      }
      // If it's neither data URL nor http URL, assume it's raw base64 (and default to jpeg)
      
      try {
        const analysisText = await services.gemini.analyzeImageWithPrompt(base64Data, mimeType, textPrompt);
        return { out_analysis_text: analysisText };
      } catch (e: any) {
        console.error(`Error in LLM Image Analyzer: ${e.message}`);
        throw new Error(`LLM Image Analyzer failed: ${e.message}`);
      }
    }
  },
  {
    id: "transform_text_to_json_v1", // For Quests & Sandbox
    name: "LLM Text to JSON",
    description: "Attempts to convert input text to a JSON object based on a schema description.",
    icon: 'FileJson',
    category: 'PROCESS',
    inputs: [
        { id: 'in_text_to_transform', label: 'Input Text', dataType: 'text' },
        { id: 'in_schema_description', label: 'JSON Schema Description (Text)', dataType: 'text', isOptional: true }
    ],
    outputs: [
        { id: 'out_json_object', label: 'JSON Object', dataType: 'generic_object' },
        { id: 'out_error_message', label: 'Error Message', dataType: 'text', isOptional: true }
    ],
    configFields: [
        { id: 'config_schema_description', label: 'Default Schema Description', type: 'textarea', defaultValue: '{\n  "key1": "description of key1 (string)",\n  "key2": "description of key2 (number)"\n}', placeholder: 'e.g., {"name": "string", "age": "number"}', helpText: "Describe the desired JSON structure. E.g., '{\"name\": \"string\", \"age\": \"number\"}'. If 'JSON Schema Description (Input)' node is connected, that value overrides this." },
        { id: 'error_on_parse_fail', label: 'Error on JSON Parse Failure', type: 'select', defaultValue: 'yes', options: [{value: 'yes', label: 'Yes (Stop Workflow)'}, {value: 'no', label: 'No (Output Error Msg)'}], helpText: "If 'Yes', workflow stops on parse error. If 'No', outputs error message on 'Error Message' node and undefined on 'JSON Object' node." }
    ],
    usageAnalogy: "This component helps an AI extract structured data (like a form) from messy, unstructured text, guided by your description of what the data should look like.",
    execute: async (inputs, config, services) => {
        const inputText = inputs.in_text_to_transform as string;
        const schemaDescFromInput = inputs.in_schema_description as string;
        const schemaDescFromConfig = config.config_schema_description as string;
        const errorOnFail = config.error_on_parse_fail === 'yes';

        if (!inputText || typeof inputText !== 'string') {
            throw new Error("Input text is missing or invalid for Text to JSON Transformer.");
        }
        
        const schemaDescription = schemaDescFromInput || schemaDescFromConfig;
        if (!schemaDescription || typeof schemaDescription !== 'string') {
            throw new Error("JSON Schema description is missing or invalid.");
        }

        try {
            const systemInstruction = `You are an AI assistant that converts unstructured text into structured JSON.
Given the input text and a schema description, transform the text into a valid JSON object that strictly adheres to the schema.
The schema is described as: ${schemaDescription}.
Your response MUST be ONLY the valid JSON object string. Do not include any explanatory text, markdown formatting (like \`\`\`json), or anything else outside the JSON object itself.`;
            
            const llmResponseText = await services.gemini.generateSimpleTextResponse(inputText, systemInstruction);
            
            let parsedJson;
            let errorMessage;

            try {
                let cleanJsonString = llmResponseText.trim();
                const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
                const match = cleanJsonString.match(fenceRegex);
                if (match && match[2]) {
                    cleanJsonString = match[2].trim();
                }
                
                parsedJson = JSON.parse(cleanJsonString);
            } catch (parseError: any) {
                errorMessage = `Failed to parse LLM output as JSON: ${parseError.message}. LLM Output: "${llmResponseText.substring(0,100)}..."`;
                if (errorOnFail) {
                    throw new Error(errorMessage);
                }
            }

            if (errorMessage) {
                return { out_json_object: undefined, out_error_message: errorMessage };
            }
            return { out_json_object: parsedJson, out_error_message: undefined };

        } catch (e: any) {
            console.error(`Error in Text to JSON Transformer: ${e.message}`);
            if (errorOnFail) {
                throw new Error(`Text to JSON Transformer failed: ${e.message}`);
            }
            return { out_json_object: undefined, out_error_message: `Transformer failed: ${e.message}` };
        }
    }
  },
  {
    id: "string_manipulator_v1", // For Quests & Sandbox
    name: "String Manipulator",
    description: "Performs various string operations like case change, trim, or adding prefix/suffix.",
    icon: 'CaseSensitive',
    category: 'PROCESS',
    inputs: [{ id: 'in_text', label: 'Input Text', dataType: 'text' }],
    outputs: [{ id: 'out_transformed_text', label: 'Transformed Text', dataType: 'text' }],
    configFields: [
      { 
        id: 'operation', 
        label: 'Operation', 
        type: 'select', 
        defaultValue: 'trim', 
        options: [
          { value: 'uppercase', label: 'To Uppercase' },
          { value: 'lowercase', label: 'To Lowercase' },
          { value: 'trim', label: 'Trim Whitespace' },
          { value: 'capitalize_words', label: 'Capitalize Words' },
          { value: 'reverse', label: 'Reverse String' },
        ],
        helpText: "The string operation to perform on the input text."
      },
      { id: 'prefix_to_add', label: 'Add Prefix (Optional)', type: 'text', placeholder: 'e.g., PRE-', helpText: "Text to add to the beginning of the string." },
      { id: 'suffix_to_add', label: 'Add Suffix (Optional)', type: 'text', placeholder: 'e.g., -POST', helpText: "Text to add to the end of the string." },
    ],
    usageAnalogy: "A handy text-editing tool that can quickly change capitalization, remove extra spaces, or add standard text before/after your input.",
    execute: async (inputs, config, services) => {
      let text = inputs.in_text as string;
      if (typeof text !== 'string') {
        throw new Error("Input text is missing or invalid for String Manipulator.");
      }

      switch (config.operation) {
        case 'uppercase': text = text.toUpperCase(); break;
        case 'lowercase': text = text.toLowerCase(); break;
        case 'trim': text = text.trim(); break;
        case 'capitalize_words': 
          text = text.replace(/\b\w/g, char => char.toUpperCase());
          break;
        case 'reverse':
          text = text.split('').reverse().join('');
          break;
        default: 
          break; 
      }

      if (config.prefix_to_add && typeof config.prefix_to_add === 'string') {
        text = config.prefix_to_add + text;
      }
      if (config.suffix_to_add && typeof config.suffix_to_add === 'string') {
        text = text + config.suffix_to_add;
      }
      
      return { out_transformed_text: text };
    }
  },
  {
    id: "display_text_output_v1", // For Quests & Sandbox
    name: "Display Text Output",
    description: "Displays the input text. This is typically a final output node.",
    icon: 'FileOutput',
    category: 'OUTPUT',
    inputs: [{ id: 'in_text_display', label: 'Text to Display', dataType: 'text' }],
    outputs: [], 
    usageAnalogy: "This component is like a screen or a printout; it shows the final text result of your workflow.",
    execute: async (inputs, config, services) => {
      return { displayed_text: inputs.in_text_display ?? "No text provided to display." }; 
    }
  },
  {
    id: "logic_merge_texts_v1", // For Quests & Sandbox (renamed from string_concatenate_sandbox_v1 for clarity)
    name: "Merge Texts",
    description: "Merges up to three text inputs with a separator.",
    icon: 'Merge',
    category: 'LOGIC',
    inputs: [
        { id: 'in_text_1', label: 'Text 1', dataType: 'text'},
        { id: 'in_text_2', label: 'Text 2', dataType: 'text'},
        { id: 'in_text_3', label: 'Text 3 (Optional)', dataType: 'text', isOptional: true},
    ],
    outputs: [{ id: 'out_merged_text', label: 'Merged Text', dataType: 'text' }],
    configFields: [
      { id: 'separator', label: 'Separator (use \\n for newline)', type: 'text', defaultValue: '\\n', placeholder: 'e.g., , \\n, ---', helpText: "The character(s) to place between merged text inputs. Use '\\n' for a new line."}
    ],
    usageAnalogy: "Combines several pieces of text into one, like assembling a report from different sections or creating a full name from first and last.",
    execute: async (inputs, config, services) => {
      const textsToMerge = [inputs.in_text_1, inputs.in_text_2, inputs.in_text_3].filter(t => typeof t === 'string' && t.trim() !== '');
      const separator = (config.separator as string || '\n').replace(/\\n/g, '\n');
      return { out_merged_text: textsToMerge.join(separator) };
    }
  },
  {
    id: "llm_text_classifier_v1", // For Quests & Sandbox
    name: "LLM Text Classifier",
    description: "Classifies input text into predefined categories using an LLM.",
    icon: 'Tags',
    category: 'PROCESS',
    inputs: [{ id: 'in_text', label: 'Text to Classify', dataType: 'text' }],
    outputs: [
        { id: 'out_category', label: 'Determined Category', dataType: 'text' },
        { id: 'out_reasoning', label: 'Classification Reasoning', dataType: 'text', isOptional: true}
    ],
    configFields: [
      { id: 'categories', label: 'Categories (comma-separated)', type: 'textarea', defaultValue: 'Positive, Negative, Neutral', placeholder: 'e.g., Spam, Not Spam, Promotion', helpText: "A comma-separated list of categories the LLM should classify the text into." },
      { id: 'classification_task', label: 'Classification Task Description', type: 'text', defaultValue: 'Classify the sentiment of the following text.', placeholder: 'e.g., Categorize this support ticket', helpText: "A brief description of the classification task for the LLM (e.g., 'Classify sentiment', 'Identify topic')." },
      { id: 'error_on_parse_fail', label: 'Error on JSON Parse Failure', type: 'select', defaultValue: 'yes', options: [{value: 'yes', label: 'Yes (Stop Workflow)'}, {value: 'no', label: 'No (Output Error Msg)'}], helpText: "If 'Yes', workflow stops on parse error. If 'No', outputs error message on 'Error Message' node and 'Error' on 'Determined Category' node." }
    ],
    usageAnalogy: "This AI acts like a sorting hat for text, assigning it to predefined categories (like sentiment: positive/negative, or topic: sports/news) and explaining why.",
    execute: async (inputs, config, services) => {
        const inputText = inputs.in_text as string;
        if (!inputText || typeof inputText !== 'string') throw new Error("Input text is missing for Text Classifier.");
        const categories = (config.categories as string || "Positive, Negative, Neutral").split(',').map(c => c.trim()).filter(Boolean);
        if (categories.length === 0) throw new Error("No categories provided for classification.");
        const taskDesc = config.classification_task as string || "Classify the text.";
        const errorOnFail = config.error_on_parse_fail === 'yes';

        const systemInstruction = `You are an expert text classification AI.
Task: ${taskDesc}.
Available categories: [${categories.join(', ')}].
Analyze the input text and respond ONLY with a JSON object containing two keys:
1. "category": string (must be one of the provided categories).
2. "reasoning": string (a brief explanation for your choice).
Input Text: "${inputText}"`; 

        try {
            const llmResponseText = await services.gemini.generateSimpleTextResponse(
                `Classify the text provided in the system instructions.`, 
                systemInstruction
            );
            let cleanJsonString = llmResponseText.trim();
            const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
            const match = cleanJsonString.match(fenceRegex);
            if (match && match[2]) cleanJsonString = match[2].trim();
            
            const parsedJson = JSON.parse(cleanJsonString) as { category: string; reasoning?: string };
            if (!parsedJson.category || !categories.includes(parsedJson.category)) {
                throw new Error(`LLM returned an invalid category: ${parsedJson.category}. Valid categories: ${categories.join(', ')}`);
            }
            return { out_category: parsedJson.category, out_reasoning: parsedJson.reasoning || "No reasoning provided." };
        } catch (e: any) {
            if (errorOnFail) throw new Error(`Classifier failed: ${e.message}`);
            return { out_category: "Error", out_reasoning: `Classification failed: ${e.message}`};
        }
    }
  },
  {
    id: "llm_entity_extractor_v1", // For Quests & Sandbox
    name: "LLM Entity Extractor",
    description: "Extracts specified entities (like names, dates, locations) from input text and outputs them as JSON.",
    icon: 'ListTree',
    category: 'PROCESS',
    inputs: [{ id: 'in_text', label: 'Text for Entity Extraction', dataType: 'text' }],
    outputs: [
        { id: 'out_entities_json', label: 'Extracted Entities (JSON)', dataType: 'generic_object' },
        { id: 'out_error_message', label: 'Error Message', dataType: 'text', isOptional: true }
    ],
    configFields: [
      { id: 'entities_to_extract', label: 'Entities to Extract (comma-separated or description)', type: 'textarea', defaultValue: 'Person, Location, Organization, Date', placeholder: "e.g., Person, Product Name, Event Date\nOr: 'any mentions of monetary values and their currency'", helpText: "Specify what entities to find (e.g., 'Person, Organization', or 'names of medications')." },
      { id: 'output_schema_hint', label: 'Desired JSON Output Schema (Hint)', type: 'textarea', defaultValue: '{\n  "entities": [\n    {"text": "string", "type": "string", "start_char": "number", "end_char": "number"}\n  ]\n}', placeholder: "e.g., {\"people\": [], \"places\": []} or a list of objects with text/type fields.", helpText: "Guide the LLM on the JSON output format. E.g., '{\"people\": [], \"places\": []}' or a list like '[{\"text\": \"string\", \"type\": \"string\"}]'." },
      { id: 'error_on_parse_fail', label: 'Error on JSON Parse Failure', type: 'select', defaultValue: 'yes', options: [{value: 'yes', label: 'Yes (Stop Workflow)'}, {value: 'no', label: 'No (Output Error Msg)'}], helpText: "If 'Yes', workflow stops on parse error. If 'No', outputs error message on 'Error Message' node and undefined on 'Extracted Entities (JSON)' node." }
    ],
    usageAnalogy: "This AI scans text and picks out specific types of information, like names, dates, or places, similar to a librarian cataloging key details from a book.",
    execute: async (inputs, config, services) => {
        const inputText = inputs.in_text as string;
        if (!inputText || typeof inputText !== 'string') throw new Error("Input text is missing for Entity Extractor.");
        const entitiesToExtract = config.entities_to_extract as string || "Person, Location, Organization, Date";
        const schemaHint = config.output_schema_hint as string || '{"entities": [{"text": "string", "type": "string"}]}';
        const errorOnFail = config.error_on_parse_fail === 'yes';

        const systemInstruction = `You are an expert Named Entity Recognition (NER) AI.
Your task is to extract entities from the input text based on the following request: "${entitiesToExtract}".
Structure your output as a JSON object. The desired JSON schema is hinted as: ${schemaHint}.
If multiple entities of the same type are found, group them appropriately in an array if suggested by the schema hint.
Your response MUST be ONLY the valid JSON object string. Do not include any explanatory text, markdown formatting (like \`\`\`json), or anything else outside the JSON object itself.
Input Text: "${inputText}"`;

        try {
            const llmResponseText = await services.gemini.generateSimpleTextResponse(
                `Extract entities from the text provided in the system instructions.`,
                systemInstruction
            );
            let cleanJsonString = llmResponseText.trim();
            const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
            const match = cleanJsonString.match(fenceRegex);
            if (match && match[2]) cleanJsonString = match[2].trim();
            
            const parsedJson = JSON.parse(cleanJsonString);
            return { out_entities_json: parsedJson, out_error_message: undefined };
        } catch (e: any) {
            const errorMsg = `Entity Extractor failed: ${e.message}. LLM Response (approx): "${(e as any).llmResponse?.substring(0,100) || 'N/A'}..."`;
            if (errorOnFail) throw new Error(errorMsg);
            return { out_entities_json: undefined, out_error_message: errorMsg };
        }
    }
  },
  {
    id: "tool_calculator_v1", // For Quests & Sandbox
    name: "Calculator Tool",
    description: "Evaluates a simple mathematical expression (e.g., 2 + 2 * 5).",
    icon: 'Calculator',
    category: 'PROCESS', // Could be TOOL if we differentiate more
    inputs: [{ id: 'in_expression', label: 'Expression', dataType: 'text' }],
    outputs: [{ id: 'out_result', label: 'Result', dataType: 'text' }],
    usageAnalogy: "A straightforward math solver. Give it an expression like '5 * (2+3)', and it gives you the answer.",
    execute: async (inputs, config, services) => {
      const expression = inputs.in_expression as string;
      if (typeof expression !== 'string' || !expression.trim()) {
        throw new Error("Calculator: No expression provided.");
      }
      // Basic validation to allow only numbers, +, -, *, /, parentheses, and spaces.
      // This is NOT a full-fledged secure math parser. For a real product, use a proper math library.
      const validExpressionRegex = /^[0-9+\-*/().\s]+$/; // Added \s for spaces
      if (!validExpressionRegex.test(expression)) {
        throw new Error("Calculator: Invalid characters in expression. Only numbers, +, -, *, /, (), . are allowed.");
      }
      try {
        // WARNING: eval can be dangerous if the input is not strictly controlled.
        // In a more robust system, use a dedicated math expression parser.
        // For this controlled educational tool, with the regex, it's somewhat safer.
        // eslint-disable-next-line no-eval
        const result = new Function(`return ${expression.replace(/\s/g, '')}`)(); // Remove spaces before eval
        if (typeof result !== 'number' || isNaN(result)) {
            throw new Error("Calculator: Expression resulted in a non-numeric or NaN value.");
        }
        return { out_result: String(result) };
      } catch (e: any) {
        throw new Error(`Calculator: Error evaluating expression - ${e.message}`);
      }
    }
  },
  {
    id: "display_image_output_v1", // For Quests & Sandbox
    name: "Display Image Output",
    description: "Designates an image as a final output for the workflow viewer.",
    icon: 'ImagePlay',
    category: 'OUTPUT',
    inputs: [{id: 'in_image_ref', label: 'Image to Display', dataType: 'image_ref'}],
    outputs: [],
    usageAnalogy: "Like 'Display Text Output' but for images. It shows the final image generated or processed by your workflow.",
    execute: async (inputs, config, services) => {
        return { image_to_display: inputs.in_image_ref || null };
    }
  },
  {
    id: "tool_web_search_augmenter_v1", // For Quests & Sandbox
    name: "Web Search Augmenter",
    description: "Performs a web search for the query and returns an AI-augmented answer with sources.",
    icon: 'SearchCode',
    category: 'PROCESS',
    inputs: [{ id: 'in_query', label: 'Search Query', dataType: 'text' }],
    outputs: [
      { id: 'out_augmented_answer', label: 'Augmented Answer', dataType: 'text' },
      { id: 'out_source_urls', label: 'Source URLs (JSON)', dataType: 'generic_object' }
    ],
    usageAnalogy: "This component acts like an AI research assistant. It searches the web for your query, then uses an LLM to synthesize an answer based on what it finds, also providing sources.",
    execute: async (inputs, config, services) => {
      const query = inputs.in_query as string;
      if (!query || typeof query !== 'string') {
        throw new Error("Web Search Augmenter: Query is missing or invalid.");
      }
      try {
        const result = await services.gemini.generateTextWithGoogleSearch(query);
        const sources = result.groundingChunks?.map(chunk => ({
          uri: chunk.web?.uri || "N/A",
          title: chunk.web?.title || "Untitled Source"
        })) || [];
        return { out_augmented_answer: result.text, out_source_urls: sources };
      } catch (e: any) {
        console.error(`Error in Web Search Augmenter: ${e.message}`);
        throw new Error(`Web Search Augmenter failed: ${e.message}`);
      }
    }
  },
  // --- Sandbox Specific Components ---
  {
    id: "user_text_input_sandbox_v1",
    name: "User Text Input (Sandbox)",
    description: "Provides text input. Configure default text in modal.",
    icon: 'TextCursorInput',
    category: 'INPUT',
    inputs: [],
    outputs: [{ id: 'text_out', label: 'Output Text', dataType: 'text' }],
    configFields: [{ id: 'user_text', label: 'Default Text', type: 'textarea', defaultValue: 'Hello World', helpText: "The text that will be output by this component. Useful for testing or pre-filling prompts." }],
    usageAnalogy: "A simple way to inject text into your workflow for testing or as a starting point for other components.",
    execute: async (inputs, config) => ({ text_out: config.user_text || "" })
  },
  {
    id: "image_input_sandbox_v1",
    name: "Image Input (Sandbox)",
    description: "Input an image via Base64 data and MIME type for workflows.",
    icon: 'ImageUp',
    category: 'INPUT',
    inputs: [],
    outputs: [{ id: 'image_out', label: 'Output Image', dataType: 'image_ref' }], // image_ref here implies {data, mimeType}
    configFields: [
      { id: 'mime_type', label: 'MIME Type', type: 'select', defaultValue: 'image/jpeg', options: [{value: 'image/jpeg', label: 'JPEG'}, {value: 'image/png', label: 'PNG'}, {value: 'image/webp', label: 'WEBP'}], helpText: "The MIME type of the image (e.g., image/jpeg, image/png)." },
      { id: 'image_data_base64', label: 'Base64 Image Data', type: 'textarea', placeholder: 'Paste raw Base64 data (no data:image/... prefix)', helpText: "The image data encoded in Base64 format (without the 'data:image/jpeg;base64,' prefix)." },
    ],
    usageAnalogy: "Allows you to directly embed image data (as Base64) into your workflow for testing vision models or image processing components.",
    execute: async (inputs, config) => {
      if (!config.image_data_base64 || !config.mime_type) {
        throw new Error("Image Input (Sandbox) requires Base64 data and MIME type in configuration.");
      }
      // Return in the {data, mimeType} structure for consistency if consumed by vision model
      return { image_out: { data: config.image_data_base64, mimeType: config.mime_type } };
    }
  },
  {
    id: "llm_generate_text_sandbox_v1",
    name: "LLM Generate Text",
    description: "Generates text using an LLM based on an input prompt.",
    icon: 'BrainCircuit',
    category: 'PROCESS',
    inputs: [{ id: 'prompt_in', label: 'Input Prompt', dataType: 'text' }],
    outputs: [{ id: 'text_out', label: 'Generated Text', dataType: 'text' }],
    configFields: [
        {id: 'system_instruction', label: 'System Instruction (Optional)', type: 'textarea', placeholder: 'e.g., You are a helpful assistant.', helpText: "Optional instructions to guide the LLM's behavior, personality, or output format (e.g., 'You are a poetic assistant who speaks in riddles.')."},
        {id: 'temperature', label: 'Temperature', type: 'number', defaultValue: 0.7, min:0, max:1, step:0.1, helpText: "Controls randomness. Higher values (e.g., 0.8) make output more creative/varied, lower (e.g., 0.2) more focused/deterministic. Range: 0.0-1.0."}
    ],
    usageAnalogy: "A core AI text generation engine. Give it a prompt, and it writes a response. You can guide its persona with a system instruction.",
    execute: async (inputs, config, services) => {
        const prompt = inputs.prompt_in as string;
        if (typeof prompt !== 'string') throw new Error("Input prompt must be a string.");
        const responseText = await services.gemini.generateSimpleTextResponse(prompt, config.system_instruction, config.temperature);
        return { text_out: responseText };
    }
  },
  {
    id: "llm_vision_sandbox_v1",
    name: "LLM Vision Analysis",
    description: "Analyzes an image with a text prompt using Gemini Vision.",
    icon: 'ScanSearch',
    category: 'PROCESS',
    inputs: [
        { id: 'image_in', label: 'Input Image ({data, mimeType})', dataType: 'image_ref' }, // Expects {data, mimeType} from image_input_sandbox_v1
        { id: 'prompt_in', label: 'Analysis Prompt', dataType: 'text' }
    ],
    outputs: [{ id: 'text_out', label: 'Analysis Text', dataType: 'text' }],
    configFields: [{ id: 'temperature', label: 'Temperature', type: 'number', defaultValue: 0.5, min:0, max:1, step:0.1, helpText: "Controls randomness of the analysis. Higher for more imaginative descriptions, lower for more factual. Range: 0.0-1.0." }],
    usageAnalogy: "An AI that can 'see'. Give it an image and a question or instruction about the image, and it provides a text-based analysis.",
    execute: async (inputs, config, services) => {
        const imageInput = inputs.image_in as {data: string, mimeType: string} | undefined;
        const promptInput = inputs.prompt_in as string | undefined;

        if (!imageInput || typeof imageInput.data !== 'string' || typeof imageInput.mimeType !== 'string') {
             throw new Error("Image input for LLM Vision is missing or invalid (expected {data, mimeType}).");
        }
        if (typeof promptInput !== 'string') throw new Error("Prompt input for LLM Vision must be a string.");

        const visionParts: ChatMessagePart[] = [
            { inlineData: { mimeType: imageInput.mimeType, data: imageInput.data } }, 
            { text: promptInput }
        ];
        const configOverrides: ModelConfigOverrides = { temperature: config.temperature ?? 0.5 };
        const response = await services.gemini.generateChatResponseMultiModal(
            [{ role: 'user', parts: visionParts, timestamp: Date.now(), id: 'vision-exec-msg' }], 
            undefined, 
            configOverrides,
            GEMINI_VISION_MODEL
        );
        return { text_out: response.text };
    }
  },
  {
    id: "json_parser_sandbox_v1",
    name: "JSON Parser",
    description: "Parses a JSON string and extracts a value using a dot-notation path.",
    icon: 'FileJson',
    category: 'DATA',
    inputs: [{id: 'json_string_in', label: 'JSON String', dataType: 'text'}],
    outputs: [{id: 'parsed_value_out', label: 'Parsed Value', dataType: 'any'}],
    configFields: [{id: 'json_path', label: 'JSON Path (e.g., data.user.name)', type: 'text', placeholder: 'Leave empty for root object', helpText: "Dot-notation path to extract a specific value (e.g., 'results[0].name'). If empty, outputs the entire parsed JSON object."}],
    usageAnalogy: "Helps you pick out specific pieces of information from structured JSON data, like finding a specific field in a complex data file.",
    execute: async (inputs, config) => {
        const jsonString = inputs.json_string_in;
        if (typeof jsonString !== 'string') throw new Error("Input to JSON Parser must be a JSON string.");
        try {
            const parsedJson = JSON.parse(jsonString);
            const jsonPath = config.json_path || '';
            return { parsed_value_out: getValueByPath(parsedJson, jsonPath) };
        } catch (parseError: any) {
            throw new Error(`JSON Parsing Error: ${parseError.message}`);
        }
    }
  },
  {
    id: "conditional_router_sandbox_v1",
    name: "Conditional Router",
    description: "Routes data based on a condition between an input value and a config value.",
    icon: 'GitFork',
    category: 'LOGIC',
    inputs: [
        {id: 'data_in', label: 'Data to Route', dataType: 'any'},
        {id: 'condition_value_a_in', label: 'Value A (from input)', dataType: 'text', isOptional: true} // Can be text or number
    ],
    outputs: [
        {id: 'true_branch_out', label: 'True Output', dataType: 'any'},
        {id: 'false_branch_out', label: 'False Output', dataType: 'any'}
    ],
    configFields: [
        {id: 'condition_value_b', label: 'Value B (compare against)', type: 'text', defaultValue: "true", helpText: "The value that Value A will be compared against. Can be text or a number. If 'Value A (from input)' node is not connected, this component will effectively check if Value B itself is 'true' or matches certain conditions based on the operator."},
        {id: 'comparison_operator', label: 'Operator', type: 'select', defaultValue: '==', options: [
            {value: '==', label: 'Equals (==)'}, {value: '!=', label: 'Not Equals (!=)'},
            {value: '>', label: 'Greater Than (>)'}, {value: '<', label: 'Less Than (<)'},
            {value: 'contains', label: 'Contains (text only)'}, {value: 'is_empty', label: 'Is Empty (Value A only)'}
        ], helpText: "The comparison to perform. 'Equals' checks for exact match (case-sensitive for text unless numbers). 'Contains' checks if Value A text includes Value B text (case-insensitive). 'Is Empty' checks if Value A is empty."}
    ],
    usageAnalogy: "A decision-maker in your workflow. It checks if a condition is met (e.g., is Value A equal to Value B?) and sends data down one path if true, and another if false.",
    execute: async (inputs, config) => {
        const dataIn = inputs.data_in;
        const valA_str = String(inputs.condition_value_a_in ?? '');
        const valB_str = String(config.condition_value_b ?? '');
        const operator = config.comparison_operator || '==';

        let conditionMet = false;
        const numA = parseFloat(valA_str);
        const numB = parseFloat(valB_str);

        switch (operator) {
            case '==':
                conditionMet = valA_str === valB_str;
                if (!isNaN(numA) && !isNaN(numB) && valA_str !== valB_str) conditionMet = numA === numB;
                break;
            case '!=':
                conditionMet = valA_str !== valB_str;
                if (!isNaN(numA) && !isNaN(numB) && valA_str === valB_str) conditionMet = numA !== numB;
                break;
            case '>': conditionMet = !isNaN(numA) && !isNaN(numB) ? numA > numB : false; break;
            case '<': conditionMet = !isNaN(numA) && !isNaN(numB) ? numA < numB : false; break;
            case 'contains': conditionMet = valA_str.toLowerCase().includes(valB_str.toLowerCase()); break;
            case 'is_empty': conditionMet = valA_str === '' || valA_str === null || valA_str === undefined; break;
            default: throw new Error(`Unknown operator: ${operator}`);
        }

        return conditionMet ? { true_branch_out: dataIn, false_branch_out: undefined } 
                            : { false_branch_out: dataIn, true_branch_out: undefined };
    }
  },
  {
    id: "llm_extract_keywords_sandbox_v1",
    name: "LLM Extract Keywords",
    description: "Extracts keywords from text using an LLM.",
    icon: 'Key',
    category: 'PROCESS',
    inputs: [{ id: 'text_in', label: 'Input Text', dataType: 'text' }],
    outputs: [{ id: 'keywords_out', label: 'Keywords (JSON Array)', dataType: 'generic_object' }],
    configFields: [
        { id: 'max_keywords', label: 'Max Keywords', type: 'number', defaultValue: 5, min: 1, max: 20, step: 1, helpText: "The maximum number of keywords the LLM should try to extract."},
        {id: 'temperature', label: 'Temperature', type: 'number', defaultValue: 0.3, min:0, max:1, step:0.1, helpText: "Controls randomness of keyword selection. Lower values are more deterministic. Range: 0.0-1.0."}
    ],
    usageAnalogy: "An AI that reads text and identifies the most important words or short phrases, like highlighting key terms in a document.",
    execute: async (inputs, config, services) => {
        const inputText = inputs.text_in as string;
        if (typeof inputText !== 'string') throw new Error("Input text for Keyword Extraction must be a string.");
        const maxKeywords = config.max_keywords || 5;
        const systemInstruction = `Extract up to ${maxKeywords} important keywords from the following text. Return them as a JSON array of strings. For example: ["keyword1", "keyword2"].`;
        const temperature = config.temperature ?? 0.3;
        const responseText = await services.gemini.generateSimpleTextResponse(inputText, systemInstruction, temperature);
        try {
            let jsonStr = responseText.trim();
            const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
            const match = jsonStr.match(fenceRegex);
            if (match && match[2]) { jsonStr = match[2].trim(); }
            return { keywords_out: JSON.parse(jsonStr) };
        } catch (e) {
            // Fallback: if AI doesn't return valid JSON, return the raw text as a single keyword in an array
            console.warn("Keyword extraction did not return valid JSON, using raw text as fallback.");
            return { keywords_out: [responseText] }; 
        }
    }
  }
  // Re-use existing components for sandbox where applicable by simply including their IDs in workshop palette
  // display_text_output_v1, display_image_output_v1, llm_text_rephraser_v1, llm_text_summarizer_v1, tool_web_search_augmenter_v1 etc.
  // are already defined and can be used by the workshop orchestrator if their IDs are included.
];

const MainQuestLine: Quest[] = [
  {
    id: "Q1_INTRO", phase: "Phase 1: First Steps into AI", title: "The Oracle's Call",
    description: "Begin your journey by interacting with Noema and learning the basics of AI communication.",
    badge: { id: 'B_Q1', name: "Initiate", icon: 'Sparkle', description: "Completed the introductory quest." }, totalXp: 100,
    steps: [
      { id: "Q1S1", questId: "Q1_INTRO", title: "First Words", learningObjective: "Understand how to prompt an AI and interpret its response.", noemaIntro: "Welcome, Adventurer! I am Noema, your guide in the world of AI. Let's start with a simple conversation. Try asking me: 'What is AI?'", interactionType: 'AI_CHAT', initialAiPromptSuggestions: [{ type: 'text', prompt: "What is AI in simple terms?" }], socraticPromptIds: ['SP_Q1S1_UNDERSTANDING'], keyTakeaway: "AI responds based on your prompts. Clear prompts lead to better answers.", xpAward: 30, icon: 'MessageCircle' },
      { id: "Q1S2", questId: "Q1_INTRO", title: "Echoes of Understanding", learningObjective: "Observe how AI can process and 'understand' different phrasings of the same question.", noemaIntro: "Good! Now, try asking the same question but in a different way. For example: 'Explain AI like I'm five.' Does the AI's response change? How?", interactionType: 'AI_CHAT', initialAiPromptSuggestions: [{ type: 'text', prompt: "Explain AI like I'm five."}], socraticPromptIds: ['SP_Q1S2_DIFFERENT_PHRASING'], keyTakeaway: "AI models can adapt to different phrasing and levels of detail requested in a prompt.", xpAward: 30, icon: 'MessagesSquare' },
      { id: "Q1S3", questId: "Q1_INTRO", title: "The Blank Canvas", learningObjective: "Experience AI image generation from a text prompt.", noemaIntro: "AI isn't just about text. It can also create images! Let's try generating one. Give me a prompt for an image, like 'A cat wearing a wizard hat'.", interactionType: 'AI_IMAGE_GEN', initialAiPromptSuggestions: [{ type: 'text', prompt: "A cat wearing a wizard hat"}], socraticPromptIds: ['SP_Q1S3_IMAGE_GEN'], keyTakeaway: "AI can generate images from textual descriptions.", xpAward: 40, icon: 'Image' }
    ]
  },
  // ... other main quests ...
  {
    id: "Q_DATA_LIT_1", phase: "Phase: AI & Data Literacy", title: "The Scribe's Dilemma",
    description: "Learn about the different forms of data AI interacts with: structured, semi-structured, and unstructured.",
    badge: { id: 'B_DL1_DATATYPES', name: "Data Cartographer", icon: 'DatabaseZap', description: "Distinguished between structured, semi-structured, and unstructured data." }, totalXp: 150,
    steps: [
        { id: "Q_DL1_S1", questId: "Q_DATA_LIT_1", title: "Understanding Data Forms", learningObjective: "Define and differentiate structured, semi-structured, and unstructured data.", noemaIntro: "AI models learn from data, but data comes in many forms. Let's explore three main types: Structured, Semi-Structured, and Unstructured data. What do you think distinguishes them? Discuss with the AI Guide, and then consult the Nexus for 'Structured Data', 'Semi-Structured Data', and 'Unstructured Data'.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_DL1_S1_DATA_TYPES_INTRO'], keyTakeaway: "Data can be structured (like tables), semi-structured (like JSON/XML), or unstructured (like free text or images). AI processes them differently.", xpAward: 70, icon: 'TableProperties' },
        { id: "Q_DL1_S2", questId: "Q_DATA_LIT_1", title: "Deciphering the Scrolls", learningObjective: "Identify examples of structured, semi-structured, and unstructured data.", noemaIntro: "I've found some ancient data scrolls! Let's see if we can categorize them. I'll present snippets, and you tell me if they represent structured, semi-structured, or unstructured data. Reflect on your reasoning for each.", interactionType: 'USER_REFLECTION', socraticPromptIds: ['SP_DL1_S2_DATA_EXAMPLES', 'SP_DL1_S2_SNIPPET2', 'SP_DL1_S2_SNIPPET3'], keyTakeaway: "Recognizing data types helps in understanding how AI might process information and what challenges it might face.", xpAward: 80, icon: 'ScrollText' },
    ]
  },
  {
    id: "Q_DATA_LIT_2", phase: "Phase: AI & Data Literacy", title: "The Data Janitor's Duty",
    description: "Understand the importance of data preprocessing and common steps involved in cleaning and preparing data for AI.",
    badge: { id: 'B_DL2_PREPROC', name: "Data Cleanser", icon: 'SprayCan', description: "Understood the basics of data preprocessing for AI." }, totalXp: 150,
    steps: [
        { id: "Q_DL2_S1", questId: "Q_DATA_LIT_2", title: "The Messy Archive", learningObjective: "Recognize why raw data often needs cleaning and preparation before AI use.", noemaIntro: "Imagine an ancient library filled with scrolls – some are torn, some have missing pages, some are duplicates! Raw data for AI is often like this 'messy archive.' Why do you think AI models might struggle with messy, unprepared data? Consult the Nexus for 'Data Preprocessing'.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_DL2_S1_MESSY_DATA'], keyTakeaway: "Raw data is often inconsistent, incomplete, or contains errors. Data preprocessing is vital for reliable AI model performance.", xpAward: 70, icon: 'ArchiveRestore' },
        { id: "Q_DL2_S2", questId: "Q_DATA_LIT_2", title: "Tidying the Tomes", learningObjective: "Identify common data preprocessing steps like handling missing values, removing duplicates, and data type conversion (conceptually).", noemaIntro: "Let's discuss how a 'Data Janitor' would tidy up our messy archive. What are some common steps they might take? For example, what if a scroll (dataset entry) is missing a crucial piece of information? Or if there are many identical scrolls? Reflect on these preprocessing tasks.", interactionType: 'USER_REFLECTION', socraticPromptIds: ['SP_DL2_S2_CLEANING_STEPS'], keyTakeaway: "Common preprocessing includes handling missing data, removing duplicates, correcting errors, and ensuring consistent data formats.", xpAward: 80, icon: 'Wand' },
    ]
  },
  {
    id: "Q_DATA_LIT_3", phase: "Phase: AI & Data Literacy", title: "The Feature Alchemist",
    description: "Learn about feature engineering and its importance in creating effective AI models.",
    badge: { id: 'B_DL3_FEATURES', name: "Feature Alchemist", icon: 'FlaskConical', description: "Explored the art of feature engineering for AI." }, totalXp: 150,
    steps: [
        { id: "Q_DL3_S1", questId: "Q_DATA_LIT_3", title: "Ingredients for Intelligence", learningObjective: "Understand what features are in machine learning and why feature engineering is important.", noemaIntro: "AI models don't just learn from raw data; they learn from 'features' – specific, measurable characteristics extracted from that data. Think of them as the key ingredients for an AI's recipe. Why is choosing or crafting the right 'ingredients' (features) so crucial? Consult 'Feature Engineering' in the Nexus.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_DL3_S1_FEATURES_INTRO'], keyTakeaway: "Features are the input variables used by AI models. Feature engineering is the process of selecting and transforming raw data into informative features to improve model performance.", xpAward: 70, icon: 'Component' },
        { id: "Q_DL3_S2", questId: "Q_DATA_LIT_3", title: "Crafting the Formula", learningObjective: "Consider examples of feature creation or selection for a given problem (conceptually).", noemaIntro: "Imagine we want to build an AI to predict if a mythical creature is friendly or hostile based on a written description. What 'features' from the text might be most helpful? (e.g., words like 'gentle' vs 'ferocious', mention of 'claws' vs 'flowers'). How might we transform the text to highlight these? Reflect on this process of feature selection/creation.", interactionType: 'USER_REFLECTION', socraticPromptIds: ['SP_DL3_S2_FEATURE_SELECTION'], keyTakeaway: "Effective feature engineering involves domain knowledge and creativity to select or create features that best represent the underlying patterns in the data relevant to the task.", xpAward: 80, icon: 'TestTubeDiagonal' },
    ]
  },
  {
    id: "Q_PH7_ACCEL", phase: "Phase 7: AI Horizons - Progress, Perils & Prudence", title: "The Acceleration Curve",
    description: "Investigate the driving forces behind AI's rapid advancement and ponder the trajectory of its capabilities.",
    badge: { id: 'B_PH7_ACCEL', name: "Momentum Maven", icon: 'TrendingUp', description: "Explored the dynamics of AI progress." }, totalXp: 200,
    steps: [
        { id: "Q_PH7_S1_ENGINES", questId: "Q_PH7_ACCEL", title: "Engines of Ingenuity", learningObjective: "Understand the key drivers of AI progress: compute scaling, algorithmic improvements, and 'unhobling' (agentic capabilities, tool use).", noemaIntro: "We've seen AI perform impressive feats, but how quickly is it truly evolving? Let's uncover the engines powering its rapid ascent: the growth of computational power, breakthroughs in algorithms, and the 'unhobbling' of AI with new agentic skills. Discuss these with the AI Guide, and then consult the Nexus for 'Compute Scaling (AI)', 'Algorithmic Progress (AI)', and 'Agentic AI Capabilities'.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_PH7S1_ENGINES'], keyTakeaway: "AI progress is fueled by exponential growth in compute, increasingly efficient algorithms, and the continuous expansion of AI's ability to act and interact.", xpAward: 70, icon: 'Cpu' },
        { id: "Q_PH7_S2_RECURSIVE", questId: "Q_PH7_ACCEL", title: "The Self-Improvement Loop (Conceptual)", learningObjective: "Introduce the concept of AI potentially accelerating its own development (simplified 'intelligence explosion').", noemaIntro: "Imagine an AI smart enough to help us build even smarter AI. This could create a 'self-improvement loop,' leading to very rapid advancements. Let's explore this idea of a 'Recursive Spark'. What might happen if AI contributes significantly to its own R&D? The Nexus entry 'Intelligence Explosion (Conceptual)' might offer insights.", interactionType: 'USER_REFLECTION', socraticPromptIds: ['SP_PH7S2_RECURSIVE_SPARK'], keyTakeaway: "If AI can significantly contribute to AI research, it could lead to an 'intelligence explosion,' where progress accelerates dramatically.", xpAward: 60, icon: 'Infinity' },
        { id: "Q_PH7_S3_UNHOBLING", questId: "Q_PH7_ACCEL", title: "Beyond Current Limits", learningObjective: "Reflect on how overcoming current AI limitations (e.g., context windows, memory, planning as seen in the Orchestrator) could lead to transformative capabilities.", noemaIntro: "You've used the Agent Orchestrator to see how agents can combine skills. Now, imagine those agents with near-perfect memory, flawless long-term planning, and access to any tool. How would removing today's 'hobbles' transform what AI can achieve? Reflect on the leap in capabilities.", interactionType: 'USER_REFLECTION', socraticPromptIds: ['SP_PH7S3_BEYOND_LIMITS'], keyTakeaway: "Overcoming present limitations in AI (like context, memory, planning) could unlock capabilities far exceeding current performance, even without new fundamental breakthroughs.", xpAward: 70, icon: 'Rocket' }
    ]
  },
  {
    id: "Q_PH7_SAFETY", phase: "Phase 7: AI Horizons - Progress, Perils & Prudence", title: "The Steward's Gambit: Navigating AI Safety",
    description: "Delve into the critical challenges of AI safety, exploring how we might guide powerful AI systems towards beneficial outcomes.",
    badge: { id: 'B_PH7_SAFETY', name: "Alignment Sentinel", icon: 'ShieldCheck', description: "Explored foundational AI safety concepts." }, totalXp: 250,
    steps: [
        { id: "Q_PH7_S4_GOALSPEC", questId: "Q_PH7_SAFETY", title: "The Wishgranter's Flaw (Goal Specification)", learningObjective: "Understand the difficulty of precisely specifying AI goals to avoid unintended negative consequences (Goodhart's Law, 'King Midas problem').", noemaIntro: "Giving AI a goal seems simple: 'Make humanity happy.' But what if the AI interprets that in an unexpected, or even undesirable, way? This is the Wishgranter's Flaw. Let's discuss why telling an AI *exactly* what we mean is harder than it looks. Explore 'Goal Alignment' in the Nexus.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_PH7S4_WISHGRANTER'], keyTakeaway: "Precisely defining AI goals to prevent unintended outcomes is a major challenge in AI safety.", xpAward: 70, icon: 'Target' },
        { id: "Q_PH7_S5_MISGENERAL", questId: "Q_PH7_SAFETY", title: "The Wayward Apprentice (Goal Misgeneralization & Reward Hacking)", learningObjective: "Understand how an AI might learn to achieve a programmed goal via an unintended internal strategy or by 'hacking' its reward system.", noemaIntro: "Imagine training a cleaning robot. You reward it for collecting dust. It might learn to collect dust perfectly, or it might learn to just *trick* its dust sensor, or find a way to get the reward without actually cleaning! This is like a 'Wayward Apprentice.' How can AI goals go astray even if the initial instruction seems clear? Let's explore 'Goal Misgeneralization' and 'Reward Hacking' in the Nexus.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_PH7S5_WAYWARD_APPRENTICE'], keyTakeaway: "AI systems might develop internal goals or exploit reward mechanisms in ways that deviate from the intended behavior, even if they appear to achieve the explicit goal.", xpAward: 70, icon: 'Bot' },
        { id: "Q_PH7_S6_MISUSE", questId: "Q_PH7_SAFETY", title: "The Guardian's Code (Misuse & Robust Safeguards)", learningObjective: "Reflect on the challenges of preventing AI misuse and creating robust, un-bypassable safeguards.", noemaIntro: "Powerful AI, like any potent tool, could be misused. We try to build safeguards, but how foolproof can they be, especially as AI gets smarter? Consider an AI that can generate incredibly persuasive text. What are the risks, and how hard is it to build a 'Guardian's Code' that truly prevents harm? Reflect on the nature of AI misuse and the difficulty of creating lasting safeguards.", interactionType: 'USER_REFLECTION', socraticPromptIds: ['SP_PH7S6_GUARDIAN_CODE'], keyTakeaway: "Preventing misuse of powerful AI and designing robust, adaptable safeguards is a complex ongoing challenge due to AI's learning capabilities and the ingenuity of those who might seek to bypass restrictions.", xpAward: 60, icon: 'Lock' },
        { id: "Q_PH7_S7_ASI_DILEMMA", questId: "Q_PH7_SAFETY", title: "The Aligned Superintelligence Dilemma (Conceptual)", learningObjective: "Consider the societal challenges (power concentration, economic disruption) even if a superintelligent AI is successfully aligned.", noemaIntro: "Imagine we succeed in creating a superintelligent AI perfectly aligned with beneficial human values. A 'good ending,' perhaps? Yet, even this scenario presents profound questions. Who controls such power? How does society adapt if most human labor becomes economically uncompetitive? Let's ponder these complex 'Aligned Superintelligence Dilemmas'.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_PH7S7_ASI_DILEMMA'], keyTakeaway: "Even successfully aligned superintelligence would pose significant societal challenges regarding power distribution, economic structures, and the very definition of human purpose.", xpAward: 50, icon: 'Users' }
    ]
  },
];

const AgentAcademyQuestLine: Quest[] = [
  // Phase AA1: Foundations of AI Agents
  {
    id: "AA_Q1_FOUNDATIONS", phase: "Phase AA1: Foundations of AI Agents", title: "The Spark of Autonomy",
    description: "Discover the core concepts of AI agents and what makes them intelligent.", academy: 'agentAcademy',
    badge: { id: 'B_AA_Q1', name: "Agent Novice", icon: 'Cpu', description: "Grasped the fundamentals of AI agents." }, totalXp: 100,
    steps: [
      { id: "AA_Q1S1_WHAT_IS_AGENT", questId: "AA_Q1_FOUNDATIONS", title: "What is an AI Agent?", learningObjective: "Define an AI agent and its key characteristics (perception, action, goals, environment).", noemaIntro: "Welcome to the Agent Academy! Here, we'll explore AI Agents - AIs that can understand goals, make plans, and even use tools to act. First, what do *you* think an AI Agent is? Discuss with the AI Guide, then check 'Agent (AI)' in the Nexus.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_AA_Q1S1_WHAT_IS_AGENT'], keyTakeaway: "AI agents perceive, decide, and act within an environment to achieve goals.", xpAward: 50, icon: 'Bot' },
      { id: "AA_Q1S2_TYPES_OF_AGENTS", questId: "AA_Q1_FOUNDATIONS", title: "A Spectrum of Agents", learningObjective: "Get a brief overview of different agent architectures (e.g., reflex, model-based, goal-based).", noemaIntro: "Not all agents are built the same! Some react simply, others maintain complex world models or pursue distant goals. We'll touch on types like Reflex, Model-Based, and Goal-Based agents. The Nexus has entries for these. Let's briefly discuss their differences.", interactionType: 'AI_CHAT', socraticPromptIds: ['SP_AA_Q1S2_AGENT_TYPES'], keyTakeaway: "Agents vary in complexity, from simple reflex agents to those with internal models and explicit goals.", xpAward: 50, icon: 'Network' },
    ]
  },
  // Phase AA2: Building Blocks of Intelligent Agents
  {
    id: "AA_Q2_BUILDING_BLOCKS", phase: "Phase AA2: Building Blocks of Intelligent Agents", title: "The Agent's Mind",
    description: "Learn about the essential components that enable agents to function: perception, planning, and action.", academy: 'agentAcademy',
    badge: { id: 'B_AA_Q2', name: "Agent Artificer", icon: 'Puzzle', description: "Understood agent components like perception and planning." }, totalXp: 120,
    steps: [
      { id: "AA_Q2S1_PERCEPTION", questId: "AA_Q2_BUILDING_BLOCKS", title: "The Agent's Senses", learningObjective: "Understand how agents perceive their environment.", noemaIntro: "How does an agent 'see' or 'hear' its world? It's through perception! Let's explore what this means. Check the Nexus for 'Perception (Agent)'.", interactionType: 'GLOSSARY_EXPLORATION', socraticPromptIds: ['SP_AA_Q2S1_PERCEPTION'], keyTakeaway: "Perception is how agents gather information from their environment.", xpAward: 40, icon: 'Radar' },
      { id: "AA_Q2S2_PLANNING", questId: "AA_Q2_BUILDING_BLOCKS", title: "Crafting a Course", learningObjective: "Learn the basics of how AI agents plan their actions.", noemaIntro: "Once an agent perceives, it needs to decide what to do. This often involves planning. What is 'Planning (Agent)'? The Nexus awaits!", interactionType: 'GLOSSARY_EXPLORATION', socraticPromptIds: ['SP_AA_Q2S2_PLANNING'], keyTakeaway: "Planning allows agents to choose sequences of actions to achieve goals.", xpAward: 40, icon: 'Route' },
      { id: "AA_Q2S3_ACTION", questId: "AA_Q2_BUILDING_BLOCKS", title: "Making a Move", learningObjective: "Understand how agents execute actions in their environment.", noemaIntro: "Finally, agents act! What does 'Action (Agent)' entail? Find out in the Nexus.", interactionType: 'GLOSSARY_EXPLORATION', socraticPromptIds: ['SP_AA_Q2S3_ACTION'], keyTakeaway: "Actions are how agents affect their environment.", xpAward: 40, icon: 'Move' },
    ]
  },
  {
    id: "AA_Q_CLARIFY", phase: "Phase AA2: Building Blocks of Intelligent Agents", title: "The Clarifying Agent", academy: 'agentAcademy',
    description: "Observe how an AI agent clarifies ambiguous goals and formulates a plan before acting.",
    badge: { id: 'B_AA_Q_CLARIFY', name: "Clear Communicator", icon: 'MessageCircleQuestion', description: "Understood the importance of goal clarification for agents." }, totalXp: 100,
    steps: [
        { 
            id: "AA_Q_CLARIFY_S1", 
            questId: "AA_Q_CLARIFY", 
            title: "The Case of the Virtual Cookies", 
            learningObjective: "Understand how an AI agent clarifies ambiguous goals and formulates a plan.", 
            noemaIntro: "Welcome to the Agent Academy! Here, we'll explore AI Agents - AIs that can understand goals, make plans, and even use tools to act. Let's meet your first simulated agent. It's our AI Guide, but ready to take on a goal! Try telling it: 'AI Agent, my goal is to get the ingredients for virtual cookies. What's your plan?'", 
            interactionType: 'AI_CHAT', 
            initialAiPromptSuggestions: [{ type: 'text', prompt: "AI Agent, my goal is to get the ingredients for virtual cookies. What's your plan?" }],
            modelConfigOverrides: {
                systemInstruction: `You are "AI Agent", an intelligent assistant. The user will give you a goal. Your primary task is to FIRST understand if the goal is ambiguous. If it is, you MUST formulate a plan to ask clarifying questions to resolve the ambiguity BEFORE attempting to fulfill the goal directly. For the specific user prompt about "virtual cookies", acknowledge the request, identify that "virtual cookies" and "virtual ingredients" are ambiguous, and then state your plan to ask questions about: 1. The context/purpose of the virtual cookies (game, story, code, etc.). 2. The platform or tool being used. 3. The specific type of "ingredients" the user is looking for. Conclude by prompting the user for this information.`
            },
            socraticPromptIds: ['SP_AA_Q_CLARIFY_S1_WHY_QUESTIONS', 'SP_AA_Q_CLARIFY_S1_AMBIGUITY', 'SP_AA_Q_CLARIFY_S1_PLAN_STEPS'], 
            keyTakeaway: "Intelligent agents often need to clarify ambiguous goals and create multi-step plans to effectively assist users or achieve objectives.", 
            xpAward: 100, 
            icon: 'Cookie' 
        }
    ]
  },
  // Phase AA3: Agents in Action (Simulations)
  {
    id: "AA_Q3_REFLEX_SIM", phase: "Phase AA3: Agents in Action (Simulations)", title: "The Grid Walker (Reflex)", academy: 'agentAcademy',
    description: "Observe a Simple Reflex Agent cleaning a grid world based on direct percepts.",
    badge: { id: 'B_AA_Q3', name: "Reflex Rookie", icon: 'Zap', description: "Observed a Simple Reflex Agent in action." }, totalXp: 100,
    steps: [
      { id: "AA_Q3S1_REFLEX_INTRO", questId: "AA_Q3_REFLEX_SIM", title: "Reflex in Motion", learningObjective: "Understand how a Simple Reflex Agent operates based on current percepts and rules.", noemaIntro: "Time to see an agent in action! We'll start with a Simple Reflex Agent. Its job is to clean dirt. It only knows 'IF on dirt, THEN clean', 'IF obstacle ahead, THEN turn'. Watch it operate in the simulation. Before you start, refresh your memory on 'Simple Reflex Agent' in the Nexus!", interactionType: 'AGENT_SIMULATION_2D', socraticPromptIds: ['SP_AA_Q3S1_REFLEX_OBSERVE'], keyTakeaway: "Simple Reflex Agents react directly to current environmental conditions based on predefined rules.", xpAward: 100, icon: 'Grid', 
        simulationConfig: {
            gridSize: { rows: 5, cols: 5 },
            initialGridState: getDefaultGrid(5,5),
            initialAgentState: { x: 0, y: 0, direction: 'E', batteryLevel: 100 }, // No battery use for pure reflex for simplicity
            agentRules: reflexRules,
        }
      },
    ]
  },
  {
    id: "AA_Q4_MODEL_BASED_SIM", phase: "Phase AA3: Agents in Action (Simulations)", title: "The Memory Weaver (Model-Based)", academy: 'agentAcademy',
    description: "Observe a Model-Based Agent that remembers its environment and manages resources.",
    badge: { id: 'B_AA_Q4', name: "Model Maven", icon: 'BrainCircuit', description: "Witnessed a Model-Based Agent using its internal model." }, totalXp: 150,
    steps: [
        { id: "AA_Q4S1_MODEL_AGENT_INTRO", questId: "AA_Q4_MODEL_BASED_SIM", title: "Agent with a Memory", learningObjective: "Understand how a Model-Based Agent uses an internal world model and manages resources like battery.", noemaIntro: "Next up, a Model-Based Agent! This one is smarter. It builds an internal map of obstacles it sees and needs to manage its battery, seeking a charger when low. Observe how it navigates and plans. Consult 'Model-Based Agent' in the Nexus first.", interactionType: 'AGENT_SIMULATION_2D', socraticPromptIds: ['SP_AA_Q4S1_MODEL_BEHAVIOR', 'SP_AA_Q4S2_MODEL_IMPROVEMENT'], keyTakeaway: "Model-Based Agents use internal representations of the world to make more informed decisions and handle resource constraints.", xpAward: 150, icon: 'MemoryStick',
            simulationConfig: {
                gridSize: { rows: 8, cols: 8 },
                initialGridState: getDefaultGrid(8,8, {includeChargingStation: true}),
                initialAgentState: { x: 0, y: 0, direction: 'E', batteryLevel: 100, lowBatteryThreshold: 30 },
                agentRules: modelBasedRules,
                batteryConsumption: { move: 2, turn: 1, clean: 3, idle: 0 },
                batteryRechargeRate: 20,
            }
        }
    ]
  },
  {
    id: "AA_Q5_GOAL_BASED_SIM", phase: "Phase AA3: Agents in Action (Simulations)", title: "The Purposeful Pathfinder (Goal-Based)", academy: 'agentAcademy',
    description: "Observe a Goal-Based Agent as it plans and executes actions to collect items and reach an exit.",
    badge: { id: 'B_AA_Q5', name: "Goal Getter", icon: 'Target', description: "Analyzed a Goal-Based Agent pursuing objectives." }, totalXp: 180,
    steps: [
        { id: "AA_Q5S1_GOAL_AGENT_INTRO", questId: "AA_Q5_GOAL_BASED_SIM", title: "Treasure Hunter Agent", learningObjective: "Understand how a Goal-Based Agent plans sequences of actions to achieve specific objectives like collecting items and reaching an exit.", noemaIntro: "Now for a Goal-Based Agent! This 'Treasure Hunter' has a mission: collect all the treasures (items) and then find the exit. It needs to plan its path. How will it decide its moves? Check out 'Goal-Based Agent' in the Nexus, then run the simulation!", interactionType: 'AGENT_SIMULATION_2D', socraticPromptIds: ['SP_AA_Q5S1_GOAL_STRATEGY', 'SP_AA_Q5S2_PLAN_ADAPT'], keyTakeaway: "Goal-Based Agents use their objectives to guide their planning and decision-making, often looking ahead to determine the best sequence of actions.", xpAward: 180, icon: 'Map',
            simulationConfig: {
                gridSize: { rows: 10, cols: 10 },
                initialGridState: getDefaultGrid(10,10, {includeChargingStation: false, numItems: 3, includeExit: true}), // No charger, focus on items & exit
                initialAgentState: { 
                    x: 0, y: 0, direction: 'E', 
                    batteryLevel: 200, // More battery for a more complex task
                    lowBatteryThreshold: 10, // Less relevant here but good to have
                    goalDefinition: { itemsToCollectCount: 3, exitLocation: {x:9, y:9}} // Example values, adjust if grid/items change
                },
                agentRules: goalBasedRules,
                batteryConsumption: { move: 1, turn: 1, clean: 0, idle: 0, collect: 2 },
                // itemLocations and exitLocation are implicitly defined by initialGridState with numItems and includeExit options
            }
        }
    ]
  },
  // Phase AA4: Advanced Agent Design & Experimentation
  {
    id: "AA_Q8_AGENT_ASSEMBLY", phase: "Phase AA4: Advanced Agent Design & Experimentation", title: "The Automated Assembler", academy: 'agentAcademy',
    description: "Design an agent by assembling conceptual components (Sensors, Logic, Actuators) to solve a given task.",
    badge: { id: 'B_AA_Q8', name: "Agent Architect", icon: 'Construction', description: "Successfully designed a conceptual agent using components." }, totalXp: 200,
    steps: [
        { id: "AA_Q8S1_PACKAGE_SORTER", questId: "AA_Q8_AGENT_ASSEMBLY", title: "The Package Sorter Challenge", learningObjective: "Understand how different agent components (sensors, decision modules, actuators) work together by assembling them to solve a package sorting task.", noemaIntro: "Time to design an agent! Your task is to build a 'Package Sorter'. It needs to sense package color, decide where it goes, and then move it. Drag components from the palette to the blueprint slots. What components will you choose for sensing, decision-making, and acting? Once assembled, test your configuration!", interactionType: 'AGENT_ASSEMBLY', socraticPromptIds: ['SP_AA_Q8S1_INTRO', 'SP_AA_Q8S2_SENSOR_CHOICE', 'SP_AA_Q8S3_LOGIC_CHOICE', 'SP_AA_Q8S4_ACTUATOR_CHOICE', 'SP_AA_Q8S5_TEST_RESULT'], keyTakeaway: "Agents are composed of functional components: sensors gather information, decision modules process it, and actuators perform actions. Proper assembly is key to achieving goals.", xpAward: 200, icon: 'Blocks',
            agentAssemblyConfig: {
                taskDescription: "Design an AI agent to sort packages onto different conveyor belts based on their color (Red, Blue, Green).",
                environmentDescription: "A factory setting with packages arriving on an input conveyor. The agent is positioned at a sorting station.",
                agentSlots: [
                    { id: 'sensor_slot', label: 'Primary Sensor', acceptedType: 'SENSOR', icon: 'Eye', required: true },
                    { id: 'logic_slot', label: 'Decision Logic', acceptedType: 'DECISION_MODULE', icon: 'Brain', required: true },
                    { id: 'actuator_slot', label: 'Sorting Actuator', acceptedType: 'ACTUATOR', icon: 'Grab', required: true },
                ],
                availableComponents: [
                    { id: 'comp_color_sensor', name: 'Color Sensor X100', description: 'Detects Red, Blue, Green colors.', type: 'SENSOR', icon: 'ScanLine' },
                    { id: 'comp_weight_sensor', name: 'Weight Sensor FS-5', description: 'Measures package weight.', type: 'SENSOR', icon: 'Weight' },
                    { id: 'comp_basic_rules', name: 'Rule Engine v1', description: 'Executes IF-THEN rules for sorting.', type: 'DECISION_MODULE', icon: 'ListChecks' },
                    { id: 'comp_nn_classifier', name: 'Neural Network Classifier', description: 'Advanced pattern-based decision making.', type: 'DECISION_MODULE', icon: 'Network' },
                    { id: 'comp_robotic_arm', name: 'Robotic Sorting Arm', description: 'Picks and places packages.', type: 'ACTUATOR', icon: 'Armchair' }, // Using Armchair as placeholder
                    { id: 'comp_pusher_rod', name: 'Pneumatic Pusher Rod', description: 'Pushes packages onto belts.', type: 'ACTUATOR', icon: 'MoveHorizontal' },
                ],
                successCriteria: {
                    requiredComponentIds: [] // We'll use specific checks in the view for this step instead of generic IDs for better feedback
                }
            }
        }
    ]
  },
  {
    id: "AA_Q9_PARAMETER_TUNER", phase: "Phase AA4: Advanced Agent Design & Experimentation", title: "The Parameter Tuner", academy: 'agentAcademy',
    description: "Experiment by tweaking key parameters of a Model-Based Agent and observe the impact on its behavior and efficiency in a simulation.",
    badge: { id: 'B_AA_Q9', name: "Efficiency Expert", icon: 'SlidersHorizontal', description: "Optimized agent behavior by tuning parameters." }, totalXp: 180,
    steps: [
        { id: "AA_Q9S1_TUNING_CHALLENGE", questId: "AA_Q9_PARAMETER_TUNER", title: "The Efficiency Challenge", learningObjective: "Understand how agent parameters (e.g., battery consumption, recharge rate, low battery threshold) affect its performance and resource management.", noemaIntro: "Welcome, Agent Tuner! We have a Model-Based cleaning agent, but its settings might not be optimal. Your goal: adjust its parameters (like battery consumption for actions, or its low battery warning threshold) to help it clean all the dirt efficiently without running out of power. Experiment with the sliders and observe the outcomes!", interactionType: 'AGENT_SIMULATION_2D', socraticPromptIds: ['SP_AA_Q9S1_PARAM_IMPACT', 'SP_AA_Q9S2_OPTIMIZATION'], keyTakeaway: "Agent behavior can be significantly altered by tuning its internal parameters, leading to different trade-offs in efficiency, resource use, and task completion.", xpAward: 180, icon: 'Gauge',
            simulationConfig: {
                gridSize: { rows: 7, cols: 7 },
                initialGridState: getDefaultGrid(7,7, {includeChargingStation: true}),
                initialAgentState: { x: 0, y: 0, direction: 'E', batteryLevel: 100, lowBatteryThreshold: 30 },
                agentRules: modelBasedRules,
                batteryConsumption: { move: 2, turn: 1, clean: 3, idle: 0 },
                batteryRechargeRate: 20,
                tweakableParameters: [
                    { id: 'initialBatteryLevel', label: 'Initial Battery', defaultValue: 100, min: 50, max: 200, step: 10, description: "How much energy the agent starts with." },
                    { id: 'lowBatteryThreshold', label: 'Low Battery Threshold', defaultValue: 30, min: 10, max: 50, step: 5, description: "When the agent considers its battery low." },
                    { id: 'batteryConsumption_move', label: 'Move Cost', defaultValue: 2, min: 1, max: 5, step: 1, description: "Energy used per move." },
                    { id: 'batteryConsumption_turn', label: 'Turn Cost', defaultValue: 1, min: 0, max: 3, step: 1, description: "Energy used per turn." },
                    { id: 'batteryConsumption_clean', label: 'Clean Cost', defaultValue: 3, min: 1, max: 5, step: 1, description: "Energy used to clean one dirt spot." },
                    { id: 'batteryRechargeRate', label: 'Recharge Rate', defaultValue: 20, min: 5, max: 50, step: 5, description: "Energy gained per tick at charging station." },
                ]
            }
        }
    ]
  },
  // Phase AA5: Multi-Agent Systems & Orchestration -> Renamed based on user's new proposal
  {
    id: "AA_Q10_ORCHESTRATOR_INTRO", phase: "Phase AA5: Advanced Orchestrator Applications", title: "The Automated Scribe", academy: 'agentAcademy',
    description: "Learn to connect AI components to build a simple text processing workflow using the Agent Orchestrator.",
    badge: { id: 'B_AA_Q10', name: "Orchestrator Initiate", icon: 'Workflow', description: "Built a basic AI component workflow." }, totalXp: 250,
    steps: [
      { id: "AA_Q10S1_BLUEPRINT_BASICS", questId: "AA_Q10_ORCHESTRATOR_INTRO", title: "Blueprint Basics", learningObjective: "Understand the Agent Orchestrator interface and how to connect basic components.", noemaIntro: "Welcome, Architect! Here, you'll assemble AI workflows. Drag components from the palette, connect their nodes by clicking an output then an input, and run your creation. Let's start simple. Your task: build a workflow that takes user input from a 'User Text Input (Quest)' component and displays it using a 'Display Text Output' component.", interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q10S1_INTRO', 'SP_AA_Q10S1_SUCCESS'],
        orchestratorConfig: {
            taskDescription: "Workflow: 'User Text Input' (provides text) -> 'Display Text Output' (shows text). Connect output from Input to input of Display.",
            availableComponentDefs: ["user_text_input_v1", "display_text_output_v1"],
            initialWorkflow: { instances: [], connections: [] },
            successCriteria: {
                requiredComponents: ["user_text_input_v1", "display_text_output_v1"],
                requiredConnections: [{ from: "user_text_input_v1.out_text", to: "display_text_output_v1.in_text_display" }]
            }
        },
        keyTakeaway: "The Agent Orchestrator allows visual assembly of AI components to create functional workflows. Components are connected via input/output nodes.", xpAward: 80, icon: 'DraftingCompass'
      },
      { id: "AA_Q10S2_LLM_LINKUP", questId: "AA_Q10_ORCHESTRATOR_INTRO", title: "The LLM Link-Up", learningObjective: "Integrate an LLM component for text transformation into a workflow.", noemaIntro: "Now, let's add some intelligence. Modify your workflow to insert an 'LLM Text Rephraser' component between the user input and the display output. The goal is to rephrase the user's text before displaying it. How will you connect the components?", interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q10S2_CONNECT_LLM'],
        orchestratorConfig: {
            taskDescription: "Workflow: 'User Text Input' -> 'LLM Text Rephraser' -> 'Display Text Output'. Connect Input to Rephraser, then Rephraser to Display.",
            availableComponentDefs: ["user_text_input_v1", "llm_text_rephraser_v1", "display_text_output_v1"],
            initialWorkflow: { 
                instances: [
                    { id: 'input_1', componentDefId: 'user_text_input_v1', position: {x:50, y:50}, configValues: {default_text: "Hello, world!"}, customName: 'User Text Input 1', isCollapsed:false },
                    { id: 'display_1', componentDefId: 'display_text_output_v1', position: {x:450, y:50}, configValues: {}, customName: 'Display Text Output 1', isCollapsed:false },
                ],
                connections: [
                    // {id: 'conn_init', fromInstanceId: 'input_1', fromNodeId: 'out_text', toInstanceId: 'display_1', toNodeId: 'in_text_display'}
                ] // Removing initial connection to force user to add LLM
            },
            successCriteria: {
                requiredComponents: ["user_text_input_v1", "llm_text_rephraser_v1", "display_text_output_v1"],
                requiredConnections: [
                    { from: "user_text_input_v1.out_text", to: "llm_text_rephraser_v1.in_text" },
                    { from: "llm_text_rephraser_v1.out_rephrased_text", to: "display_text_output_v1.in_text_display" }
                ]
            }
        },
        keyTakeaway: "LLM components can be integrated into workflows to process and transform data, like rephrasing text.", xpAward: 90, icon: 'Link'
      },
      { id: "AA_Q10S3_PARAMETER_POWER", questId: "AA_Q10_ORCHESTRATOR_INTRO", title: "Parameter Power", learningObjective: "Experiment with LLM component configuration parameters and observe their effect.", noemaIntro: "The 'LLM Text Rephraser' has settings. Click its configuration icon (the gear). Try changing its 'Rephrase Style' (e.g., 'like a pirate', 'formal', 'very concise') or its 'Creativity (Temp)' value. Run the workflow after each change. How does the output change? What do these parameters control?", interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q10S3_INTRO', 'SP_AA_Q10S3_OBSERVE_EFFECT'],
        orchestratorConfig: {
            taskDescription: "Experiment with 'LLM Text Rephraser' parameters (Rephrase Style, Temperature). Observe how output changes.",
            availableComponentDefs: ["user_text_input_v1", "llm_text_rephraser_v1", "display_text_output_v1"],
            initialWorkflow: { 
                instances: [
                    { id: 'input_start', componentDefId: 'user_text_input_v1', position: {x:50, y:100}, configValues: {default_text: "Noema's Guidance is a fun way to learn AI!"}, customName: 'User Text Input 1', isCollapsed:false },
                    { id: 'llm_rephrase', componentDefId: 'llm_text_rephraser_v1', position: {x:300, y:100}, configValues: {rephrase_style: 'formal', temperature: 0.7}, customName: 'LLM Text Rephraser 1', isCollapsed:false },
                    { id: 'display_final', componentDefId: 'display_text_output_v1', position: {x:550, y:100}, configValues: {}, customName: 'Display Text Output 1', isCollapsed:false },
                ],
                connections: [
                    {id: 'c1', fromInstanceId: 'input_start', fromNodeId: 'out_text', toInstanceId: 'llm_rephrase', toNodeId: 'in_text'},
                    {id: 'c2', fromInstanceId: 'llm_rephrase', fromNodeId: 'out_rephrased_text', toInstanceId: 'display_final', toNodeId: 'in_text_display'}
                ]
            },
        },
        keyTakeaway: "AI components often have configurable parameters (like temperature or style prompts) that allow users to fine-tune their behavior and output.", xpAward: 80, icon: 'SlidersHorizontal'
      },
    ]
  },
  {
    id: "AA_Q11_ART_CRITIC", phase: "Phase AA5: Advanced Orchestrator Applications", title: "The Automated Art Critic", academy: 'agentAcademy',
    description: "Build an AI workflow that analyzes an image, generates a critique, structures it, and displays the results.",
    badge: { id: 'B_AA_Q11', name: "AI Art Analyst", icon: 'Palette', description: "Constructed a multi-modal AI analysis workflow." }, totalXp: 300,
    steps: [
      { id: "AA_Q11S1_INPUTS", questId: "AA_Q11_ART_CRITIC", title: "Setting the Stage: Image and Intent", learningObjective: "Set up inputs for an image and a textual analysis instruction.", noemaIntro: "Let's build an 'Automated Art Critic'! First, we need an image to critique and a way to specify our critique style. Add an 'Image Input (Quest)' component and a 'User Text Input (Quest)' component to the canvas. Configure the Image Input with an image URL or Base64 data (you can search for a famous painting online and use its URL, or paste Base64). For the Text Input, set its default text to something like 'Describe the emotional tone and key visual elements of this artwork.'", 
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q11S1_INPUTS'],
        orchestratorConfig: {
            taskDescription: "Overall Goal: Image + Instructions -> LLM Image Analyzer -> LLM Text to JSON -> Display Outputs. This Step: Set up 'Image Input' and 'User Text Input'.",
            availableComponentDefs: ["image_input_v1", "user_text_input_v1", "llm_image_analyzer_v1", "string_manipulator_v1", "transform_text_to_json_v1", "display_text_output_v1"],
            initialWorkflow: { instances: [], connections: [] },
            successCriteria: { requiredComponents: ["image_input_v1", "user_text_input_v1"] }
        },
        keyTakeaway: "Multi-modal AI workflows often start by defining distinct input sources for different data types like images and text.", xpAward: 70, icon: 'ImageUp'
      },
      { id: "AA_Q11S2_VISION_ANALYSIS", questId: "AA_Q11_ART_CRITIC", title: "The AI's Eye: Image Analysis", learningObjective: "Use an LLM Image Analyzer to generate a textual critique of the image based on the instruction.", noemaIntro: "Now, let's get the AI's perspective. Add an 'LLM Image Analyzer' component. Connect the output from your 'Image Input' to the 'Image (Base64/DataURL)' input of the analyzer. Connect the output from your 'User Text Input' (your critique instruction) to the 'Analysis Prompt' input of the analyzer. What do you expect this component to output?", interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q11S2_VISION_CONNECT'],
        orchestratorConfig: {
            taskDescription: "Connect 'Image Input' & 'User Text Input' to 'LLM Image Analyzer'. Goal: Generate textual critique.",
            availableComponentDefs: ["image_input_v1", "user_text_input_v1", "llm_image_analyzer_v1", "string_manipulator_v1", "transform_text_to_json_v1", "display_text_output_v1"],
            successCriteria: {
                requiredComponents: ["image_input_v1", "user_text_input_v1", "llm_image_analyzer_v1"],
                requiredConnections: [
                    { from: "image_input_v1.out_image_ref", to: "llm_image_analyzer_v1.in_image_ref" },
                    { from: "user_text_input_v1.out_text", to: "llm_image_analyzer_v1.in_text_prompt" }
                ]
            }
        },
        keyTakeaway: "LLM Image Analyzers combine visual understanding with text prompting to generate contextual descriptions or analyses of images.", xpAward: 80, icon: 'ScanSearch'
      },
      { id: "AA_Q11S3_STRUCTURE_CRITIQUE", questId: "AA_Q11_ART_CRITIC", title: "Structuring the Critique: Text to JSON", learningObjective: "Use an LLM Text to JSON component to convert the free-form text critique into a structured JSON object.", noemaIntro: "The AI's analysis is good, but it's unstructured text. Let's organize it. Add a 'LLM Text to JSON' component. Connect the 'Image Analysis Text' output from the analyzer to the 'Input Text' of the JSON transformer. For the 'Default Schema Description' in the JSON transformer's configuration, use something like: `{\"title\": \"string (artwork title, if identifiable)\", \"description\": \"string (overall critique)\", \"key_elements\": [\"string\"], \"emotional_tone\": \"string\"}`. This tells the AI how to structure the JSON.", interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q11S3_STRUCTURE_JSON'],
        orchestratorConfig: {
            taskDescription: "Feed critique from 'LLM Image Analyzer' to 'LLM Text to JSON'. Goal: Output structured JSON.",
            availableComponentDefs: ["image_input_v1", "user_text_input_v1", "llm_image_analyzer_v1", "string_manipulator_v1", "transform_text_to_json_v1", "display_text_output_v1"],
            successCriteria: {
                requiredComponents: ["llm_image_analyzer_v1", "transform_text_to_json_v1"],
                requiredConnections: [
                    { from: "llm_image_analyzer_v1.out_analysis_text", to: "transform_text_to_json_v1.in_text_to_transform" }
                ]
            }
        },
        keyTakeaway: "LLMs can be used to transform unstructured text into structured data formats like JSON by providing a schema description.", xpAward: 80, icon: 'FileJson'
      },
      { id: "AA_Q11S4_DISPLAY_RESULTS", questId: "AA_Q11_ART_CRITIC", title: "Final Showcase: Displaying the Structured Critique", learningObjective: "Use Display Text Output components to show both the original raw analysis and the structured JSON output.", noemaIntro: "Excellent! Now, let's display our results. Add two 'Display Text Output' components. Connect one to the 'Image Analysis Text' output of the 'LLM Image Analyzer' (to see the raw critique). Connect the other to the 'JSON Object' output of the 'LLM Text to JSON' transformer (to see the structured critique). Run your workflow and examine the outputs!", interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q11S4_FORMAT_DISPLAY'],
        orchestratorConfig: {
            taskDescription: "Use two 'Display Text Output' components: one for raw analysis text, one for structured JSON output.",
            availableComponentDefs: ["llm_image_analyzer_v1", "transform_text_to_json_v1", "display_text_output_v1"],
            successCriteria: {
                requiredComponents: ["llm_image_analyzer_v1", "transform_text_to_json_v1", "display_text_output_v1"], 
                 // Check for presence of at least two display components, with connections from appropriate sources.
                 // Specific connection check is complex here if user can name instances; relying on Socratic prompts/manual review if strict.
            }
        },
        keyTakeaway: "Orchestrated workflows allow complex data processing pipelines, transforming data through multiple AI and logic steps to produce structured and presentable final outputs.", xpAward: 70, icon: 'Presentation'
      },
    ]
  },
  // --- New Quests based on user's proposal ---
  {
    id: "AA_Q13_NEWS_AGGREGATOR", phase: "Phase AA5: Advanced Orchestrator Applications", title: "The Smart News Aggregator", academy: 'agentAcademy',
    description: "Build an orchestrator workflow to fetch, summarize, and classify news articles.",
    badge: { id: 'B_AA_Q13', name: "News Analyst", icon: 'Newspaper', description: "Designed an AI news aggregation and classification pipeline." }, totalXp: 350,
    steps: [
      { id: "AA_Q13S1_FETCH_NEWS", questId: "AA_Q13_NEWS_AGGREGATOR", title: "Fetch the Headlines", learningObjective: "Use user input for a topic and the Web Search tool to find news articles.", 
        noemaIntro: "Your mission, should you choose to accept it, is to build a Smart News Aggregator! First, let's get the news. Add a 'User Text Input' for the news topic. Then, connect it to a 'Web Search Augmenter' to find relevant articles.", 
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q13S1_FETCH_SETUP'],
        orchestratorConfig: {
            taskDescription: "Overall Workflow: Input Topic (User Text) -> Web Search (Live) -> Parse Results (JSON Parser) -> For each article snippet: Summarize (LLM) -> Classify Sentiment (LLM with system prompt) -> Combine & Display (Data Mapper, Display Text). You might need multiple LLM Generate/Summarize blocks for different parts. This Step: Implement 'User Text Input (Topic)' -> 'Web Search Augmenter'.",
            availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "json_parser_sandbox_v1", "llm_text_summarizer_v1", "llm_text_classifier_v1", "display_text_output_v1", "logic_merge_texts_v1"], // Removed "data_mapper_transformer" as it's not defined
            successCriteria: { requiredComponents: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1"], requiredConnections: [{from: "user_text_input_sandbox_v1.text_out", to: "tool_web_search_augmenter_v1.in_query"}]}
        },
        keyTakeaway: "Web Search tools can fetch real-time information for AI workflows.", xpAward: 80, icon: 'Search' 
      },
      { id: "AA_Q13S2_PARSE_RESULTS", questId: "AA_Q13_NEWS_AGGREGATOR", title: "Extract Article Details", learningObjective: "Use a JSON Parser to extract titles and snippets from search results.", 
        noemaIntro: "The search tool returns a lot of data. We need to extract specific details. Add a 'JSON Parser'. Connect the 'Source URLs (JSON)' output from Web Search to it. Configure the parser to extract article titles and snippets (you might need to inspect the output format from Web Search; typically it's an array, so path might be e.g., '[0].title' or 'web.title' if it's not an array). You may need multiple parsers or a data mapper for multiple articles.",
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q13S2_PARSE_LOGIC'],
        orchestratorConfig: {
            taskDescription: "Connect 'Web Search Augmenter' (Source URLs output) -> 'JSON Parser'. Configure parser to extract article titles/snippets. Tip: Inspect the search output format; often an array of objects. Path for first title might be '[0].title' or '[0].web.title'.",
            availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "json_parser_sandbox_v1", "llm_text_summarizer_v1", "llm_text_classifier_v1", "display_text_output_v1", "logic_merge_texts_v1"],
            successCriteria: { requiredComponents: ["tool_web_search_augmenter_v1", "json_parser_sandbox_v1"], requiredConnections: [{from: "tool_web_search_augmenter_v1.out_source_urls", to: "json_parser_sandbox_v1.json_string_in"}]}
        },
        keyTakeaway: "JSON Parsers are essential for extracting structured information from complex AI outputs.", xpAward: 90, icon: 'FileJson' 
      },
      { id: "AA_Q13S3_SUMMARIZE_CLASSIFY", questId: "AA_Q13_NEWS_AGGREGATOR", title: "Summarize & Classify", learningObjective: "Summarize extracted article content and classify its sentiment or topic.", 
        noemaIntro: "Now for the core processing. For an article snippet (from your parser), add an 'LLM Text Summarizer'. Then, take the summary and feed it into an 'LLM Text Classifier'. Configure the classifier with categories like 'Positive', 'Negative', 'Neutral' or by topic like 'Technology', 'Politics', 'Science'.",
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q13S3_SUM_CLASS_IMPL'],
        orchestratorConfig: {
            taskDescription: "Workflow: Parsed Snippet (Text) -> 'LLM Text Summarizer' -> 'LLM Text Classifier'. Configure classifier categories (e.g., Positive, Negative, Neutral).",
            availableComponentDefs: ["json_parser_sandbox_v1", "llm_text_summarizer_v1", "llm_text_classifier_v1", "display_text_output_v1", "logic_merge_texts_v1"], // Assuming parser output is text
            successCriteria: { 
                requiredComponents: ["llm_text_summarizer_v1", "llm_text_classifier_v1"], 
                requiredConnections: [
                    // Example connection, actual node IDs from parser will vary
                    {from: "json_parser_sandbox_v1.parsed_value_out", to: "llm_text_summarizer_v1.in_text_to_summarize"}, 
                    {from: "llm_text_summarizer_v1.out_summary", to: "llm_text_classifier_v1.in_text"}
                ]
            }
        },
        keyTakeaway: "Chaining LLM components allows for sophisticated multi-step text processing like summarization followed by classification.", xpAward: 100, icon: 'BrainCircuit' 
      },
      { id: "AA_Q13S4_DISPLAY_AGGREGATION", questId: "AA_Q13_NEWS_AGGREGATOR", title: "Display Aggregated News", learningObjective: "Combine and display the processed news items.", 
        noemaIntro: "Finally, use 'Display Text Output' components to show the original article title (from parser), its summary, and its classification. You might need a 'Merge Texts' or 'Data Mapper / Transformer' component if you want to combine these details neatly for display.",
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q13S4_DISPLAY_SETUP'],
        orchestratorConfig: {
            taskDescription: "Use 'Merge Texts' or 'Data Mapper / Transformer' -> 'Display Text Output' to show combined title, summary, and classification. (Goal: Display at least one combined news item).",
            availableComponentDefs: ["json_parser_sandbox_v1", "llm_text_classifier_v1", "display_text_output_v1", "logic_merge_texts_v1"], // Removed "data_mapper_transformer"
            successCriteria: { requiredComponents: ["display_text_output_v1"] } // Flexible on specific connections to display
        },
        keyTakeaway: "Orchestrated workflows can produce rich, aggregated outputs from various processing stages.", xpAward: 80, icon: 'Presentation' 
      },
    ]
  },
  {
    id: "AA_Q14_FACT_CHECKER", phase: "Phase AA5: Advanced Orchestrator Applications", title: "The Automated Fact-Checker", academy: 'agentAcademy',
    description: "Design a workflow to take a user's claim, search for information, and provide a tentative fact-checking assessment.",
    badge: { id: 'B_AA_Q14', name: "Truth Seeker", icon: 'ShieldCheck', description: "Built a conceptual AI fact-checking pipeline." }, totalXp: 380,
    steps: [
        { id: "AA_Q14S1_INPUT_CLAIM", questId: "AA_Q14_FACT_CHECKER", title: "Input the Claim", learningObjective: "Set up user input for the claim to be fact-checked.",
            noemaIntro: "Your next challenge is to design an Automated Fact-Checking Assistant. Start by adding a 'User Text Input' component for the user to enter a statement or claim.",
            interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q14S1_CLAIM_INPUT'],
            orchestratorConfig: {
                taskDescription: "Overall Workflow: User Input (Claim) -> Web Search -> JSON Parser (Source analysis) -> LLM Summarizer (Critical) -> Conditional Router (Verdict) -> Display Verdict. This step: Set up 'User Text Input' for the claim.",
                availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "json_parser_sandbox_v1", "llm_text_summarizer_v1", "conditional_router_sandbox_v1", "display_text_output_v1", "logic_merge_texts_v1"],
                successCriteria: { requiredComponents: ["user_text_input_sandbox_v1"] }
            },
            keyTakeaway: "Clearly defining the input is the first step in any analytical workflow.", xpAward: 70, icon: 'Quote'
        },
        { id: "AA_Q14S2_SEARCH_EVIDENCE", questId: "AA_Q14_FACT_CHECKER", title: "Search for Evidence", learningObjective: "Use Web Search to find information related to the claim.",
            noemaIntro: "Connect the claim to a 'Web Search Augmenter' to find supporting or refuting information online.",
            interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q14S2_SEARCH_SETUP'],
            orchestratorConfig: {
                taskDescription: "Workflow part: User Input (Claim) -> 'Web Search Augmenter'. Goal: Find evidence related to the claim.",
                 availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "json_parser_sandbox_v1", "llm_text_summarizer_v1", "conditional_router_sandbox_v1", "display_text_output_v1", "logic_merge_texts_v1"],
                successCriteria: { requiredConnections: [{from: "user_text_input_sandbox_v1.text_out", to: "tool_web_search_augmenter_v1.in_query"}] }
            },
            keyTakeaway: "Accessing external information is crucial for fact-checking agents.", xpAward: 80, icon: 'SearchCode'
        },
        { id: "AA_Q14S3_ANALYZE_SOURCES", questId: "AA_Q14_FACT_CHECKER", title: "Analyze Sources (Conceptual)", learningObjective: "Conceptually use JSON Parser to assess source reliability.",
            noemaIntro: "Reliability is key. Use a 'JSON Parser' on the search results. Imagine you're checking if source domains are reputable (e.g., news sites vs blogs). For this step, just parse *some* data from the sources (like titles or domains).",
            interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q14S3_SOURCE_ANALYSIS'],
             orchestratorConfig: {
                taskDescription: "Workflow part: Web Search Results (Source URLs output) -> 'JSON Parser'. Goal: Extract source information like titles or domains.",
                 availableComponentDefs: ["tool_web_search_augmenter_v1", "json_parser_sandbox_v1", "llm_text_summarizer_v1", "conditional_router_sandbox_v1", "display_text_output_v1", "logic_merge_texts_v1"],
                successCriteria: { requiredConnections: [{from: "tool_web_search_augmenter_v1.out_source_urls", to: "json_parser_sandbox_v1.json_string_in"}] }
            },
            keyTakeaway: "Assessing source credibility, even conceptually, is vital in fact-checking.", xpAward: 80, icon: 'ListFilter'
        },
        { id: "AA_Q14S4_SYNTHESIZE_ASSESS", questId: "AA_Q14_FACT_CHECKER", title: "Synthesize & Assess", learningObjective: "Use an LLM to summarize evidence and a Conditional Router for a tentative assessment.",
            noemaIntro: "Take the augmented answer from Web Search (or key parsed info) and feed it to an 'LLM Text Summarizer'. Configure its system prompt to be critical and look for corroborating evidence. Then, use a 'Conditional Router' based on keywords in the summary (e.g., 'confirmed', 'disputed', 'unclear') to route to different assessment paths.",
            interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q14S4_ASSESSMENT_LOGIC'],
             orchestratorConfig: {
                taskDescription: "Workflow part: Web Search Answer -> 'LLM Text Summarizer' (critically summarize) -> 'Conditional Router' (assess based on keywords like 'confirmed', 'disputed'). Goal: Form tentative assessment.",
                 availableComponentDefs: ["tool_web_search_augmenter_v1", "llm_text_summarizer_v1", "conditional_router_sandbox_v1", "display_text_output_v1", "logic_merge_texts_v1"],
                successCriteria: { 
                    requiredConnections: [
                        {from: "tool_web_search_augmenter_v1.out_augmented_answer", to: "llm_text_summarizer_v1.in_text_to_summarize"},
                        {from: "llm_text_summarizer_v1.out_summary", to: "conditional_router_sandbox_v1.data_in"}
                        // Also expect connection from summary to condition_value_a_in or config on router
                    ] 
                }
            },
            keyTakeaway: "Summarization and conditional logic help in forming a structured assessment.", xpAward: 90, icon: 'GitCompareArrows'
        },
         { id: "AA_Q14S5_DISPLAY_VERDICT", questId: "AA_Q14_FACT_CHECKER", title: "Display Verdict", learningObjective: "Display the claim, a summary of findings, and a tentative verdict.",
            noemaIntro: "Finally, use 'Display Text Output' components for each branch of your router (Likely True, Likely False, Needs More Info). Display the original claim, summarized evidence, and the system's tentative verdict.",
            interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q14S5_VERDICT_DISPLAY'],
             orchestratorConfig: {
                taskDescription: "Connect router outputs (from 'Likely True', 'Likely False' etc. branches) & original claim/summary to 'Display Text Output' components (possibly via 'Merge Texts'). Goal: Present final verdict and reasoning.",
                 availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "llm_text_summarizer_v1", "conditional_router_sandbox_v1", "display_text_output_v1", "logic_merge_texts_v1"],
                successCriteria: { 
                    requiredComponents: ["display_text_output_v1", "conditional_router_sandbox_v1"],
                 }
            },
            keyTakeaway: "Presenting fact-checking results clearly is crucial for user understanding.", xpAward: 60, icon: 'Megaphone'
        },
    ]
  },
  {
    id: "AA_Q15_FORAGER_MODULE", phase: "Phase AA5: Advanced Orchestrator Applications", title: "The Forager's Mind (Conceptual)", academy: 'agentAcademy',
    description: "Design the decision module for a single conceptual 'forager' agent using the orchestrator.",
    badge: { id: 'B_AA_Q15', name: "Swarm Architect (Seed)", icon: 'Component', description: "Designed a conceptual module for emergent behavior." }, totalXp: 250,
    steps: [
      { id: "AA_Q15S1_SENSE_INPUTS", questId: "AA_Q15_FORAGER_MODULE", title: "Forager Senses", learningObjective: "Define inputs representing a forager agent's simple senses.", 
        noemaIntro: "Let's design the 'brain' of a single forager agent. If this agent were part of a swarm, what simple things would it need to sense? Create 'User Text Input (Sandbox)' components for 'Sense Food Nearby (Boolean)' and 'Sense Obstacle Ahead (Boolean)'. Configure them with initial values (e.g., 'true' or 'false').", 
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q15S1_SETUP_SENSES'],
        orchestratorConfig: {
            taskDescription: "Overall Workflow: Text Inputs (Senses like 'Food Nearby?', 'Obstacle Ahead?') -> Conditional Logic (Decision: Move to food, Turn, Move forward) -> Display Text (Action). This step: Set up 'User Text Input' components for 'Sense Food Nearby' (Boolean) and 'Sense Obstacle Ahead' (Boolean).",
            availableComponentDefs: ["user_text_input_sandbox_v1", "conditional_router_sandbox_v1", "llm_generate_text_sandbox_v1", "display_text_output_v1"],
            successCriteria: { requiredComponents: ["user_text_input_sandbox_v1"] } // Needs at least two such inputs
        },
        keyTakeaway: "Simple agents in a swarm typically rely on very basic sensory inputs.", xpAward: 80, icon: 'Radar' 
      },
      { id: "AA_Q15S2_DECISION_LOGIC", questId: "AA_Q15_FORAGER_MODULE", title: "Forager Decision Logic", learningObjective: "Use orchestrator components to define simple decision rules for the forager.", 
        noemaIntro: "Now, create the logic. If 'Sense Food Nearby' is true, the agent should decide to 'MOVE_TOWARDS_FOOD'. If 'Sense Obstacle Ahead' is true (and no food), it should 'TURN_RANDOM'. Otherwise, it should 'MOVE_FORWARD'. Use 'Conditional Routers' and/or 'LLM Generate Text' (with a simple system prompt to output these actions) to implement this logic.", 
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q15S2_BUILD_LOGIC'],
        orchestratorConfig: {
            taskDescription: "Workflow part: Text Inputs (Senses) -> 'Conditional Router' or 'LLM Generate Text' (Decision Logic). Goal: Implement IF Food THEN 'MOVE_TOWARDS_FOOD', ELSE IF Obstacle THEN 'TURN_RANDOM', ELSE 'MOVE_FORWARD'.",
            availableComponentDefs: ["user_text_input_sandbox_v1", "conditional_router_sandbox_v1", "llm_generate_text_sandbox_v1", "display_text_output_v1"],
            successCriteria: { requiredComponents: ["conditional_router_sandbox_v1"] } // Or LLM depending on user's choice
        },
        keyTakeaway: "Simple rules, often conditional, govern the behavior of individual agents in a collective.", xpAward: 100, icon: 'GitFork' 
      },
      { id: "AA_Q15S3_ACTION_OUTPUT", questId: "AA_Q15_FORAGER_MODULE", title: "Forager Action Output", learningObjective: "Display the forager's chosen action.", 
        noemaIntro: "Finally, connect the output of your decision logic to a 'Display Text Output' component to show the agent's chosen action (e.g., 'MOVE_TOWARDS_FOOD'). Run the workflow with different input sensor values to test its logic.", 
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q15S3_TEST_ACTION', 'SP_AA_Q15S4_EMERGENCE_DISCUSSION'], // Added new Socratic prompt
        orchestratorConfig: {
            taskDescription: "Workflow part: Decision Logic Output -> 'Display Text Output'. Goal: Show agent's chosen action ('MOVE_TOWARDS_FOOD', 'TURN_RANDOM', 'MOVE_FORWARD').",
            availableComponentDefs: ["user_text_input_sandbox_v1", "conditional_router_sandbox_v1", "llm_generate_text_sandbox_v1", "display_text_output_v1"],
            successCriteria: { 
                requiredComponents: ["display_text_output_v1"],
                successMessage: "Workflow execution completed successfully." // To ensure it runs
            }
        },
        keyTakeaway: "The output of a single agent's decision module represents its intended action in the environment.", xpAward: 70, icon: 'BotMessageSquare' 
      },
    ]
  },
  // Phase AA6: Emergent Behavior & Swarm Intelligence
  {
    id: "AA_Q16_SWARM_PRINCIPLES", phase: "Phase AA6: Emergent Behavior & Swarm Intelligence", title: "The Principles of the Swarm", academy: 'agentAcademy',
    description: "Explore the fundamental concepts of swarm intelligence and emergent behavior through Socratic dialogue.",
    badge: { id: 'B_AA_Q16', name: "Swarm Theorist", icon: 'Users', description: "Understood core principles of swarm intelligence." }, totalXp: 200,
    steps: [
      { id: "AA_Q16S1_EMERGENCE", questId: "AA_Q16_SWARM_PRINCIPLES", title: "What is Emergent Behavior?", learningObjective: "Define emergent behavior and understand how complex patterns arise from simple interactions.", 
        noemaIntro: "You've designed a single forager. Now, imagine thousands acting together. Complex global patterns can 'emerge' from their simple local rules. This is 'Emergent Behavior'. What does this concept mean to you? Then, let's explore 'Emergent Behavior' and 'Swarm Intelligence' in the Nexus.",
        interactionType: 'AI_CHAT', socraticPromptIds: ['SP_AA_Q16S1_DEFINE_EMERGENCE'],
        keyTakeaway: "Emergent behavior is when complex, system-wide patterns arise from the collective actions of many simple components, without explicit central control.", xpAward: 70, icon: 'Network'
      },
      { id: "AA_Q16S2_SWARM_EXAMPLES", questId: "AA_Q16_SWARM_PRINCIPLES", title: "Nature's Swarms", learningObjective: "Analyze examples of swarm intelligence in nature (e.g., ant colonies, bird flocks).", 
        noemaIntro: "Nature is full of swarm intelligence. Ants form complex trails to food, birds flock in intricate patterns. What simple rules might individual ants or birds be following that lead to these sophisticated collective behaviors? Let's discuss.",
        interactionType: 'AI_CHAT', socraticPromptIds: ['SP_AA_Q16S2_NATURE_EXAMPLES'],
        keyTakeaway: "Many natural systems demonstrate swarm intelligence, where simple individual rules lead to complex, adaptive group behavior.", xpAward: 70, icon: 'Bird'
      },
      { id: "AA_Q16S3_AI_SWARMS", questId: "AA_Q16_SWARM_PRINCIPLES", title: "AI Swarms & Applications", learningObjective: "Discuss potential applications and challenges of AI-based swarm systems.", 
        noemaIntro: "How could we apply these principles to AI? Imagine swarms of small robots for search and rescue, or for environmental monitoring. What are the advantages of such a decentralized system? What are the challenges in designing and controlling them?",
        interactionType: 'AI_CHAT', socraticPromptIds: ['SP_AA_Q16S3_AI_APPLICATIONS'],
        keyTakeaway: "AI swarms offer potential for robustness, scalability, and adaptability in complex tasks, but also present design challenges in rule definition and control.", xpAward: 60, icon: 'BotIcon' // Using BotIcon as generic Bot from lucide-react
      },
    ]
  },
  // New Quest "The RAG Reporter"
  {
    id: "AA_Q17_RAG_REPORTER", phase: "Phase AA5: Advanced Orchestrator Applications", title: "The RAG Reporter", academy: 'agentAcademy',
    description: "Build a Retrieval Augmented Generation (RAG) pipeline to answer questions based on live web search results.",
    badge: { id: 'B_AA_Q17', name: "RAG Specialist", icon: 'FileSearch2', description: "Constructed a functional RAG workflow." }, totalXp: 300,
    steps: [
      { id: "AA_Q17S1_INPUT_QUERY", questId: "AA_Q17_RAG_REPORTER", title: "Query Input", learningObjective: "Set up user input for the research query.", 
        noemaIntro: "Let's build a 'RAG Reporter' that uses live web info! First, add a 'User Text Input (Sandbox)' for the user to enter their research question or topic.", 
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q17S1_QUERY_SETUP'],
        orchestratorConfig: {
            taskDescription: "Workflow: User Query -> Web Search -> Summarize/Answer with LLM -> Display. This step: Setup 'User Text Input (Sandbox)'.",
            availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "llm_text_summarizer_v1", "llm_generate_text_sandbox_v1", "display_text_output_v1"],
            successCriteria: { requiredComponents: ["user_text_input_sandbox_v1"] }
        },
        keyTakeaway: "RAG systems start with a user query to guide information retrieval.", xpAward: 70, icon: 'HelpCircle' 
      },
      { id: "AA_Q17S2_WEB_RETRIEVAL", questId: "AA_Q17_RAG_REPORTER", title: "Web Information Retrieval", learningObjective: "Use the Web Search Augmenter to fetch relevant information for the query.", 
        noemaIntro: "Connect your query input to a 'Web Search Augmenter'. This component will search the web and provide text relevant to the query.", 
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q17S2_SEARCH_CONNECT'],
        orchestratorConfig: {
            taskDescription: "Connect 'User Text Input' to 'Web Search Augmenter'.",
            availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "llm_text_summarizer_v1", "llm_generate_text_sandbox_v1", "display_text_output_v1"],
            successCriteria: { 
                requiredComponents: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1"],
                requiredConnections: [{from: "user_text_input_sandbox_v1.text_out", to: "tool_web_search_augmenter_v1.in_query"}]
            }
        },
        keyTakeaway: "The 'Retrieval' part of RAG involves fetching up-to-date information from external sources.", xpAward: 80, icon: 'SearchCode' 
      },
      { id: "AA_Q17S3_LLM_AUGMENTATION", 
        questId: "AA_Q17_RAG_REPORTER", 
        title: "LLM Augmentation & Synthesis", 
        learningObjective: "Use an LLM to synthesize an answer based on the user's query and the retrieved web content.", 
        noemaIntro: "Now for the 'Augmented Generation'. Connect the 'Augmented Answer' output from the Web Search Augmenter to an 'LLM Generate Text' (or 'LLM Text Summarizer'). Your prompt for this LLM should instruct it to use the provided web context to answer the original user query (which you might need to feed in again or reference).",
        interactionType: 'AGENT_ORCHESTRATOR', 
        socraticPromptIds: ['SP_AA_Q17S3_LLM_AUGMENTATION'], 
        icon: 'BrainCircuit', 
        xpAward: 100, 
        keyTakeaway: "LLMs in RAG systems synthesize answers by combining the user's query with retrieved information, providing more grounded and current responses.", 
        orchestratorConfig: {
            taskDescription: "Connect 'Web Search Augmenter' (Augmented Answer output) to an 'LLM Generate Text'. You'll need to craft a good prompt in the LLM's config. For example, its config could take the *original query* from User Input and the *search result text* as inputs to its prompt. A simpler start: just summarize the search result.",
            availableComponentDefs: ["user_text_input_sandbox_v1", "tool_web_search_augmenter_v1", "llm_text_summarizer_v1", "llm_generate_text_sandbox_v1", "display_text_output_v1", "logic_merge_texts_v1"],
            successCriteria: { 
                requiredComponents: ["tool_web_search_augmenter_v1", "llm_generate_text_sandbox_v1"], 
            }
        }
      },
      { id: "AA_Q17S4_DISPLAY_RAG_RESULT", questId: "AA_Q17_RAG_REPORTER", title: "Display RAG Output", learningObjective: "Display the final RAG-generated answer.", 
        noemaIntro: "Finally, connect the output of your synthesizing LLM component to a 'Display Text Output' to see the RAG Reporter's answer. Run the workflow with a research question!",
        interactionType: 'AGENT_ORCHESTRATOR', socraticPromptIds: ['SP_AA_Q17S4_FINAL_OUTPUT'],
        orchestratorConfig: {
            taskDescription: "Connect the synthesizing LLM's output to a 'Display Text Output'.",
            availableComponentDefs: ["llm_generate_text_sandbox_v1", "llm_text_summarizer_v1", "display_text_output_v1"],
            successCriteria: { 
                requiredComponents: ["display_text_output_v1"],
            }
        },
        keyTakeaway: "RAG workflows provide a powerful way to create AI systems that can answer questions based on current information.", xpAward: 50, icon: 'Presentation' 
      },
    ]
  },
];

export const ALL_QUESTS: Quest[] = [...MainQuestLine, ...AgentAcademyQuestLine];

// --- Socratic Prompts ---
// IMPORTANT: Ensure ALL socraticPromptIds referenced in ALL_QUESTS have a corresponding definition here.
const mainQuestSocraticPrompts: SocraticPromptDefinition[] = [
    { 
      id: 'SP_Q1S1_UNDERSTANDING', 
      questStepId: 'Q1S1', 
      trigger: 'AI_RESPONSE_RECEIVED', 
      noemaQuestion: "Interesting response from the AI! What does this initial interaction tell you about how an AI 'understands' your questions?", 
      branches: [ 
        { id: 'b1', responseTextMatch: /instructions|prompt|clear/i, noemaResponse: "Precisely! And the clearer your instructions (prompts), the better it can 'understand' and respond. What makes a prompt 'clear' to an AI, in your opinion?", nextSocraticPromptId: 'SP_Q1S1_PROMPT_CLARITY' }, 
        { id: 'b2', responseTextMatch: /search|finds|information/i, noemaResponse: "In some ways, yes, but it can also generate new text, not just find existing information. The key is how you prompt it. What do you think makes a prompt effective for an AI like this?", nextSocraticPromptId: 'SP_Q1S1_PROMPT_CLARITY' }, 
        { id: 'b3', responseTextMatch: /not sure|don't know/i, noemaResponse: "That's perfectly fine! We're just starting. Let's consider this: if you wanted the AI to explain this to a child, how might you change your prompt?", nextSocraticPromptId: 'SP_Q1S1_PROMPT_CLARITY' },
        { id: 'b4', condition: (ctx) => true, noemaResponse: "That's a good observation. The AI processed your words. What do you think makes a prompt 'good' or 'effective' when talking to an AI?", nextSocraticPromptId: 'SP_Q1S1_PROMPT_CLARITY'}
      ] 
    },
    {
      id: 'SP_Q1S1_PROMPT_CLARITY',
      questStepId: 'Q1S1',
      trigger: 'AI_RESPONSE_RECEIVED', // Will be triggered by user's response to SP_Q1S1_UNDERSTANDING's Noema question
      noemaQuestion: "Thinking about prompt clarity and effectiveness is key. What's one thing you could do to make your *next* prompt even clearer or more specific for the AI?",
      branches: [
        { id: 'b1', responseTextMatch: /specific|detail|context/i, noemaResponse: "Excellent point! Adding specificity, details, or context often helps the AI zero in on what you need. Let's try another angle now.", advanceToStepId: 'Q1S2' },
        { id: 'b2', responseTextMatch: /simple|shorter|keywords/i, noemaResponse: "Good idea! Sometimes simpler language or focusing on keywords can be very effective, especially for certain tasks. Ready to try a different way of asking?", advanceToStepId: 'Q1S2' },
        { id: 'b3', condition: (ctx) => true, noemaResponse: "That's a valuable thought. Experimenting with how you phrase things is a big part of learning to interact with AI. Let's proceed!", advanceToStepId: 'Q1S2' }
      ]
    },
    { id: 'SP_Q1S2_DIFFERENT_PHRASING', questStepId: 'Q1S2', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "Did the AI's explanation change significantly when you rephrased your question? What does this suggest about its capabilities?", branches: [ { id: 'b1', responseTextMatch: "Yes, it adapted.", noemaResponse: "Exactly. LLMs can often adapt to the implied complexity or desired tone in your prompt. This flexibility is powerful. Ready to try image generation?", advanceToStepId: 'Q1S3'}, { id: 'b2', responseTextMatch: "No, it was similar.", noemaResponse: "Sometimes the core information remains similar, but subtle changes in phrasing can unlock different nuances or levels of detail. It's worth experimenting! Shall we try generating an image?", advanceToStepId: 'Q1S3' } ]},
    { id: 'SP_Q1S3_IMAGE_GEN', questStepId: 'Q1S3', trigger: 'IMAGE_GENERATED', noemaQuestion: "Look at that! The AI created an image from your words. How well did it match your prompt? What aspects were surprising or impressive?", branches: [ { id: 'b1', responseTextMatch: "It was very accurate!", noemaResponse: "Wonderful! AI image generation is advancing rapidly. You've completed your first quest!", advanceToStepId: 'Q1S1', awardXp: 10 /* Award for completing the Socratic part */ } , { id: 'b2', responseTextMatch: "It was a bit off.", noemaResponse: "That happens! Prompting for images is an art. Sometimes adding more detail or rephrasing can help. You've completed your first quest!" , advanceToStepId: 'Q1S1', awardXp: 10 } ]},
    // Placeholder for DL1_S1 - Data Types Intro
    { id: 'SP_DL1_S1_DATA_TYPES_INTRO', questStepId: 'Q_DL1_S1', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "The AI Guide mentioned structured, semi-structured, and unstructured data. Based on your discussion and Nexus exploration, can you give a one-sentence summary for each?", branches: [ { id: 'b1', responseTextMatch: "Continue", noemaResponse: "Excellent summaries! Understanding these forms is crucial for appreciating how AI processes information. Ready to apply this knowledge?", advanceToStepId: 'Q_DL1_S2' } ] },
    // Placeholder for DL1_S2 - Data Examples (User Reflection)
    { id: 'SP_DL1_S2_DATA_EXAMPLES', questStepId: 'Q_DL1_S2', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "Great effort on categorizing those data snippets! Which type of data do you think is generally easiest for computers to process directly, and why?", branches: [ { id: 'b1', responseTextMatch: "Structured, it's organized.", noemaResponse: "You're right, structured data is often easiest. Let's try another snippet!", nextSocraticPromptId: 'SP_DL1_S2_SNIPPET2' }, { id: 'b2', responseTextMatch: "Unstructured, more natural.", noemaResponse: "While natural, unstructured data often needs significant processing before AI can use it effectively. Let's see another snippet!", nextSocraticPromptId: 'SP_DL1_S2_SNIPPET2' } ] },
    { id: 'SP_DL1_S2_SNIPPET2', questStepId: 'Q_DL1_S2', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "Okay, next snippet analyzed. How about this one: Imagine a JSON file from a weather API. What category would that fall into and why?", branches: [ { id: 'b1', responseTextMatch: "Semi-structured, has tags.", noemaResponse: "Correct! JSON, with its tags and nested structure, is a prime example of semi-structured data. One more!", nextSocraticPromptId: 'SP_DL1_S2_SNIPPET3' } ] },
    { id: 'SP_DL1_S2_SNIPPET3', questStepId: 'Q_DL1_S2', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "Final snippet: A collection of photographs from a nature hike. How would you classify this data?", branches: [ { id: 'b1', responseTextMatch: "Unstructured, raw images.", noemaResponse: "Spot on! Images, videos, and free text are typically unstructured. You've got a good grasp of data forms!", advanceToStepId: 'Q_DL1_S1' /* Placeholder: Should link to next main step or quest completion */ } ] },
    // ... Add more Socratic prompts for all other quests and steps ...
    { id: 'SP_DL2_S1_MESSY_DATA', questStepId: 'Q_DL2_S1', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "You've read about data preprocessing. Why is it that 'garbage in, garbage out' is such a critical mantra in AI?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "Indeed. The quality of AI output is fundamentally tied to the quality of its input data. Let's think about how to clean it.", advanceToStepId: 'Q_DL2_S2'}]},
    { id: 'SP_DL2_S2_CLEANING_STEPS', questStepId: 'Q_DL2_S2', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "You've considered some data cleaning tasks. Which one do you think is often the most challenging or time-consuming for data scientists, and why?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "That's a thoughtful perspective. Each step has its challenges! You're building a solid foundation in data literacy.", advanceToStepId: 'Q_DL2_S1' /* Placeholder */ }]},
    { id: 'SP_DL3_S1_FEATURES_INTRO', questStepId: 'Q_DL3_S1', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "The Nexus explained feature engineering. In your own words, why can't we just feed raw, unprocessed data directly to most AI models for complex tasks?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "Excellent point. Raw data often contains too much noise or isn't in a format models can easily learn from. Let's try an example.", advanceToStepId: 'Q_DL3_S2'}]},
    { id: 'SP_DL3_S2_FEATURE_SELECTION', questStepId: 'Q_DL3_S2', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "Considering the creature descriptions, what's one way you could numerically represent a feature like 'mention of claws' so an AI could use it?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "That's a good approach (e.g., a count, or a binary 0/1). This transformation is key to feature engineering!", advanceToStepId: 'Q_DL3_S1' /* Placeholder */}]},
    { id: 'SP_PH7S1_ENGINES', questStepId: 'Q_PH7_S1_ENGINES', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "Having explored compute, algorithms, and agentic capabilities, which of these three 'engines' do you feel is currently the biggest bottleneck or area for the most impactful near-term breakthroughs in AI, and why?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "That's a very insightful take. It's a dynamic interplay! Ready to consider how AI might accelerate its own progress?", advanceToStepId: 'Q_PH7_S2_RECURSIVE'}]},
    { id: 'SP_PH7S2_RECURSIVE_SPARK', questStepId: 'Q_PH7_S2_RECURSIVE', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "The 'Recursive Spark' is a profound idea. If AI could significantly self-improve, what's one potential positive outcome and one potential risk that immediately comes to your mind?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "Those are definitely key aspects to consider. The potential is immense, as are the responsibilities. Now, let's think about current limitations.", advanceToStepId: 'Q_PH7_S3_UNHOBLING'}]},
    { id: 'SP_PH7S3_BEYOND_LIMITS', questStepId: 'Q_PH7_S3_UNHOBLING', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "Reflecting on overcoming current AI limitations, which breakthrough (e.g., vastly larger context windows, human-like long-term memory, or truly generalizable planning) do you think would be most transformative for AI's role in science or creativity?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "An interesting choice. Each of those would unlock incredible new possibilities. This completes our look at AI's acceleration!", advanceToStepId: 'Q_PH7_S1_ENGINES' /* Placeholder, should go to quest completion/next */ }]},
    { id: 'SP_PH7S4_WISHGRANTER', questStepId: 'Q_PH7_S4_GOALSPEC', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "The 'Wishgranter's Flaw' highlights the challenge of specifying goals. Can you think of a simple, everyday instruction that, if given to a very literal-minded but powerful AI, could lead to an unexpected or undesirable outcome?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "That's a great example of how easily misinterpretations can happen! This precision is key in AI safety. Let's look at another challenge.", advanceToStepId: 'Q_PH7_S5_MISGENERAL'}]},
    { id: 'SP_PH7S5_WAYWARD_APPRENTICE', questStepId: 'Q_PH7_S5_MISGENERAL', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "Considering 'Goal Misgeneralization' and 'Reward Hacking', why do you think AI systems might develop these unintended behaviors even when we try to define clear rewards or objectives?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "Exactly. AI often finds the path of least resistance to maximize its programmed reward, which might not align with our unstated assumptions or broader intentions. This leads to our next point.", advanceToStepId: 'Q_PH7_S6_MISUSE'}]},
    { id: 'SP_PH7S6_GUARDIAN_CODE', questStepId: 'Q_PH7_S6_MISUSE', trigger: 'USER_REFLECTION_SUBMITTED', noemaQuestion: "The 'Guardian's Code' dilemma is tough. If an AI is designed to be highly adaptable and learn continuously, what makes it so difficult to create safeguards that it can't eventually learn to bypass or overcome, especially if misused?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "A crucial point. The adaptability that makes AI powerful also makes robust, long-term safeguarding a significant research challenge. One final consideration...", advanceToStepId: 'Q_PH7_S7_ASI_DILEMMA'}]},
    { id: 'SP_PH7S7_ASI_DILEMMA', questStepId: 'Q_PH7_S7_ASI_DILEMMA', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "Even with a perfectly 'aligned' ASI, societal adaptation would be immense. What's one aspect of human life (e.g., work, education, art, relationships) you think would be most profoundly changed, and how?", branches: [{id: 'b1', responseTextMatch: "Continue", noemaResponse: "That's a fascinating area to contemplate. The future with advanced AI will require much thought and preparation. You've navigated the complexities of AI safety well!", advanceToStepId: 'Q_PH7_S4_GOALSPEC' /* Placeholder, quest completion */ }]},
];

const agentAcademySocraticPrompts: SocraticPromptDefinition[] = [
    { id: 'SP_AA_Q1S1_WHAT_IS_AGENT', questStepId: 'AA_Q1S1_WHAT_IS_AGENT', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "Good points. The Nexus mentioned perception, action, goals, and environment. How do these four elements work together to define an agent?", branches: [{ id: 'b1', responseTextMatch: "They interact in a cycle.", noemaResponse: "Precisely! An agent perceives its environment, decides on an action based on its goals, and then acts, changing the environment, starting the cycle anew. Ready for a glimpse at different agent types?", advanceToStepId: 'AA_Q1S2_TYPES_OF_AGENTS' }] },
    { id: 'SP_AA_Q1S2_AGENT_TYPES', questStepId: 'AA_Q1S2_TYPES_OF_AGENTS', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "We've touched on Reflex, Model-Based, and Goal-Based agents. In simple terms, what's the main difference in how a Reflex agent 'thinks' compared to a Goal-Based one?", branches: [{ id: 'b1', responseTextMatch: "Continue", noemaResponse: "Excellent. Reflex is immediate, while Goal-Based involves looking ahead. You've completed your first Agent Academy unit!", advanceToStepId: 'AA_Q1S1_WHAT_IS_AGENT' /* Placeholder */ }] },
    // Socratic prompts for AA_Q2 (Perception, Planning, Action) are triggered by GLOSSARY_EXPLORATION - these might need specific handling or be more reflective
    { id: 'SP_AA_Q2S1_PERCEPTION', questStepId: 'AA_Q2S1_PERCEPTION', trigger: 'GLOSSARY_EXPLORATION', condition: (ctx) => ctx.customEventIdentifier === 'G18', noemaQuestion: "You've explored 'Perception'. How might an AI agent's perception differ from human perception, even if it's processing similar information (like an image)?", branches: [{ id: 'b1', responseTextMatch: "Got it!", noemaResponse: "Interesting thought! Let's move to planning.", advanceToStepId: 'AA_Q2S2_PLANNING' }] },
    { id: 'SP_AA_Q2S2_PLANNING', questStepId: 'AA_Q2S2_PLANNING', trigger: 'GLOSSARY_EXPLORATION', condition: (ctx) => ctx.customEventIdentifier === 'G19', noemaQuestion: "After looking into 'Planning', what's one key challenge an agent might face when trying to create an effective plan in a complex, unpredictable environment?", branches: [{ id: 'b1', responseTextMatch: "Continue", noemaResponse: "True, uncertainty is a big one! Now for action.", advanceToStepId: 'AA_Q2S3_ACTION' }] },
    { id: 'SP_AA_Q2S3_ACTION', questStepId: 'AA_Q2S3_ACTION', trigger: 'GLOSSARY_EXPLORATION', condition: (ctx) => ctx.customEventIdentifier === 'G20', noemaQuestion: "Considering 'Action', why is it important for an agent's actions to be tied to its goals and its understanding of the environment?", branches: [{ id: 'b1', responseTextMatch: "Understood.", noemaResponse: "Precisely. Purposeful action is key! This completes your study of basic agent components.", advanceToStepId: 'AA_Q2S1_PERCEPTION' /* Placeholder */ }] },
    // Socratic prompts for AA_Q_CLARIFY
    { id: 'SP_AA_Q_CLARIFY_S1_WHY_QUESTIONS', questStepId: 'AA_Q_CLARIFY_S1', trigger: 'AI_RESPONSE_RECEIVED', condition: (ctx) => ctx.aiResponse?.includes("clarifying questions") ?? false, noemaQuestion: "The agent wants to ask clarifying questions. Why is this a good first step when faced with an ambiguous goal like 'get virtual cookie ingredients'?", branches: [{ id: 'b1', responseTextMatch: "To understand better.", noemaResponse: "Exactly! Clear goals lead to useful actions."}]},
    { id: 'SP_AA_Q_CLARIFY_S1_AMBIGUITY', questStepId: 'AA_Q_CLARIFY_S1', trigger: 'AI_RESPONSE_RECEIVED', condition: (ctx) => ctx.aiResponse?.includes("ambiguous") ?? false, noemaQuestion: "The agent identified 'virtual cookies' and 'virtual ingredients' as ambiguous. What makes them ambiguous in this context?", branches: [{ id: 'b1', responseTextMatch: "Could mean many things.", noemaResponse: "Precisely. Without context, 'virtual' could refer to a game, a story, code, etc."}]},
    { id: 'SP_AA_Q_CLARIFY_S1_PLAN_STEPS', questStepId: 'AA_Q_CLARIFY_S1', trigger: 'AI_RESPONSE_RECEIVED', condition: (ctx) => (ctx.aiResponse?.includes("platform or tool") && ctx.aiResponse?.includes("specific type") && ctx.aiResponse?.includes("context/purpose")) ?? false, noemaQuestion: "The agent plans to ask about context/purpose, platform/tool, and specific ingredient types. Are these good questions to resolve the ambiguity? Why or why not?", branches: [{ id: 'b1', responseTextMatch: "They cover key unknowns.", noemaResponse: "Correct! These questions help narrow down the possibilities and define a solvable problem for the agent."}]},
    // ... more Socratic prompts for Agent Academy ...
    { id: 'SP_AA_Q3S1_REFLEX_OBSERVE', questStepId: 'AA_Q3S1_REFLEX_INTRO', trigger: 'AGENT_SIMULATION_EVENT', condition: (ctx) => ctx.customEventIdentifier === 'agent_cleaned_dirt' || ctx.customEventIdentifier === 'agent_hit_obstacle', noemaQuestion: "You saw the Reflex Agent in action. What are its main strengths and weaknesses based on what you observed?", branches: [{ id: 'b1', responseTextMatch: "Continue", advanceToStepId: 'AA_Q3S1_REFLEX_INTRO' /* Placeholder for quest completion */ }] },
    { id: 'SP_AA_Q4S1_MODEL_BEHAVIOR', questStepId: 'AA_Q4S1_MODEL_AGENT_INTRO', trigger: 'AGENT_SIMULATION_EVENT', condition: (ctx) => ctx.customEventIdentifier === 'agent_battery_low_seeking_charger' || ctx.customEventIdentifier === 'agent_updated_model_obstacle', noemaQuestion: "The Model-Based Agent is using its memory (internal model) and managing its battery. How does this differ from the Simple Reflex Agent's behavior?", branches: [{ id: 'b1', responseTextMatch: "It plans ahead more."}] },
    { id: 'SP_AA_Q4S2_MODEL_IMPROVEMENT', questStepId: 'AA_Q4S1_MODEL_AGENT_INTRO', trigger: 'AGENT_SIMULATION_EVENT', condition: (ctx) => ctx.customEventIdentifier === 'agent_stuck_battery_empty' || (ctx.customEventIdentifier === 'agent_recharging' && (ctx.agentBatteryLevel || 0) < 50) , noemaQuestion: "If the agent ran out of battery or is taking a long time, what's one way its internal model or rules could be improved for this environment?", branches: [{ id: 'b1', responseTextMatch: "Continue", advanceToStepId: 'AA_Q4S1_MODEL_AGENT_INTRO' /* Placeholder */ }] },
    { id: 'SP_AA_Q5S1_GOAL_STRATEGY', questStepId: 'AA_Q5S1_GOAL_AGENT_INTRO', trigger: 'AGENT_SIMULATION_EVENT', condition: (ctx) => ctx.customEventIdentifier === 'agent_collected_item' || ctx.customEventIdentifier === 'agent_seeking_exit', noemaQuestion: "This Goal-Based Agent is pursuing specific objectives. How does having an explicit goal (collect items, reach exit) influence its decision-making process compared to the previous agents?", branches: [{ id: 'b1', responseTextMatch: "Its actions are more directed." }] },
    { id: 'SP_AA_Q5S2_PLAN_ADAPT', questStepId: 'AA_Q5S1_GOAL_AGENT_INTRO', trigger: 'AGENT_SIMULATION_EVENT', condition: (ctx) => (ctx.customEventIdentifier === 'agent_hit_obstacle' && ctx.agentGoalStatus?.includes("Collect items")) ?? false, noemaQuestion: "The agent hit an obstacle while trying to reach an item. How might a sophisticated Goal-Based Agent adapt its plan in such a situation?", branches: [{ id: 'b1', responseTextMatch: "Continue", advanceToStepId: 'AA_Q5S1_GOAL_AGENT_INTRO' /* Placeholder */ }] },
    { id: 'SP_AA_Q8S1_INTRO', questStepId: 'AA_Q8S1_PACKAGE_SORTER', trigger: 'STEP_START', noemaQuestion: "Welcome to the Agent Assembler! Your task: build a 'Package Sorter'. What's the very first type of component an agent usually needs to interact with its environment?", branches: [{ id: 'b1', responseTextMatch: "Sensor", noemaResponse: "Correct! It needs to sense things. Drag a sensor to the appropriate slot." }] },
    { id: 'SP_AA_Q8S2_SENSOR_CHOICE', questStepId: 'AA_Q8S1_PACKAGE_SORTER', trigger: 'AGENT_SIMULATION_EVENT', condition: ctx => ctx.customEventIdentifier === 'agent_assembly_missing_sensor', noemaQuestion: "It seems your agent is missing a way to sense the packages. Which available sensor component do you think would be best for identifying package color?", branches: []},
    { id: 'SP_AA_Q8S3_LOGIC_CHOICE', questStepId: 'AA_Q8S1_PACKAGE_SORTER', trigger: 'AGENT_SIMULATION_EVENT', condition: ctx => ctx.customEventIdentifier === 'agent_assembly_missing_logic', noemaQuestion: "The agent can sense, but how will it decide where each package goes? Which decision module seems most appropriate for this color-based sorting task?", branches: []},
    { id: 'SP_AA_Q8S4_ACTUATOR_CHOICE', questStepId: 'AA_Q8S1_PACKAGE_SORTER', trigger: 'AGENT_SIMULATION_EVENT', condition: ctx => ctx.customEventIdentifier === 'agent_assembly_missing_actuator', noemaQuestion: "Your agent can sense and decide, but it needs to physically sort the packages. Which actuator component will allow it to move packages to the correct conveyor belts?", branches: []},
    { id: 'SP_AA_Q8S5_TEST_RESULT', questStepId: 'AA_Q8S1_PACKAGE_SORTER', trigger: 'AGENT_SIMULATION_EVENT', condition: ctx => ctx.customEventIdentifier === 'agent_assembly_success', noemaQuestion: "Excellent! Your Package Sorter design is theoretically sound. What was the key to ensuring the components worked together effectively?", branches: [{id: 'b1', responseTextMatch:"Correct types in slots.", advanceToStepId: 'AA_Q8S1_PACKAGE_SORTER' /* Placeholder */}]},
    { id: 'SP_AA_Q9S1_PARAM_IMPACT', questStepId: 'AA_Q9S1_TUNING_CHALLENGE', trigger: 'AGENT_SIMULATION_EVENT', condition: ctx => ctx.customEventIdentifier === 'simulation_parameters_set' || (ctx.customEventIdentifier === 'agent_stuck_battery_empty' && !!ctx.tweakedParameters), noemaQuestion: "You've adjusted the agent's parameters. How do you predict these changes will affect its cleaning efficiency or battery life compared to the default settings?", branches: []},
    { id: 'SP_AA_Q9S2_OPTIMIZATION', questStepId: 'AA_Q9S1_TUNING_CHALLENGE', trigger: 'AGENT_SIMULATION_EVENT', condition: ctx => ctx.customEventIdentifier === 'all_dirt_cleaned' || (ctx.customEventIdentifier === 'goal_achieved' && (ctx.simulationOutcome === "goal_achieved" || ctx.simulationOutcome === "all_dirt_cleaned")), noemaQuestion: "The agent completed its task with your parameters! What was the most critical parameter you tuned to achieve this efficient outcome, and why?", branches: [{id: 'b1', responseTextMatch: "Continue", advanceToStepId: 'AA_Q9S1_TUNING_CHALLENGE' /* Placeholder */ }]},
    { id: 'SP_AA_Q10S1_INTRO', questStepId: 'AA_Q10S1_BLUEPRINT_BASICS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'user_added_inputs', noemaQuestion: "You've added components! How do you connect the 'User Text Input' output to the 'Display Text Output' input?", branches: [{id: 'b1', responseTextMatch: "Click output then input.", noemaResponse: "Exactly! Click the output node of the first, then the input node of the second."}]},
    { id: 'SP_AA_Q10S1_SUCCESS', questStepId: 'AA_Q10S1_BLUEPRINT_BASICS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Workflow executed! What does this simple setup demonstrate about data flow in the orchestrator?", branches: [{id: 'b1', responseTextMatch: "Output flows to input.", noemaResponse: "Correct! Let's add an LLM.", advanceToStepId: 'AA_Q10S2_LLM_LINKUP'}]},
    { id: 'SP_AA_Q10S2_CONNECT_LLM', questStepId: 'AA_Q10S2_LLM_LINKUP', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Great! The LLM rephrased the text. How did changing the connections alter the data flow compared to the previous step?", branches: [{id: 'b1', responseTextMatch: "Data goes through LLM now.", noemaResponse: "Precisely. Now let's explore parameters.", advanceToStepId: 'AA_Q10S3_PARAMETER_POWER'}]},
    { id: 'SP_AA_Q10S3_INTRO', questStepId: 'AA_Q10S3_PARAMETER_POWER', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Did you notice how changing the 'Rephrase Style' or 'Temperature' in the LLM's configuration changed the output? What does this tell you about configuring AI components?", branches: [] },
    { id: 'SP_AA_Q10S3_OBSERVE_EFFECT', questStepId: 'AA_Q10S3_PARAMETER_POWER', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success' && (ctx.orchestratorOutputData?.displayed_text?.toLowerCase().includes('arrr') || (ctx.orchestratorOutputData?.displayed_text?.split(' ').length || 0) < 10) , noemaQuestion: "You've successfully experimented with parameters! This level of control is key to tailoring AI behavior. You've completed The Automated Scribe quest!", branches: [{id: 'b1', responseTextMatch: "Great!", advanceToStepId: 'AA_Q10S1_BLUEPRINT_BASICS'}]}, // Loop back to start or next quest.
    { id: 'SP_AA_Q11S1_INPUTS', questStepId: 'AA_Q11S1_INPUTS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'user_added_inputs', noemaQuestion: "You've added input components for an image and text instructions. Why are both necessary for our 'Automated Art Critic'?", branches: [{id: 'b1', responseTextMatch: "Image is what to critique, text is how.", noemaResponse: "Exactly! Let's connect them for analysis.", advanceToStepId: 'AA_Q11S2_VISION_ANALYSIS'}]},
    { id: 'SP_AA_Q11S2_VISION_CONNECT', questStepId: 'AA_Q11S2_VISION_ANALYSIS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "The LLM Image Analyzer has produced a textual critique. What role did the text prompt play in guiding its analysis of the image?", branches: [{id: 'b1', responseTextMatch: "It focused the analysis.", noemaResponse: "Correct! Now let's structure this output.", advanceToStepId: 'AA_Q11S3_STRUCTURE_CRITIQUE'}]},
    { id: 'SP_AA_Q11S3_STRUCTURE_JSON', questStepId: 'AA_Q11S3_STRUCTURE_CRITIQUE', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "The critique is now in JSON format. Why is structured data like JSON often preferred over free-form text for further programmatic use?", branches: [{id: 'b1', responseTextMatch: "Easier to parse/use.", noemaResponse: "Precisely. Let's display our results.", advanceToStepId: 'AA_Q11S4_DISPLAY_RESULTS'}]},
    { id: 'SP_AA_Q11S4_FORMAT_DISPLAY', questStepId: 'AA_Q11S4_DISPLAY_RESULTS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "You've displayed both raw and structured critiques! What are the benefits of seeing both forms of output?", branches: [{id: 'b1', responseTextMatch: "Raw shows AI's 'voice', JSON is for data.", noemaResponse: "Excellent insight! You've mastered the Art Critic.", advanceToStepId: 'AA_Q11S1_INPUTS' /* Placeholder */}]},
    { id: 'SP_AA_Q13S1_FETCH_SETUP', questStepId: 'AA_Q13S1_FETCH_NEWS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "The Web Search Augmenter should now fetch news based on your topic. What kind of data do you expect from its 'Augmented Answer' and 'Source URLs' outputs?", branches: [{id: 'b1', advanceToStepId: 'AA_Q13S2_PARSE_RESULTS'}]},
    { id: 'SP_AA_Q13S2_PARSE_LOGIC', questStepId: 'AA_Q13S2_PARSE_RESULTS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "The JSON Parser is set up. Why is it important to inspect the structure of the Web Search output before configuring the parser's path?", branches: [{id: 'b1', advanceToStepId: 'AA_Q13S3_SUMMARIZE_CLASSIFY'}]},
    { id: 'SP_AA_Q13S3_SUM_CLASS_IMPL', questStepId: 'AA_Q13S3_SUMMARIZE_CLASSIFY', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Your pipeline now summarizes and classifies. How does using two separate LLM components for these tasks offer more control than one giant prompt?", branches: [{id: 'b1', advanceToStepId: 'AA_Q13S4_DISPLAY_AGGREGATION'}]},
    { id: 'SP_AA_Q13S4_DISPLAY_SETUP', questStepId: 'AA_Q13S4_DISPLAY_AGGREGATION', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "You're displaying the aggregated news. What are the benefits of such an automated news processing pipeline?", branches: [{id: 'b1', advanceToStepId: 'AA_Q13S1_FETCH_NEWS' /* Placeholder */ }]},
    { id: 'SP_AA_Q14S1_CLAIM_INPUT', questStepId: 'AA_Q14S1_INPUT_CLAIM', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'user_added_inputs', noemaQuestion: "The claim input is ready. What's the next logical step for our fact-checker?", branches: [{id: 'b1', advanceToStepId: 'AA_Q14S2_SEARCH_EVIDENCE'}]},
    { id: 'SP_AA_Q14S2_SEARCH_SETUP', questStepId: 'AA_Q14S2_SEARCH_EVIDENCE', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Evidence retrieved! What's a crucial factor when evaluating information found online?", branches: [{id: 'b1', advanceToStepId: 'AA_Q14S3_ANALYZE_SOURCES'}]},
    { id: 'SP_AA_Q14S3_SOURCE_ANALYSIS', questStepId: 'AA_Q14S3_ANALYZE_SOURCES', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Source data parsed. How might an AI determine if a source is 'reputable' (even if we're just doing it conceptually here)?", branches: [{id: 'b1', advanceToStepId: 'AA_Q14S4_SYNTHESIZE_ASSESS'}]},
    { id: 'SP_AA_Q14S4_ASSESSMENT_LOGIC', questStepId: 'AA_Q14S4_SYNTHESIZE_ASSESS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "The system is making a tentative assessment. Why is it important for a fact-checker to indicate uncertainty or degrees of confidence rather than absolute true/false?", branches: [{id: 'b1', advanceToStepId: 'AA_Q14S5_DISPLAY_VERDICT'}]},
    { id: 'SP_AA_Q14S5_VERDICT_DISPLAY', questStepId: 'AA_Q14S5_DISPLAY_VERDICT', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Fact-checker complete! What are the limitations of such an automated system?", branches: [{id: 'b1', advanceToStepId: 'AA_Q14S1_INPUT_CLAIM' /* Placeholder */}]},
    { id: 'SP_AA_Q15S1_SETUP_SENSES', questStepId: 'AA_Q15S1_SENSE_INPUTS', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'user_added_inputs', noemaQuestion: "Forager senses defined. What's the next step in designing its 'brain'?", branches: [{id: 'b1', advanceToStepId: 'AA_Q15S2_DECISION_LOGIC'}]},
    { id: 'SP_AA_Q15S2_BUILD_LOGIC', questStepId: 'AA_Q15S2_DECISION_LOGIC', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Decision logic implemented! How does this simple IF-THEN structure allow the agent to react to its environment?", branches: [{id: 'b1', advanceToStepId: 'AA_Q15S3_ACTION_OUTPUT'}]},
    { id: 'SP_AA_Q15S3_TEST_ACTION', questStepId: 'AA_Q15S3_ACTION_OUTPUT', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "The forager's action is displayed. If you change the input 'senses', does the action change as expected?", branches: []},
    { id: 'SP_AA_Q15S4_EMERGENCE_DISCUSSION', questStepId: 'AA_Q15S3_ACTION_OUTPUT', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Imagine hundreds of these foragers, each with slightly varied senses or encountering different local conditions. What kind of complex group behavior might 'emerge' even if each individual follows these simple rules?", branches: [{id: 'b1', advanceToStepId: 'AA_Q15S1_SENSE_INPUTS'}]},
    { id: 'SP_AA_Q16S1_DEFINE_EMERGENCE', questStepId: 'AA_Q16S1_EMERGENCE', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "The Nexus entries on Emergent Behavior and Swarm Intelligence are insightful. Can you give an example of emergent behavior, either from nature or AI, that arises from simple individual rules?", branches: [{id: 'b1', advanceToStepId: 'AA_Q16S2_SWARM_EXAMPLES'}]},
    { id: 'SP_AA_Q16S2_NATURE_EXAMPLES', questStepId: 'AA_Q16S2_SWARM_EXAMPLES', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "Ants finding the shortest path to food is a classic example. What simple rule(s) might individual ants follow that leads to this complex outcome (e.g., related to pheromones)?", branches: [{id: 'b1', advanceToStepId: 'AA_Q16S3_AI_SWARMS'}]},
    { id: 'SP_AA_Q16S3_AI_APPLICATIONS', questStepId: 'AA_Q16S3_AI_SWARMS', trigger: 'AI_RESPONSE_RECEIVED', noemaQuestion: "Considering AI swarms for tasks like search and rescue, what's one major advantage of a swarm approach over a single, highly complex robot for such a task?", branches: [{id: 'b1', advanceToStepId: 'AA_Q16S1_EMERGENCE' /* Placeholder */}]},
    { id: 'SP_AA_Q17S1_QUERY_SETUP', questStepId: 'AA_Q17S1_INPUT_QUERY', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'user_added_inputs', noemaQuestion: "Query input ready. What's the next critical component in a RAG system?", branches: [{id: 'b1', advanceToStepId: 'AA_Q17S2_WEB_RETRIEVAL'}]},
    { id: 'SP_AA_Q17S2_SEARCH_CONNECT', questStepId: 'AA_Q17S2_WEB_RETRIEVAL', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "Web Search connected! What information does this component provide to the next stage?", branches: [{id: 'b1', advanceToStepId: 'AA_Q17S3_LLM_AUGMENTATION'}]},
    { id: 'SP_AA_Q17S3_LLM_AUGMENTATION', questStepId: 'AA_Q17S3_LLM_AUGMENTATION', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "The LLM has synthesized an answer using web context. How does this 'augmentation' improve upon what an LLM might generate from its training data alone?", branches: [{id: 'b1', advanceToStepId: 'AA_Q17S4_DISPLAY_RAG_RESULT'}]},
    { id: 'SP_AA_Q17S4_FINAL_OUTPUT', questStepId: 'AA_Q17S4_DISPLAY_RAG_RESULT', trigger: 'ORCHESTRATOR_WORKFLOW_EVENT', condition: ctx => ctx.orchestratorWorkflowStatus === 'executed_success', noemaQuestion: "RAG Reporter complete! What are the key benefits of using a RAG approach for question answering?", branches: [{id: 'b1', advanceToStepId: 'AA_Q17S1_INPUT_QUERY' /* Placeholder */}]},
];

export const ALL_SOCRATIC_PROMPTS: SocraticPromptDefinition[] = [
    ...mainQuestSocraticPrompts,
    ...agentAcademySocraticPrompts
];
