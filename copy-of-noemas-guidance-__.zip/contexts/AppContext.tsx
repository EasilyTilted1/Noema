
import React, { createContext, useContext, useState, FC, ReactNode, useEffect, useCallback } from 'react';
import {
  AppContextType,
  UserProgressData,
  Quest,
  SocraticPromptDefinition,
  PromptItem,
  ModalConfig,
  ToastMessage,
  NotebookEntry,
  ChatMessage,
  StoryForgeSession,
  VaultStory,
  WorkshopMode,
  OrchestratorWorkflow,
  AppView,
  SocraticContext,
  IconName
} from '../types'; // Path relative to contexts/
import { ALL_QUESTS, INITIAL_GLOSSARY_DATA, DEFAULT_USER_NAME, DEFAULT_TTS_ENABLED, ALL_SOCRATIC_PROMPTS, LOCALSTORAGE_USER_PROGRESS_KEY_PREFIX } from '../constants'; // Path relative to contexts/
import { Icon } from '../components/Icon'; // Path relative to contexts/

export const AppContext = createContext<AppContextType | null>(null);

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: FC<{ children: ReactNode }> = ({ children }) => {
  const [userProgress, setUserProgress] = useState<UserProgressData | null>(null);
  const [currentView, _setCurrentView] = useState<AppContextType['currentView']>('welcome');
  const [isAppReady, setIsAppReady] = useState(false); // Start as false until loaded
  const [activeWorkshopMode, setActiveWorkshopMode] = useState<WorkshopMode | null>(null);
  const [selectedOrchestratorInstanceId, setSelectedOrchestratorInstanceId] = useState<string | null>(null);
  const [orchestratorWorkflowForContext, setOrchestratorWorkflowForContext] = useState<OrchestratorWorkflow | null>(null);
  const [inputValue, setInputValue] = useState('');
  const [promptLibrary, setPromptLibrary] = useState<PromptItem[]>([]);
  const [modalConfig, setModalConfig] = useState<ModalConfig | null>(null);
  const [toastMessages, setToastMessages] = useState<ToastMessage[]>([]);
  const [targetNexusTermId, setTargetNexusTermId] = useState<string | null>(null);


  // Initial load from localStorage
  useEffect(() => {
    try {
      const savedStateJSON = localStorage.getItem(LOCALSTORAGE_USER_PROGRESS_KEY_PREFIX);
      if (savedStateJSON) {
        const savedState = JSON.parse(savedStateJSON) as any;

        const userProgressDataToSet: UserProgressData = {
          userId: savedState.userId,
          displayName: savedState.displayName,
          xp: savedState.xp,
          unlockedBadgeIds: savedState.unlockedBadgeIds,
          currentQuestId: savedState.currentQuestId,
          currentStepId: savedState.currentStepId,
          completedQuestSteps: savedState.completedQuestSteps,
          savedAiResponses: savedState.savedAiResponses || [],
          noemasNotebookEntries: savedState.noemasNotebookEntries || [],
          storyForgeSessions: savedState.storyForgeSessions || [],
          storyVault: savedState.storyVault || [],
          ttsEnabled: savedState.ttsEnabled !== undefined ? savedState.ttsEnabled : DEFAULT_TTS_ENABLED,
        };
        
        if (userProgressDataToSet.userId) {
          setUserProgress(userProgressDataToSet);
          const savedView = savedState.currentView || (userProgressDataToSet.currentQuestId && userProgressDataToSet.currentStepId ? 'interaction' : 'quest_log');
          _setCurrentView(savedView);
          
          if (savedView === 'story_forge') {
            setActiveWorkshopMode('story_forge');
          } else if (savedView === 'agent_orchestrator_sandbox') {
            setActiveWorkshopMode('agent_orchestrator_sandbox');
          } else if (savedView === 'workshop' && savedState.activeWorkshopMode) {
            setActiveWorkshopMode(savedState.activeWorkshopMode);
          } else {
            setActiveWorkshopMode(null);
          }

        } else {
          _setCurrentView('welcome');
        }
      } else {
        _setCurrentView('welcome');
      }
    } catch (error) {
      console.error("Failed to load state from localStorage:", error);
      _setCurrentView('welcome');
    }
    setIsAppReady(true);
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (userProgress && userProgress.userId && isAppReady) { // Only save if app is ready and user exists
      try {
        const stateToSave = {
          ...userProgress,
          currentView: currentView,
          activeWorkshopMode: activeWorkshopMode,
        };
        localStorage.setItem(LOCALSTORAGE_USER_PROGRESS_KEY_PREFIX, JSON.stringify(stateToSave));
      } catch (error) {
        console.error("Failed to save state to localStorage:", error);
      }
    }
  }, [userProgress, currentView, activeWorkshopMode, isAppReady]);

  const initializeUser = (name: string) => {
    const userId = `user_${Date.now()}_${Math.random().toString(16).slice(2)}`;
    const newUserProgress: UserProgressData = {
      userId,
      displayName: name || DEFAULT_USER_NAME,
      xp: 0,
      unlockedBadgeIds: [],
      currentQuestId: null,
      currentStepId: null,
      completedQuestSteps: {},
      savedAiResponses: [],
      noemasNotebookEntries: [],
      storyForgeSessions: [],
      storyVault: [],
      ttsEnabled: DEFAULT_TTS_ENABLED,
    };
    setUserProgress(newUserProgress);
    _setCurrentView('quest_log');
    setActiveWorkshopMode(null);
    console.log('[AppProvider] User initialized, currentView set to quest_log.');
  };

  const setCurrentView = (view: AppView) => {
    _setCurrentView(view);
    if (view === 'story_forge') {
      setActiveWorkshopMode('story_forge');
    } else if (view === 'agent_orchestrator_sandbox') {
      setActiveWorkshopMode('agent_orchestrator_sandbox');
    } else if (view === 'workshop') {
      if (!activeWorkshopMode || !['chat', 'image', 'tool_master', 'debate_arena', 'feedback_coach'].includes(activeWorkshopMode)) {
         setActiveWorkshopMode('chat'); 
      }
    } else {
      setActiveWorkshopMode(null);
    }
  };
  
  const speak = useCallback((text: string, force: boolean = false) => {
    if (userProgress?.ttsEnabled || force) {
      // Actual TTS implementation would go here
      console.log("TTS (mock):", text);
    }
  }, [userProgress?.ttsEnabled]);

  const toggleTTS = () => {
    setUserProgress(prev => prev ? { ...prev, ttsEnabled: !prev.ttsEnabled } : null);
    // speak(userProgress?.ttsEnabled ? "Text-to-speech disabled." : "Text-to-speech enabled.");
  };
  
  const addToast = useCallback((message: string, type: ToastMessage['type'] = 'info', duration: number = 3000) => {
    const id = crypto.randomUUID();
    setToastMessages(prev => [...prev, { id, message, type, duration }]);
    setTimeout(() => {
      setToastMessages(prev => prev.filter(t => t.id !== id));
    }, duration);
  }, []);

  const showModal = useCallback((config: Omit<ModalConfig, 'isVisible'>) => {
    setModalConfig({ ...config, isVisible: true });
  }, []);

  const hideModal = useCallback(() => {
    setModalConfig(prev => prev ? { ...prev, isVisible: false } : null);
    // Delay removal to allow for fade-out animations if any
    setTimeout(() => setModalConfig(null), 300);
  }, []);

  const startQuest = (questId: string) => {
    const quest = ALL_QUESTS.find(q => q.id === questId);
    if (quest && quest.steps.length > 0) {
      setUserProgress(prev => {
        if (!prev) return null;
        return {
          ...prev,
          currentQuestId: questId,
          currentStepId: quest.steps[0].id,
        };
      });
      setCurrentView('interaction');
      if (quest.steps[0]?.title) {
           speak(`Starting quest: ${quest.title}. First step: ${quest.steps[0].title}.`);
      }
    } else {
      addToast(`Error: Could not start quest "${quest?.title || questId}".`, 'error');
    }
  };

  const completeStep = useCallback((stepId: string, questId: string, socraticContext?: SocraticContext) => {
    setUserProgress(prev => {
      if (!prev) return null;
      const quest = ALL_QUESTS.find(q => q.id === questId);
      if (!quest) return prev;
      const step = quest.steps.find(s => s.id === stepId);
      if (!step) return prev;

      const updatedCompletedSteps = {
        ...prev.completedQuestSteps,
        [stepId]: { completedAt: Date.now(), socraticPath: [] } 
      };
      let newXp = prev.xp + (step.xpAward || 0);
      
      const questStepsCompleted = quest.steps.every(s => updatedCompletedSteps[s.id]);
      let newUnlockedBadges = [...prev.unlockedBadgeIds];
      if (questStepsCompleted && !newUnlockedBadges.includes(quest.badge.id)) {
        newUnlockedBadges.push(quest.badge.id);
        newXp += quest.totalXp - quest.steps.reduce((sum, s) => sum + (s.xpAward || 0), 0); 
        addToast(`Badge Unlocked: ${quest.badge.name}!`, 'success');
        speak(`Congratulations! You've earned the ${quest.badge.name} badge.`);
      }
      
      const currentStepIndex = quest.steps.findIndex(s => s.id === stepId);
      let nextStepId: string | null = null;
      let nextQuestId: string | null = questId;

      if (currentStepIndex < quest.steps.length - 1) {
        nextStepId = quest.steps[currentStepIndex + 1].id;
      } else { 
        nextQuestId = null; 
        nextStepId = null;
        addToast(`Quest "${quest.title}" completed!`, 'success');
        speak(`Quest "${quest.title}" completed! Well done!`);
      }

      return {
        ...prev,
        xp: newXp,
        unlockedBadgeIds: newUnlockedBadges,
        completedQuestSteps: updatedCompletedSteps,
        currentQuestId: nextQuestId,
        currentStepId: nextStepId,
      };
    });

    const quest = ALL_QUESTS.find(q => q.id === questId);
    if (quest) {
        const currentStepIndex = quest.steps.findIndex(s => s.id === stepId);
        if (currentStepIndex < quest.steps.length - 1) {
             setCurrentView('interaction'); 
        } else {
            if (quest.academy === 'agentAcademy') {
                setCurrentView('agent_academy_log');
            } else {
                setCurrentView('quest_log');
            }
        }
    }
  }, [addToast, speak, setCurrentView]);

  const resetUserProgressAndLibrary = () => {
    showModal({
      title: "Confirm Reset",
      content: "Are you sure you want to reset all your progress, notebook entries, and story vault? This action cannot be undone.",
      confirmText: "Reset All",
      onConfirm: () => {
        localStorage.removeItem(LOCALSTORAGE_USER_PROGRESS_KEY_PREFIX);
        setUserProgress(null);
        setPromptLibrary([]);
        _setCurrentView('welcome');
        setActiveWorkshopMode(null);
        addToast("All progress has been reset.", "info");
        speak("All progress has been reset. Welcome back, Adventurer!");
        hideModal();
      },
      cancelText: "Cancel",
      onCancel: hideModal,
    });
  };
  
  const addNotebookEntry = (entryData: Omit<NotebookEntry, 'id' | 'createdAt' | 'updatedAt'>) => {
    setUserProgress(prev => {
      if (!prev) return null;
      const newEntry: NotebookEntry = {
        ...entryData,
        id: `note_${Date.now()}_${Math.random().toString(16).slice(2)}`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      const updatedProgress = { ...prev, noemasNotebookEntries: [newEntry, ...prev.noemasNotebookEntries] };
      addToast(`Note "${newEntry.title || 'Untitled'}" added.`, 'success');
      return updatedProgress;
    });
  };

  const updateNotebookEntry = (updatedEntry: NotebookEntry) => {
    setUserProgress(prev => {
      if (!prev) return null;
      const updatedEntries = prev.noemasNotebookEntries.map(entry =>
        entry.id === updatedEntry.id ? { ...updatedEntry, updatedAt: Date.now() } : entry
      );
      addToast(`Note "${updatedEntry.title || 'Untitled'}" updated.`, 'success');
      return { ...prev, noemasNotebookEntries: updatedEntries };
    });
  };

  const deleteNotebookEntry = (entryId: string) => {
    setUserProgress(prev => {
      if (!prev) return null;
      const entryToDelete = prev.noemasNotebookEntries.find(e => e.id === entryId);
      const updatedEntries = prev.noemasNotebookEntries.filter(entry => entry.id !== entryId);
      addToast(`Note "${entryToDelete?.title || 'Untitled'}" deleted.`, 'info');
      return { ...prev, noemasNotebookEntries: updatedEntries };
    });
  };
  
  const addSavedAiResponse = (aiMessage: ChatMessage, userPrompt?: ChatMessage) => {
    // Placeholder
  };
  
  const createStoryForgeSession = (): StoryForgeSession => {
    const newSession: StoryForgeSession = {
      id: `story_${Date.now()}_${Math.random().toString(16).slice(2)}`,
      title: "Untitled Story",
      fullStory: [{id: crypto.randomUUID(), role: 'noema', parts:[{text:"Let's begin your new story!"}], timestamp: Date.now()}],
      loreNotes: {},
      lastUpdated: new Date().toISOString(),
    };
    setUserProgress(prev => {
        if (!prev) return prev; 
        const updatedSessions = [newSession, ...(prev.storyForgeSessions || [])];
        addToast(`New story "${newSession.title}" created!`, 'success');
        return { ...prev, storyForgeSessions: updatedSessions };
    });
    return newSession;
  };

  const updateStoryForgeSessions = (sessions: StoryForgeSession[], updatedSession?: StoryForgeSession) => {
    setUserProgress(prev => {
      if (!prev) return null;
      if(updatedSession) addToast(`Story "${updatedSession.title}" saved.`, 'success');
      return { ...prev, storyForgeSessions: sessions };
    });
  };
  
  const createVaultStory = (baseSession: StoryForgeSession, title?: string): string | undefined => {
    if (!userProgress) return undefined;
    const newVaultEntry: VaultStory = {
      id: `vault_${Date.now()}_${Math.random().toString(16).slice(2)}`,
      title: title || `Collection for "${baseSession.title}"`,
      baseSessionId: baseSession.id,
      versionSessionIds: [baseSession.id],
      createdAt: Date.now(),
      lastModified: Date.now(),
    };
    setUserProgress(prev => {
        if(!prev) return null;
        addToast(`Story group "${newVaultEntry.title}" created in Vault!`, 'success');
        return {...prev, storyVault: [newVaultEntry, ...(prev.storyVault || [])] };
    });
    return newVaultEntry.id;
  };

  const addVersionToVaultStory = (vaultId: string, versionSession: StoryForgeSession) => {
    setUserProgress(prev => {
      if (!prev) return null;
      return { ...prev, storyVault: prev.storyVault.map(v => v.id === vaultId ? {...v, versionSessionIds: Array.from(new Set([...v.versionSessionIds, versionSession.id])), lastModified: Date.now()} : v) };
    });
  };

  const updateVaultStoryMeta = (vaultId: string, updates: Partial<Pick<VaultStory, 'title' | 'description'>>) => {
    setUserProgress(prev => {
      if (!prev) return null;
      return { ...prev, storyVault: prev.storyVault.map(v => v.id === vaultId ? {...v, ...updates, lastModified: Date.now()} : v) };
    });
  };

  const deleteVaultStoryEntry = (vaultId: string) => {
     setUserProgress(prev => prev ? { ...prev, storyVault: prev.storyVault.filter(v => v.id !== vaultId) } : null);
  };

  const removeSessionFromVault = (vaultId: string, sessionId: string) => {
    setUserProgress(prev => {
      if (!prev) return null;
      return { ...prev, storyVault: prev.storyVault.map(v => v.id === vaultId ? {...v, versionSessionIds: v.versionSessionIds.filter(id => id !== sessionId), lastModified: Date.now()} : v).filter(v => v.versionSessionIds.length > 0 || v.id !== vaultId) };
    });
  };
  
  const loadSessionToWorkshop = (sessionId: string) => {
    if (typeof localStorage !== 'undefined') {
        localStorage.setItem('storyforge_load_session_id', sessionId);
        localStorage.setItem('storyforge_target_mode', 'story_forge');
    }
    setCurrentView('story_forge'); 
    addToast("Loading story session to Story Forge...", "info");
  };

  const triggerSocraticPromptsForSimulation = useCallback((triggerType: SocraticPromptDefinition['trigger'], context: SocraticContext) => {
    // Placeholder
  }, []);

  const contextValue: AppContextType = {
    userProgress,
    setUserProgress,
    updateUserProgress: (updates) => setUserProgress(prev => prev ? { ...prev, ...updates } : null),
    currentView,
    setCurrentView,
    isAppReady,
    initializeUser,
    speak,
    toggleTTS,
    isTTSEnabled: userProgress?.ttsEnabled ?? DEFAULT_TTS_ENABLED,
    userId: userProgress?.userId || null,
    promptLibrary,
    setPromptLibrary,
    addPromptToLibrary: (promptData) => {
      const newPrompt: PromptItem = {...promptData, id: crypto.randomUUID(), createdAt: Date.now(), updatedAt: Date.now()};
      setPromptLibrary(prev => [newPrompt, ...prev]);
      addToast(`Prompt "${newPrompt.title}" added.`, 'success');
    },
    deletePromptFromLibrary: (promptId) => {
      setPromptLibrary(prev => prev.filter(p => p.id !== promptId));
      addToast("Prompt removed.", "info");
    },
    quests: ALL_QUESTS,
    socraticPrompts: ALL_SOCRATIC_PROMPTS,
    activeQuest: userProgress?.currentQuestId ? ALL_QUESTS.find(q => q.id === userProgress.currentQuestId) || null : null,
    activeStep: userProgress?.currentQuestId && userProgress?.currentStepId ? ALL_QUESTS.find(q => q.id === userProgress.currentQuestId)?.steps.find(s => s.id === userProgress.currentStepId) || null : null,
    startQuest,
    completeStep,
    resetUserProgressAndLibrary,
    modalConfig,
    showModal,
    hideModal,
    addToast,
    addNotebookEntry,
    updateNotebookEntry,
    deleteNotebookEntry,
    addSavedAiResponse,
    storyForgeSessions: userProgress?.storyForgeSessions || [],
    createStoryForgeSession,
    updateStoryForgeSessions,
    createVaultStory,
    addVersionToVaultStory,
    updateVaultStoryMeta,
    deleteVaultStoryEntry,
    removeSessionFromVault,
    loadSessionToWorkshop,
    triggerSocraticPromptsForSimulation,
    targetNexusTermId, 
    setTargetNexusTermId,
    selectedOrchestratorInstanceId,
    setSelectedOrchestratorInstanceId,
    activeWorkshopMode,
    setActiveWorkshopMode,
    orchestratorWorkflowForContext,
    setOrchestratorWorkflowForContext,
    inputValue,
    setInputValue,
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
      {toastMessages.length > 0 && (
        <div className="fixed bottom-4 right-4 space-y-2 z-[200]" role="status" aria-live="assertive">
          {toastMessages.map(toast => (
            <div key={toast.id} className={`p-3 rounded-md shadow-lg text-sm text-white flex items-center
              ${toast.type === 'success' ? 'bg-green-600' : 
               toast.type === 'error' ? 'bg-red-600' : 
               toast.type === 'warning' ? 'bg-yellow-600 text-slate-800' : 
               'bg-sky-600'}`}
            >
              {toast.icon && <Icon name={toast.icon} size={18} className="mr-2"/>}
              {toast.message}
            </div>
          ))}
        </div>
      )}
      {modalConfig?.isVisible && modalConfig.content && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[150] p-4 backdrop-blur-sm" 
             onClick={(e) => { if (e.target === e.currentTarget && !modalConfig.onCancel && modalConfig.cancelText !== null) hideModal(); }}>
          <div className="bg-slate-800 p-6 rounded-lg shadow-2xl w-full max-w-md border border-slate-700"
               onClick={(e)=>e.stopPropagation()}
               role="dialog"
               aria-labelledby="modal-title"
               aria-modal="true"
          >
            <h3 id="modal-title" className="text-xl font-semibold text-sky-300 mb-4">{modalConfig.title}</h3>
            <div className="text-slate-300 text-sm mb-6">{modalConfig.content}</div>
            <div className="flex justify-end space-x-3">
              {modalConfig.onCancel && <button onClick={modalConfig.onCancel} className="px-4 py-2 bg-slate-600 hover:bg-slate-500 text-slate-100 rounded-md transition-colors">{modalConfig.cancelText || "Cancel"}</button>}
              {modalConfig.onConfirm && <button onClick={modalConfig.onConfirm} className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-md transition-colors">{modalConfig.confirmText || "Confirm"}</button>}
              {!modalConfig.onConfirm && !modalConfig.onCancel && <button onClick={hideModal} className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-md transition-colors">OK</button>}
            </div>
          </div>
        </div>
      )}
    </AppContext.Provider>
  );
};